# ACCESS — configuração e teste (v3.0)

## 1. Chave do OpenRouter
Abra `local.properties` na raiz do projeto (no mesmo nível de `settings.gradle.kts`) e adicione:

`OPENROUTER_API_KEY=SUA_CHAVE_DO_OPENROUTER`

Se o arquivo não existir, crie-o. Não remova uma linha `sdk.dir=...` que já exista. Depois use **Sync Project with Gradle Files**. A chave embutida no APK pode ser extraída; para distribuir o app a outras pessoas, mova as chamadas de IA para um backend próprio (basta implementar outro `AiClient` em `ai/`).

Modelo configurado: `google/gemini-2.5-flash-lite`.

## 2. Firmware da bengala
O firmware novo está em `firmware/BengalaTech/BengalaTech.ino`. Leia o cabeçalho do arquivo: ele lista a placa, o esquema de partição **Huge APP** (obrigatório), a ligação do botão (GPIO13 ao GND) e a fonte de alimentação recomendada. O erro `FB-OVF` costuma vir de fonte fraca ou de quadro grande demais; o firmware usa 10 MHz, dois buffers em PSRAM e recompressão automática para evitá-lo.

## 3. Bluetooth
Bluetooth clássico SPP, UUID `00001101-0000-1000-8000-00805F9B34FB`. Pareie `BengalaTech` nas configurações Bluetooth do Android antes do primeiro uso. O app procura o nome exato `BengalaTech`.

Protocolo (não mudou):
- app -> bengala: `FOTO\n`
- bengala -> app: `FOTO:<bytes>\n` + exatamente esses bytes JPEG; ou `ERRO_CAMERA\n`
- testes: `PING\n` -> `PONG`; `STATUS\n` -> `ESP32_OK`
- botão físico: a bengala envia sozinha `FOTO:<bytes>\n` + JPEG; o app já aceita isso.

## 4. Abrir e executar
1. Extraia o ZIP e abra a pasta `ACCESS_Novo` no Android Studio; aguarde a sincronização do Gradle.
2. Grave o firmware na ESP32-CAM e pareie `BengalaTech` com o celular.
3. Execute o app, aceite as permissões de Bluetooth e notificações.
4. Toque em **ANALISAR**.

Testes automáticos do protocolo: `./gradlew testDebugUnitTest` (ou clique com o direito em `BengalaProtocolTest`).
Regras de arquitetura: `./verificar_arquitetura.sh`.

## 5. O que há de novo na v3.0
- Núcleo dividido em pacotes (`bluetooth`, `ai`, `data`, `audio`, `navigation`, `assistant`); o serviço Bluetooth não conhece mais a IA.
- Protocolo robusto: lixo no canal não derruba a conexão, imagem validada, vigia de travamento, reconexão com espera crescente, serviço só inicia com permissão.
- Falhas de captura ou de IA são avisadas por voz e vibração e não entram no histórico.
- Visual novo, ícones próprios, fundo em degradê, botão central animado durante a análise.
- Acessibilidade: texto ampliado global, alto contraste, velocidade da voz, vibração com padrões, aviso falado de conexão, repetir/parar a leitura, "Ouvir" em cada item do histórico, descrição mais completa opcional, atalho "Analisar agora" na notificação (funciona com a tela bloqueada), voz no canal de acessibilidade, áreas de toque de pelo menos 48 dp, rótulos e estados para o TalkBack.
- Otimização: histórico e imagem carregados fora da thread principal, lista do histórico e do chat preguiçosa, animação só enquanto há análise, repetição automática da chamada à IA em falha de rede, notificação só atualiza quando o texto muda.

## 6. O que NÃO foi testado
Este projeto foi escrito e verificado sem Android Studio e sem a placa. Foram conferidos, com compilador: o protocolo (9 testes passam), todo o código que não é interface (compila contra a API do Android 33) e a sintaxe do `.ino` (contra cabeçalhos simulados). **Não foram verificados**: a compilação completa do app (telas em Compose), o funcionamento no celular, o firmware na placa, o TalkBack, o funcionamento em segundo plano com a tela bloqueada, o retorno do Maps ao ACCESS. Teste cada um no aparelho real antes de confiar.

## Limitações importantes
- O Android pode encerrar serviços ou restringir Bluetooth em segundo plano conforme fabricante e bateria. Teste com a tela apagada e desative a otimização de bateria do ACCESS se a conexão cair.
- O Google Maps é um app externo; o retorno automático depende da permissão "Exibir sobre outros apps".
- A IA pode errar; não use a descrição como única garantia de segurança ao caminhar.
- A chave no APK não é segredo seguro. Use um backend antes de distribuir.
- O botão "abrir o Gemini" foi substituído pelo assistente dentro do app (aba Assistente).

package com.example.access.backend

import android.graphics.Bitmap

/*
 * CONTRATO ENTRE FRONT END (pacote ui) E O RESTO DO APP.
 *
 * O front end só pode importar ESTE arquivo. Enquanto o contrato não mudar, a interface pode
 * ser redesenhada à vontade sem tocar em Bluetooth, IA, voz, histórico ou Maps.
 *  - AccessUiState : tudo o que a interface precisa MOSTRAR
 *  - AccessActions : tudo o que a interface pode PEDIR
 */

data class HistoryItem(val title: String, val date: String, val text: String)

/** Forma de ir até o destino. [label] aparece na tela; [spoken] é falado pela voz do app. */
enum class TravelMode(val label: String, val spoken: String) {
    WALKING("A pé", "a pé"),
    TRANSIT("Transporte público", "de transporte público"),
    DRIVING("Carro", "de carro"),
    BICYCLING("Bicicleta", "de bicicleta")
}

/** Velocidade da voz do app. */
enum class SpeechRate(val label: String, val value: Float) {
    SLOW("Lenta", 0.8f),
    NORMAL("Normal", 1.0f),
    FAST("Rápida", 1.3f),
    VERY_FAST("Muito rápida", 1.6f)
}

/** Em que etapa está a análise do ambiente. */
enum class AnalysisStage { IDLE, REQUESTING, RECEIVING, ANALYZING }

data class AppSettings(
    val voiceEnabled: Boolean = true,
    val autoConnect: Boolean = true,
    val largeText: Boolean = false,
    val travelMode: TravelMode = TravelMode.WALKING,
    val highContrast: Boolean = false,
    /** Vibrações curtas ao capturar, concluir ou falhar. */
    val haptics: Boolean = true,
    /** Falar "Bengala conectada/desconectada" quando o estado mudar. */
    val announceConnection: Boolean = true,
    /** Pede à IA uma descrição um pouco mais completa. */
    val detailedAnalysis: Boolean = false,
    val speechRate: SpeechRate = SpeechRate.NORMAL
)

/** Última imagem enviada para análise, guardada só no celular. */
data class LastImage(val bitmap: Bitmap, val capturedAt: String, val analysis: String)

/** Mensagem da conversa com o assistente. */
data class ChatMessage(val fromUser: Boolean, val text: String, val withImage: Boolean = false)

data class AccessUiState(
    val connectionStatus: String = "Iniciando conexão...",
    val isConnected: Boolean = false,
    val stage: AnalysisStage = AnalysisStage.IDLE,
    val lastAnalysis: String = "",
    val lastImage: LastImage? = null,
    val history: List<HistoryItem> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val lastDestination: String = "",
    /** Permissão "Exibir sobre outros apps" (usada para voltar ao ACCESS depois do Maps). */
    val overlayGranted: Boolean = false,
    val assistantMessages: List<ChatMessage> = emptyList(),
    val assistantBusy: Boolean = false,
    /** Se verdadeiro, a última imagem vai junto com a PRÓXIMA pergunta ao assistente. */
    val assistantUseImage: Boolean = false
)

/** Eventos pontuais que o back end pede ao "shell" (MainActivity) para executar. */
sealed interface AccessEvent {
    data class ShowMessage(val message: String) : AccessEvent
    data class LaunchSpeechRecognizer(val prompt: String) : AccessEvent
}

interface AccessActions {
    // Bengala e análise
    fun requestAnalysis()
    fun reconnect()
    fun repeatLastAnalysis()

    // Voz
    fun speakText(text: String)
    fun stopSpeaking()

    // Rotas
    fun startVoiceRoute()
    fun openRoute(destination: String)
    fun setTravelMode(mode: TravelMode)
    fun openGoogleMaps()
    fun openOverlaySettings()

    // Assistente dentro do app
    fun startVoiceAssistant()
    fun askAssistant(text: String)
    fun setAssistantUseImage(enabled: Boolean)
    fun clearAssistantChat()

    // Dados e configurações
    fun clearHistory()
    fun clearLastImage()
    fun setVoiceEnabled(enabled: Boolean)
    fun setAutoConnect(enabled: Boolean)
    fun setLargeText(enabled: Boolean)
    fun setHighContrast(enabled: Boolean)
    fun setHaptics(enabled: Boolean)
    fun setAnnounceConnection(enabled: Boolean)
    fun setDetailedAnalysis(enabled: Boolean)
    fun setSpeechRate(rate: SpeechRate)
}

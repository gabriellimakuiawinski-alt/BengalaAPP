package com.example.access.bluetooth

import java.io.IOException
import java.io.InputStream

/** Mensagens que a bengala (ESP32-CAM) pode enviar ao celular. */
internal sealed interface BengalaMessage {
    /** Foto JPEG completa e validada. */
    class Photo(val jpeg: ByteArray) : BengalaMessage

    /** Texto livre da bengala (por exemplo PONG ou ESP32_OK). */
    class Status(val text: String) : BengalaMessage

    /** A câmera não conseguiu capturar (linha ERRO_CAMERA). */
    object CameraError : BengalaMessage

    /** Cabeçalho inválido ou imagem corrompida. */
    class BadPhoto(val reason: String) : BengalaMessage
}

internal class ProtocolException(message: String) : IOException(message)

/** Comandos que o app envia. O protocolo é o mesmo das versões anteriores. */
internal object BengalaCommands {
    const val PHOTO = "FOTO\n"
    const val PING = "PING\n"
    const val STATUS = "STATUS\n"
}

/**
 * Leitor do protocolo da bengala. Não conhece Android: só recebe um [InputStream].
 *
 * Protocolo (inalterado):
 *   app -> bengala : "FOTO\n"
 *   bengala -> app : "FOTO:<tamanho>\n" seguido de exatamente <tamanho> bytes JPEG
 *   outras linhas  : "PONG", "ESP32_OK", "ERRO_CAMERA"
 *
 * Diferenças em relação à versão anterior:
 *  - linhas longas ou binárias nunca derrubam a conexão: são descartadas e a leitura continua;
 *  - o cabeçalho é procurado dentro da linha, então lixo antes dele não o esconde;
 *  - o JPEG recebido é validado antes de ir para a IA;
 *  - o progresso da leitura é publicado para o serviço detectar travamentos.
 */
internal class BengalaProtocol(
    private val input: InputStream,
    private val clock: () -> Long = System::currentTimeMillis,
    private val onPhotoHeader: (Int) -> Unit = {}
) {
    @Volatile
    var transferActive: Boolean = false
        private set

    @Volatile
    private var lastProgressAt: Long = 0L

    private val lineBytes = ByteArray(LINE_BUFFER)

    /** Verdadeiro se uma imagem está sendo recebida e nenhum byte chega há mais de [timeoutMs]. */
    fun isStalled(timeoutMs: Long): Boolean = transferActive && clock() - lastProgressAt > timeoutMs

    /** Bloqueia até chegar uma mensagem útil. Lança [IOException] se a conexão cair. */
    fun readMessage(): BengalaMessage {
        while (true) {
            val line = readLine()
            val marker = line.lastIndexOf(PHOTO_PREFIX)
            if (marker >= 0) {
                val digits = line.substring(marker + PHOTO_PREFIX.length).trim().takeWhile { it.isDigit() }
                val size = digits.toIntOrNull()
                if (size == null || size <= 0 || size > MAX_IMAGE_BYTES) {
                    return BengalaMessage.BadPhoto("Tamanho de imagem inválido na resposta da bengala")
                }
                onPhotoHeader(size)
                val jpeg = readExact(size)
                return if (looksLikeJpeg(jpeg)) BengalaMessage.Photo(jpeg)
                else BengalaMessage.BadPhoto("A imagem chegou incompleta ou corrompida")
            }
            when {
                line == "ERRO_CAMERA" -> return BengalaMessage.CameraError
                line.isNotBlank() && isPrintable(line) -> return BengalaMessage.Status(line)
                // linha vazia ou binária: ignora e continua lendo
            }
        }
    }

    private fun readLine(): String {
        var count = 0
        while (true) {
            val value = input.read()
            if (value < 0) throw ProtocolException("Bluetooth encerrado")
            if (value == NEWLINE) break
            if (count == lineBytes.size) {
                // Linha longa demais: era lixo binário. Guarda só o final, onde um cabeçalho ainda caberia.
                System.arraycopy(lineBytes, count - KEEP_TAIL, lineBytes, 0, KEEP_TAIL)
                count = KEEP_TAIL
            }
            lineBytes[count++] = value.toByte()
        }
        return String(lineBytes, 0, count, Charsets.ISO_8859_1).trimEnd('\r')
    }

    private fun readExact(expected: Int): ByteArray {
        val result = ByteArray(expected)
        var offset = 0
        transferActive = true
        lastProgressAt = clock()
        try {
            while (offset < expected) {
                val count = input.read(result, offset, expected - offset)
                if (count < 0) throw ProtocolException("Conexão caiu durante a imagem ($offset/$expected bytes)")
                if (count > 0) {
                    offset += count
                    lastProgressAt = clock()
                }
            }
        } finally {
            transferActive = false
        }
        return result
    }

    private fun isPrintable(text: String) = text.all { it.code in 32..126 }

    companion object {
        const val MAX_IMAGE_BYTES = 3_000_000
        private const val PHOTO_PREFIX = "FOTO:"
        private const val NEWLINE = 10
        private const val LINE_BUFFER = 256
        private const val KEEP_TAIL = 32

        /** JPEG começa com FF D8 e termina com FF D9 (aceita alguns bytes de enchimento no fim). */
        fun looksLikeJpeg(bytes: ByteArray): Boolean {
            if (bytes.size < 4) return false
            if (bytes[0] != 0xFF.toByte() || bytes[1] != 0xD8.toByte()) return false
            val from = maxOf(2, bytes.size - 16)
            for (i in bytes.size - 2 downTo from) {
                if (bytes[i] == 0xFF.toByte() && bytes[i + 1] == 0xD9.toByte()) return true
            }
            return false
        }
    }
}

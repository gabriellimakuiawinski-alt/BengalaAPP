package com.example.access.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/** Gemini via OpenRouter: descrição de imagens e assistente de voz. */
internal class OpenRouterClient(private val apiKey: String) : AiClient {

    /** Falha que vale a pena tentar de novo (rede instável, serviço ocupado). */
    private class TransientFailure(val offline: Boolean) : Exception()

    override fun describe(jpeg: ByteArray, detailed: Boolean): String {
        val prompt = if (detailed) DESCRIBE_DETAILED else DESCRIBE_SHORT
        val content = JSONArray().put(textPart(prompt)).put(imagePart(jpeg))
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        return complete(messages, maxTokens = if (detailed) 320 else 160, temperature = 0.2)
    }

    override fun chat(history: List<AiMessage>, imageJpeg: ByteArray?): String {
        val recent = history.takeLast(12).dropWhile { !it.fromUser }
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", ASSISTANT_PROMPT))
        recent.forEachIndexed { index, message ->
            val isLast = index == recent.lastIndex
            if (message.fromUser && isLast && imageJpeg != null) {
                val content = JSONArray().put(textPart(message.text)).put(imagePart(imageJpeg))
                messages.put(JSONObject().put("role", "user").put("content", content))
            } else {
                messages.put(
                    JSONObject().put("role", if (message.fromUser) "user" else "assistant").put("content", message.text)
                )
            }
        }
        return complete(messages, maxTokens = 400, temperature = 0.5)
    }

    private fun textPart(text: String) = JSONObject().put("type", "text").put("text", text)

    private fun imagePart(jpeg: ByteArray): JSONObject {
        val image64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        return JSONObject().put("type", "image_url")
            .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$image64"))
    }

    private fun complete(messages: JSONArray, maxTokens: Int, temperature: Double): String {
        val key = apiKey.trim()
        if (key.isBlank()) {
            throw AnalysisException("Configure OPENROUTER_API_KEY no arquivo local.properties e recompile o app.")
        }
        val payload = JSONObject()
            .put("model", MODEL)
            .put("temperature", temperature)
            .put("max_tokens", maxTokens)
            .put("messages", messages)
            .toString()
            .toByteArray(Charsets.UTF_8)

        var offline = false
        for (attempt in 1..MAX_ATTEMPTS) {
            try {
                return parseAnswer(post(key, payload))
            } catch (e: TransientFailure) {
                offline = e.offline
                if (attempt < MAX_ATTEMPTS) {
                    try { Thread.sleep(RETRY_DELAY_MS) } catch (_: InterruptedException) { break }
                }
            }
        }
        throw AnalysisException(
            if (offline) "Sem conexão com a internet. Verifique a rede e tente de novo."
            else "O serviço de análise está ocupado. Tente novamente em instantes."
        )
    }

    private fun post(key: String, payload: ByteArray): String {
        val conn = (URL(URL_API).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 35_000
            doOutput = true
            setFixedLengthStreamingMode(payload.size)
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("HTTP-Referer", "https://access.local")
            setRequestProperty("X-Title", "ACCESS")
        }
        try {
            conn.outputStream.use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            when (code) {
                in 200..299 -> return body
                401, 403 -> throw AnalysisException("A chave do OpenRouter foi recusada. Confira OPENROUTER_API_KEY.")
                402 -> throw AnalysisException("O OpenRouter está sem créditos para esta chave.")
                408, 429, 500, 502, 503, 504 -> throw TransientFailure(offline = false)
                else -> throw AnalysisException("O serviço de análise respondeu com erro $code.")
            }
        } catch (e: IOException) {
            throw TransientFailure(offline = true)
        } finally {
            conn.disconnect()
        }
    }

    private fun parseAnswer(body: String): String {
        val json = try { JSONObject(body) } catch (e: Exception) {
            throw AnalysisException("Resposta inesperada do serviço de análise.")
        }
        if (json.has("error") && !json.has("choices")) {
            throw AnalysisException("O serviço de análise não conseguiu responder agora.")
        }
        val text = json.optJSONArray("choices")?.optJSONObject(0)
            ?.optJSONObject("message")?.optString("content")?.trim().orEmpty()
        if (text.isBlank()) throw AnalysisException("A análise voltou vazia. Tente novamente.")
        return text
    }

    private companion object {
        const val URL_API = "https://openrouter.ai/api/v1/chat/completions"
        const val MODEL = "google/gemini-2.5-flash-lite"
        const val MAX_ATTEMPTS = 2
        const val RETRY_DELAY_MS = 1_200L

        const val DESCRIBE_SHORT = """
Você é o assistente de acessibilidade visual do ACCESS, usado por pessoas cegas ou com baixa visão enquanto andam. A imagem vem de uma câmera presa à bengala, apontada para a frente.
Responda em português do Brasil, em no máximo duas frases curtas e fáceis de ouvir, sem markdown, listas ou emojis.
Diga primeiro o que representa mais risco: degraus, buracos, desníveis, veículos, obstáculos no chão ou na altura do corpo e pessoas. Depois cite portas, escadas e possíveis caminhos livres.
Use esquerda, centro ou direita apenas quando isso estiver visível. Não invente distâncias nem medidas.
Se a imagem estiver escura, tremida, tampada ou confusa, diga isso claramente.
Nunca afirme que o caminho é seguro ou está livre só porque não vê obstáculos: descreva apenas o que enxerga."""

        const val DESCRIBE_DETAILED = """
Você é o assistente de acessibilidade visual do ACCESS, usado por pessoas cegas ou com baixa visão enquanto andam. A imagem vem de uma câmera presa à bengala, apontada para a frente.
Responda em português do Brasil, em no máximo quatro frases curtas e fáceis de ouvir, sem markdown, listas ou emojis.
Comece pelo que representa mais risco (degraus, buracos, desníveis, veículos, obstáculos, pessoas). Depois descreva o ambiente em linhas gerais: tipo de lugar, portas, escadas, superfície do chão e possíveis caminhos livres.
Use esquerda, centro ou direita apenas quando isso estiver visível. Não invente distâncias nem medidas.
Se a imagem estiver escura, tremida, tampada ou confusa, diga isso claramente.
Nunca afirme que o caminho é seguro ou está livre só porque não vê obstáculos: descreva apenas o que enxerga."""

        const val ASSISTANT_PROMPT = """
Você é o assistente de voz do ACCESS, um app para pessoas com deficiência visual que usam a Bengala Tech. Responda sempre em português do Brasil, de forma curta e clara, com frases fáceis de ouvir. Não use markdown, listas, emojis nem símbolos. Se houver imagem e a pessoa pedir para descrevê-la, cite primeiro obstáculos e riscos, não invente distâncias e nunca garanta que o caminho é seguro. Se não souber algo ou não conseguir ver, diga isso. Para ir a algum lugar, oriente a usar o botão de rota do ACCESS. Em emergência, oriente ligar para 192 (SAMU), 193 (bombeiros) ou 190 (polícia)."""
    }
}

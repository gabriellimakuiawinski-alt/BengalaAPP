package com.example.access.ui

import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState

/** Páginas do app. O nome falado pelo leitor de tela é [label]. */
internal enum class Page(val label: String, val icon: IconKind) {
    Home("Início", IconKind.Home),
    History("Histórico", IconKind.History),
    Navigation("Rotas", IconKind.Route),
    Assistant("Assistente", IconKind.Assistant),
    Settings("Ajustes", IconKind.Settings)
}

/**
 * Raiz do FRONT END. Recebe só o estado e as ações do contrato (backend/AccessContract.kt).
 * Para redesenhar o app, mexa apenas nos arquivos desta pasta (ui/).
 */
@Composable
fun AccessApp(state: AccessUiState, actions: AccessActions) {
    var pageName by rememberSaveable { mutableStateOf(Page.Home.name) }
    val page = Page.values().firstOrNull { it.name == pageName } ?: Page.Home

    AxBackground {
        Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
            Box(Modifier.weight(1f).fillMaxWidth()) {
                Crossfade(targetState = page, label = "page") { current ->
                    when (current) {
                        Page.History -> HistoryScreen(state, actions)
                        Page.Navigation -> NavigationScreen(state, actions)
                        Page.Assistant -> AssistantScreen(state, actions)
                        Page.Settings -> SettingsScreen(state, actions)
                        Page.Home -> HomeScreen(state, actions) { pageName = it.name }
                    }
                }
            }
            BottomBar(page) { pageName = it.name }
        }
    }
}

@Composable
private fun BottomBar(current: Page, onSelect: (Page) -> Unit) {
    val c = Ax.colors
    HorizontalDivider(color = c.outline.copy(alpha = 0.6f))
    Row(
        Modifier.fillMaxWidth().background(c.bgBottom).navigationBarsPadding().padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Page.values().forEach { page -> BarItem(page, page == current, onSelect) }
    }
}

@Composable
private fun RowScope.BarItem(page: Page, selected: Boolean, onSelect: (Page) -> Unit) {
    val c = Ax.colors
    val tint = if (selected) c.accent else c.muted
    Column(
        Modifier
            .weight(1f)
            .heightIn(min = 64.dp)
            .clip(RoundedCornerShape(16.dp))
            .selectable(selected = selected, role = Role.Tab, onClick = { onSelect(page) })
            .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .width(56.dp)
                .height(30.dp)
                .clip(RoundedCornerShape(15.dp))
                .background(if (selected) c.accent.copy(alpha = 0.20f) else c.bgBottom),
            contentAlignment = Alignment.Center
        ) {
            AxIcon(page.icon, tint, iconSize = 24.dp)
        }
        Spacer(Modifier.height(3.dp))
        Text(
            page.label,
            fontSize = 12.sp,
            maxLines = 1,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            color = if (selected) c.accent else c.text,
            textAlign = TextAlign.Center
        )
    }
}

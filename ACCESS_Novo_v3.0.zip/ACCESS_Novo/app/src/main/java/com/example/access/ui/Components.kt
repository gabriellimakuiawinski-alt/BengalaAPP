package com.example.access.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.TravelMode

private val CardShape = RoundedCornerShape(22.dp)
private val ButtonShape = RoundedCornerShape(18.dp)

@Composable
private fun borderWidth() = if (Ax.colors.highContrast) 2.dp else 1.dp

/** Fundo de todas as telas: degradê vertical (preto puro no alto contraste). */
@Composable
internal fun AxBackground(content: @Composable BoxScope.() -> Unit) {
    val c = Ax.colors
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(c.bgTop, c.bgBottom))),
        content = content
    )
}

@Composable
internal fun PageHeader(title: String, subtitle: String) {
    val c = Ax.colors
    Column {
        Text(
            title,
            modifier = Modifier.semantics { heading() },
            fontSize = 30.sp,
            fontWeight = FontWeight.ExtraBold,
            color = c.text
        )
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = c.muted, fontSize = 15.sp, lineHeight = 21.sp)
    }
}

@Composable
internal fun SectionLabel(text: String, modifier: Modifier = Modifier) {
    Text(
        text.uppercase(),
        modifier = modifier.semantics { heading() },
        color = Ax.colors.accent,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.4.sp
    )
}

/** Cartão padrão: superfície escura com borda fina (grossa no alto contraste). */
@Composable
internal fun AxCard(
    modifier: Modifier = Modifier,
    highlight: Boolean = false,
    content: @Composable ColumnScope.() -> Unit
) {
    val c = Ax.colors
    val borderColor = if (highlight) c.accent else c.outline
    Column(
        modifier
            .fillMaxWidth()
            .background(c.surface, CardShape)
            .border(borderWidth(), borderColor, CardShape)
            .padding(18.dp),
        content = content
    )
}

@Composable
internal fun EmptyPanel(text: String) {
    AxCard { Text(text, color = Ax.colors.muted, fontSize = 16.sp, lineHeight = 23.sp) }
}

@Composable
internal fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: IconKind? = null,
    enabled: Boolean = true
) {
    val c = Ax.colors
    Button(
        onClick = onClick,
        modifier = modifier.heightIn(min = 58.dp),
        enabled = enabled,
        shape = ButtonShape,
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = c.accent,
            contentColor = c.onAccent,
            disabledContainerColor = c.surfaceHigh,
            disabledContentColor = c.muted
        )
    ) {
        if (icon != null) {
            AxIcon(icon, LocalContentColor.current, iconSize = 22.dp)
            Spacer(Modifier.width(10.dp))
        }
        Text(text, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, letterSpacing = 0.4.sp)
    }
}

@Composable
internal fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: IconKind? = null,
    enabled: Boolean = true
) {
    val c = Ax.colors
    OutlinedButton(
        onClick = onClick,
        modifier = modifier.heightIn(min = 52.dp),
        enabled = enabled,
        shape = ButtonShape,
        border = BorderStroke(borderWidth(), if (enabled) c.outline else c.surfaceHigh),
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
        colors = ButtonDefaults.outlinedButtonColors(
            contentColor = c.text,
            disabledContentColor = c.muted
        )
    ) {
        if (icon != null) {
            AxIcon(icon, if (enabled) c.accent else c.muted, iconSize = 20.dp)
            Spacer(Modifier.width(8.dp))
        }
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }
}

/** Linha inteira clicável (um único alvo para o leitor de tela): título, explicação e chave. */
@Composable
internal fun SettingSwitch(title: String, subtitle: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    val c = Ax.colors
    Row(
        Modifier
            .fillMaxWidth()
            .heightIn(min = 64.dp)
            .toggleable(value = checked, role = Role.Switch, onValueChange = onCheckedChange)
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = c.text, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
            Spacer(Modifier.height(2.dp))
            Text(subtitle, color = c.muted, fontSize = 14.sp, lineHeight = 19.sp)
        }
        Spacer(Modifier.width(14.dp))
        Switch(
            checked = checked,
            onCheckedChange = null,
            colors = SwitchDefaults.colors(
                checkedThumbColor = c.onAccent,
                checkedTrackColor = c.accent,
                uncheckedThumbColor = c.muted,
                uncheckedTrackColor = c.surfaceHigh,
                uncheckedBorderColor = c.outline
            )
        )
    }
    HorizontalDivider(color = c.outline.copy(alpha = 0.5f))
}

/** Escolha entre poucas opções em fila rolável (forma de ir, velocidade da voz...). */
@Composable
internal fun <T> ChipChoice(
    options: List<T>,
    selected: T,
    label: (T) -> String,
    onSelect: (T) -> Unit,
    modifier: Modifier = Modifier
) {
    val c = Ax.colors
    Row(
        modifier.horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEach { option ->
            val isSelected = option == selected
            FilterChip(
                selected = isSelected,
                onClick = { onSelect(option) },
                label = { Text(label(option), fontSize = 15.sp, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium) },
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(borderWidth(), if (isSelected) c.accent else c.outline),
                colors = FilterChipDefaults.filterChipColors(
                    containerColor = c.surface,
                    labelColor = c.text,
                    selectedContainerColor = c.accent,
                    selectedLabelColor = c.onAccent
                )
            )
        }
    }
}

/** Escolha da forma de ir: a pé, transporte público, carro ou bicicleta. */
@Composable
internal fun TravelModeSelector(
    selected: TravelMode,
    onSelect: (TravelMode) -> Unit,
    modifier: Modifier = Modifier
) {
    ChipChoice(TravelMode.values().toList(), selected, { it.label }, onSelect, modifier)
}

@Composable
internal fun axTextFieldColors() = Ax.colors.let { c ->
    OutlinedTextFieldDefaults.colors(
        focusedTextColor = c.text,
        unfocusedTextColor = c.text,
        focusedBorderColor = c.accent,
        unfocusedBorderColor = c.outline,
        focusedLabelColor = c.accent,
        unfocusedLabelColor = c.muted,
        focusedPlaceholderColor = c.muted,
        unfocusedPlaceholderColor = c.muted,
        cursorColor = c.accent,
        focusedContainerColor = c.surface,
        unfocusedContainerColor = c.surface
    )
}

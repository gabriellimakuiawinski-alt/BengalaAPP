package com.example.access

import android.app.Application
import com.example.access.backend.AccessRepository

/**
 * Raiz de composição: liga o núcleo do app assim que o processo nasce, inclusive quando o Android
 * recria só o serviço Bluetooth com a tela apagada (sem passar pela MainActivity).
 */
class AccessApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        AccessRepository.init(this)
    }
}

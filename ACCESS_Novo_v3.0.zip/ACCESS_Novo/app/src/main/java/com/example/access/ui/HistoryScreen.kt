package com.example.access.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState
import com.example.access.backend.HistoryItem

@Composable
internal fun HistoryScreen(state: AccessUiState, actions: AccessActions) {
    var confirmClear by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
        PageHeader("Histórico", "Suas análises e rotas ficam salvas só neste celular.")
        Spacer(Modifier.height(16.dp))
        if (state.history.isEmpty()) {
            EmptyPanel("Ainda não há nada salvo. Quando você analisar o ambiente ou abrir uma rota, o registro aparece aqui.")
        } else {
            LazyColumn(
                Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(state.history) { item -> HistoryCard(item, actions) }
            }
            Spacer(Modifier.height(12.dp))
            SecondaryButton(
                "Limpar histórico",
                { confirmClear = true },
                Modifier.fillMaxWidth(),
                IconKind.Trash
            )
        }
    }

    if (confirmClear) {
        val c = Ax.colors
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = c.surface,
            title = { Text("Apagar todo o histórico?", color = c.text, fontWeight = FontWeight.Bold) },
            text = { Text("Essa ação não pode ser desfeita.", color = c.muted, fontSize = 16.sp) },
            confirmButton = {
                TextButton(onClick = { actions.clearHistory(); confirmClear = false }) {
                    Text("Apagar", color = c.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancelar", color = c.accent, fontWeight = FontWeight.Bold) }
            }
        )
    }
}

@Composable
private fun HistoryCard(item: HistoryItem, actions: AccessActions) {
    val c = Ax.colors
    AxCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionLabel(item.title, Modifier.weight(1f))
            Text(item.date, color = c.muted, fontSize = 13.sp)
        }
        Spacer(Modifier.height(8.dp))
        Text(item.text, color = c.text, fontSize = 17.sp, lineHeight = 25.sp)
        Spacer(Modifier.height(10.dp))
        SecondaryButton("Ouvir", { actions.speakText(item.text) }, Modifier.fillMaxWidth(), IconKind.Speaker)
    }
}

package com.example.access.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState
import com.example.access.backend.SpeechRate

@Composable
internal fun SettingsScreen(state: AccessUiState, actions: AccessActions) {
    val c = Ax.colors
    val s = state.settings

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp)) {
        PageHeader("Ajustes", "Deixe o ACCESS do seu jeito.")

        Spacer(Modifier.height(24.dp))
        SectionLabel("Voz e áudio")
        SettingSwitch("Resposta por voz", "Lê em voz alta as análises, as respostas e os avisos.", s.voiceEnabled) { actions.setVoiceEnabled(it) }
        SettingSwitch("Avisar a conexão", "Fala \"Bengala conectada\" ou \"desconectada\" quando o estado mudar.", s.announceConnection) { actions.setAnnounceConnection(it) }
        Spacer(Modifier.height(14.dp))
        Text("Velocidade da voz", color = c.text, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        Spacer(Modifier.height(8.dp))
        ChipChoice(SpeechRate.values().toList(), s.speechRate, { it.label }, { actions.setSpeechRate(it) }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        SecondaryButton(
            "Testar a voz",
            { actions.speakText("Esta é a voz do ACCESS, na velocidade ${s.speechRate.label.lowercase()}.") },
            Modifier.fillMaxWidth(),
            IconKind.Speaker
        )

        Spacer(Modifier.height(28.dp))
        SectionLabel("Acessibilidade")
        SettingSwitch("Texto ampliado", "Aumenta todo o texto do aplicativo.", s.largeText) { actions.setLargeText(it) }
        SettingSwitch("Alto contraste", "Fundo preto com letras brancas e amarelas, bordas mais grossas.", s.highContrast) { actions.setHighContrast(it) }
        SettingSwitch("Vibração", "Toques curtos: pedido aceito, análise pronta (dois toques) e erro (um toque longo).", s.haptics) { actions.setHaptics(it) }
        SettingSwitch("Descrição mais completa", "A IA descreve um pouco mais do ambiente. A análise demora um pouco mais.", s.detailedAnalysis) { actions.setDetailedAnalysis(it) }

        Spacer(Modifier.height(28.dp))
        SectionLabel("Bengala")
        SettingSwitch("Conectar sozinho", "Mantém a conexão Bluetooth e tenta de novo se ela cair.", s.autoConnect) { actions.setAutoConnect(it) }
        Spacer(Modifier.height(12.dp))
        AxCard {
            Text("BengalaTech", color = c.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                "Pareie a bengala nas configurações Bluetooth do Android antes do primeiro uso. O botão físico da bengala também tira a foto, e a notificação do ACCESS tem o atalho \"Analisar agora\", que funciona com a tela bloqueada.",
                color = c.muted, fontSize = 14.sp, lineHeight = 20.sp
            )
            Spacer(Modifier.height(12.dp))
            SecondaryButton("Reconectar agora", { actions.reconnect() }, Modifier.fillMaxWidth(), IconKind.Refresh)
        }

        Spacer(Modifier.height(28.dp))
        SectionLabel("Rotas")
        Spacer(Modifier.height(12.dp))
        AxCard {
            Text("Voltar ao ACCESS depois do Maps", color = c.text, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Spacer(Modifier.height(4.dp))
            Text(
                if (state.overlayGranted) {
                    "Permissão concedida: o ACCESS volta sozinho para a tela depois de iniciar a rota."
                } else {
                    "Para o ACCESS voltar sozinho depois de abrir o Maps, o Android exige a permissão \"Exibir sobre outros apps\". Ative o ACCESS na lista que vai abrir."
                },
                color = c.muted, fontSize = 14.sp, lineHeight = 20.sp
            )
            if (!state.overlayGranted) {
                Spacer(Modifier.height(12.dp))
                SecondaryButton("Conceder permissão", { actions.openOverlaySettings() }, Modifier.fillMaxWidth())
            }
        }

        Spacer(Modifier.height(28.dp))
        SectionLabel("Privacidade")
        Spacer(Modifier.height(10.dp))
        Text(
            "As fotos e as perguntas ao assistente são enviadas ao OpenRouter (Gemini) para serem analisadas. A última imagem fica guardada só neste celular (toque no ícone de imagem na tela inicial para ver ou apagar) e só vai ao assistente se você ligar essa opção na tela dele. A conversa com o assistente não é salva. A IA pode errar: nunca use a descrição como única garantia de segurança ao caminhar.",
            color = c.muted, fontSize = 14.sp, lineHeight = 21.sp
        )
        Spacer(Modifier.height(24.dp))
    }
}

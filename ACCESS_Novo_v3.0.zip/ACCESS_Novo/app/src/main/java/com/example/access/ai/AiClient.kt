package com.example.access.ai

/** Erro com mensagem já pronta para ser lida ao usuário. */
internal class AnalysisException(message: String) : Exception(message)

/** Mensagem de uma conversa, no formato que a camada de IA entende (sem depender da interface). */
internal class AiMessage(val fromUser: Boolean, val text: String)

/**
 * Contrato da inteligência artificial. O resto do app só conhece esta interface:
 * trocar OpenRouter por outro serviço (ou por um backend próprio) não afeta Bluetooth nem telas.
 * As funções bloqueiam; chame-as fora da thread principal.
 */
internal interface AiClient {
    /** Descreve o ambiente da foto. Lança [AnalysisException] com mensagem pronta para o usuário. */
    fun describe(jpeg: ByteArray, detailed: Boolean): String

    /** [history] termina com a pergunta nova. A imagem só acompanha a última pergunta. */
    fun chat(history: List<AiMessage>, imageJpeg: ByteArray?): String
}

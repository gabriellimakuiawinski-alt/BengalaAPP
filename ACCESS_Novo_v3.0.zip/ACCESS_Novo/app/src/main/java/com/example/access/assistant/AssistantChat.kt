package com.example.access.assistant

import com.example.access.ai.AiClient
import com.example.access.ai.AiMessage
import com.example.access.ai.AnalysisException
import com.example.access.backend.ChatMessage

/**
 * Conversa de voz/texto com o assistente dentro do app. Não abre o Gemini nem outro app:
 * usa a mesma camada de IA do restante do ACCESS.
 */
internal class AssistantChat(private val ai: AiClient) {
    /** Bloqueia. Sempre devolve um texto pronto para mostrar e falar, mesmo em caso de erro. */
    fun ask(history: List<ChatMessage>, imageJpeg: ByteArray?): String = try {
        ai.chat(history.map { AiMessage(it.fromUser, it.text) }, imageJpeg)
    } catch (e: AnalysisException) {
        e.message ?: "Não consegui responder agora."
    } catch (e: Exception) {
        "Não consegui responder agora. Verifique a internet e tente de novo."
    }

    /** Tira símbolos de formatação que a voz leria em voz alta. */
    fun cleanForSpeech(text: String): String = text.replace(Regex("[*_#`]+"), "")
}

package com.example.access.audio

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator

/**
 * Vibrações curtas com padrões diferentes, para a pessoa reconhecer o que aconteceu sem olhar
 * nem esperar a voz: captura iniciada, resultado pronto, erro.
 */
internal class Haptics(context: Context) {
    private val vibrator: Vibrator? = context.getSystemService(Vibrator::class.java)

    /** Um toque curto: o pedido foi aceito. */
    fun tap() = play(longArrayOf(0, 40))

    /** Dois toques curtos: resultado pronto. */
    fun success() = play(longArrayOf(0, 60, 90, 60))

    /** Um toque longo: algo deu errado. */
    fun error() = play(longArrayOf(0, 380))

    private fun play(pattern: LongArray) {
        try {
            val device = vibrator ?: return
            if (!device.hasVibrator()) return
            device.vibrate(VibrationEffect.createWaveform(pattern, -1))
        } catch (_: Exception) {
            // vibração é um extra: nunca pode causar falha
        }
    }
}

package com.example.access.bluetooth

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * O que o serviço Bluetooth conta ao resto do app. O serviço não conhece IA, voz, histórico
 * nem telas: quem quiser reagir implementa esta interface e se registra em [BengalaBridge].
 */
internal interface BengalaListener {
    fun onConnectionChanged(status: String, connected: Boolean)

    /** Um pedido de foto saiu (pelo app, pela notificação ou pelo botão da bengala). */
    fun onPhotoRequested()

    /** O cabeçalho chegou: a imagem de [bytes] bytes está sendo recebida. */
    fun onPhotoStarted(bytes: Int)

    fun onPhotoReceived(jpeg: ByteArray)

    fun onPhotoFailed(reason: String)

    /** Texto livre da bengala (PONG, ESP32_OK...). */
    fun onBengalaText(text: String)
}

/** Ponto de encontro entre o serviço (criado pelo Android) e o resto do app. */
internal object BengalaBridge {
    @Volatile
    var listener: BengalaListener? = null
}

internal object BluetoothAccess {
    fun hasConnectPermission(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED
}

package com.example.access.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.access.backend.AppSettings
import com.example.access.backend.HistoryItem
import com.example.access.backend.LastImage
import com.example.access.backend.SpeechRate
import com.example.access.backend.TravelMode
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Decodifica um JPEG reduzindo o tamanho se for muito grande (protege a memória). */
internal fun decodeScaled(bytes: ByteArray, maxSide: Int = 1280): Bitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > maxSide) sample *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    return BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
}

/** Tudo o que é gravado no celular: configurações, histórico e a última imagem. */
internal class AccessStorage(context: Context) {
    private val prefs = context.getSharedPreferences("access_prefs", Context.MODE_PRIVATE)
    private val imageFile = File(context.filesDir, "last_analysis.jpg")

    fun loadSettings() = AppSettings(
        voiceEnabled = prefs.getBoolean("voice", true),
        autoConnect = prefs.getBoolean("auto_connect", true),
        largeText = prefs.getBoolean("large_text", false),
        travelMode = TravelMode.values().firstOrNull { it.name == prefs.getString("travel_mode", "") }
            ?: TravelMode.WALKING,
        highContrast = prefs.getBoolean("high_contrast", false),
        haptics = prefs.getBoolean("haptics", true),
        announceConnection = prefs.getBoolean("announce_connection", true),
        detailedAnalysis = prefs.getBoolean("detailed_analysis", false),
        speechRate = SpeechRate.values().firstOrNull { it.name == prefs.getString("speech_rate", "") }
            ?: SpeechRate.NORMAL
    )

    fun saveSettings(settings: AppSettings) {
        prefs.edit()
            .putBoolean("voice", settings.voiceEnabled)
            .putBoolean("auto_connect", settings.autoConnect)
            .putBoolean("large_text", settings.largeText)
            .putString("travel_mode", settings.travelMode.name)
            .putBoolean("high_contrast", settings.highContrast)
            .putBoolean("haptics", settings.haptics)
            .putBoolean("announce_connection", settings.announceConnection)
            .putBoolean("detailed_analysis", settings.detailedAnalysis)
            .putString("speech_rate", settings.speechRate.name)
            .apply()
    }

    fun loadHistory(): List<HistoryItem> = try {
        val array = JSONArray(prefs.getString("history", "[]"))
        (0 until array.length()).map { i ->
            val item = array.getJSONObject(i)
            HistoryItem(item.optString("title"), item.optString("date"), item.optString("text"))
        }
    } catch (_: Exception) {
        emptyList()
    }

    fun saveHistory(items: List<HistoryItem>) {
        val array = JSONArray()
        items.forEach { array.put(JSONObject().put("title", it.title).put("date", it.date).put("text", it.text)) }
        prefs.edit().putString("history", array.toString()).apply()
    }

    fun saveLastImage(jpeg: ByteArray, capturedAt: String) {
        try {
            imageFile.writeBytes(jpeg)
            prefs.edit().putString("last_image_time", capturedAt).putString("last_image_analysis", "").apply()
        } catch (_: Exception) {
        }
    }

    fun saveLastImageAnalysis(text: String) {
        prefs.edit().putString("last_image_analysis", text).apply()
    }

    fun loadLastImage(): LastImage? {
        if (!imageFile.exists()) return null
        return try {
            val bitmap = decodeScaled(imageFile.readBytes()) ?: return null
            LastImage(
                bitmap = bitmap,
                capturedAt = prefs.getString("last_image_time", "") ?: "",
                analysis = prefs.getString("last_image_analysis", "") ?: ""
            )
        } catch (_: Exception) {
            null
        }
    }

    fun loadLastImageBytes(): ByteArray? = try {
        if (imageFile.exists()) imageFile.readBytes() else null
    } catch (_: Exception) {
        null
    }

    fun clearLastImage() {
        try { imageFile.delete() } catch (_: Exception) {}
        prefs.edit().remove("last_image_time").remove("last_image_analysis").apply()
    }
}

package com.example.access.ui

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.heading
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState
import com.example.access.backend.AnalysisStage

@Composable
internal fun HomeScreen(state: AccessUiState, actions: AccessActions, onNavigate: (Page) -> Unit) {
    var showLastImage by remember { mutableStateOf(false) }
    val c = Ax.colors

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(14.dp))
        HomeHeader(hasImage = state.lastImage != null, onImage = { showLastImage = true })
        Spacer(Modifier.height(18.dp))
        ConnectionCard(state, actions)
        Spacer(Modifier.height(28.dp))

        AnalyzeButton(state.stage) { actions.requestAnalysis() }
        Spacer(Modifier.height(14.dp))
        Text(
            stageMessage(state.stage),
            modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
            color = if (state.stage == AnalysisStage.IDLE) c.muted else c.accent,
            fontSize = 15.sp,
            fontWeight = if (state.stage == AnalysisStage.IDLE) FontWeight.Normal else FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        if (state.lastAnalysis.isNotBlank()) {
            Spacer(Modifier.height(22.dp))
            ResultCard(state, actions)
        }

        Spacer(Modifier.height(22.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            QuickAction("Ir para...", "Falar um destino e abrir a rota", IconKind.Route, Modifier.weight(1f)) {
                actions.startVoiceRoute()
            }
            QuickAction("Assistente", "Falar com o assistente", IconKind.Mic, Modifier.weight(1f)) {
                actions.startVoiceAssistant()
                onNavigate(Page.Assistant)
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showLastImage) {
        LastImageDialog(
            image = state.lastImage,
            onDismiss = { showLastImage = false },
            onDelete = { actions.clearLastImage() },
            onSpeak = { actions.speakText(it) }
        )
    }
}

private fun stageMessage(stage: AnalysisStage) = when (stage) {
    AnalysisStage.IDLE -> "Aponte a bengala para a frente e toque em analisar."
    AnalysisStage.REQUESTING -> "Pedindo a foto à bengala..."
    AnalysisStage.RECEIVING -> "Recebendo a imagem..."
    AnalysisStage.ANALYZING -> "Analisando o ambiente..."
}

@Composable
private fun HomeHeader(hasImage: Boolean, onImage: () -> Unit) {
    val c = Ax.colors
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(
                "ACCESS",
                modifier = Modifier.semantics { heading() },
                fontSize = 30.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 5.sp,
                color = c.text
            )
            Text("Tecnologia para mais autonomia", fontSize = 13.sp, color = c.muted)
        }
        Box(
            Modifier
                .size(56.dp)
                .alpha(if (hasImage) 1f else 0.55f)
                .clip(CircleShape)
                .background(c.surface)
                .border(if (c.highContrast) 2.dp else 1.dp, c.outline, CircleShape)
                .semantics(mergeDescendants = true) { contentDescription = "Ver a última imagem analisada" }
                .clickable(role = Role.Button, onClick = onImage),
            contentAlignment = Alignment.Center
        ) {
            AxIcon(IconKind.Image, c.accent, iconSize = 26.dp)
        }
    }
}

@Composable
private fun ConnectionCard(state: AccessUiState, actions: AccessActions) {
    val c = Ax.colors
    val statusColor = if (state.isConnected) c.success else c.warning
    AxCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(14.dp).background(statusColor, CircleShape))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("BENGALA TECH", fontWeight = FontWeight.Bold, fontSize = 12.sp, letterSpacing = 1.4.sp, color = c.muted)
                Text(
                    if (state.isConnected) "Conectada" else "Desconectada",
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 19.sp,
                    color = c.text
                )
                Text(
                    state.connectionStatus,
                    modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite },
                    color = c.muted,
                    fontSize = 14.sp,
                    lineHeight = 19.sp
                )
            }
            TextButton(
                onClick = { actions.reconnect() },
                modifier = Modifier.heightIn(min = 52.dp)
            ) {
                Text(
                    if (state.isConnected) "Reconectar" else "Conectar",
                    color = c.accent,
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

/** Anima o anel enquanto há análise em andamento. Fora disso nada anima (economiza bateria). */
@Composable
private fun rememberPulse(): Float {
    val transition = rememberInfiniteTransition(label = "pulse")
    val value by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1500, easing = LinearEasing), RepeatMode.Restart),
        label = "pulse"
    )
    return value
}

@Composable
private fun AnalyzeButton(stage: AnalysisStage, onClick: () -> Unit) {
    val c = Ax.colors
    val busy = stage != AnalysisStage.IDLE
    val pulse = if (busy) rememberPulse() else 0f
    val label = when (stage) {
        AnalysisStage.IDLE -> "ANALISAR"
        AnalysisStage.REQUESTING -> "CAPTURANDO"
        AnalysisStage.RECEIVING -> "RECEBENDO"
        AnalysisStage.ANALYZING -> "ANALISANDO"
    }

    Box(
        Modifier
            .size(252.dp)
            .semantics(mergeDescendants = true) {
                contentDescription = "Analisar o ambiente"
                stateDescription = if (busy) label.lowercase() else "pronto"
            }
            .clip(CircleShape)
            .clickable(enabled = !busy, role = Role.Button, onClickLabel = "capturar e analisar o ambiente", onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val outer = size.minDimension / 2f
            drawCircle(c.accent.copy(alpha = 0.10f), radius = outer)
            drawCircle(c.accent.copy(alpha = 0.18f), radius = outer * 0.88f)
            if (busy) {
                drawCircle(
                    c.accent.copy(alpha = 0.55f * (1f - pulse)),
                    radius = outer * (0.74f + 0.26f * pulse),
                    style = Stroke(width = 5.dp.toPx())
                )
            }
            val disc = if (busy) c.surfaceHigh else c.accent
            drawCircle(
                brush = Brush.linearGradient(listOf(if (busy) c.surfaceHigh else c.accentAlt, disc)),
                radius = outer * 0.74f
            )
            if (c.highContrast) {
                drawCircle(c.text, radius = outer * 0.74f, style = Stroke(width = 3.dp.toPx()))
            }
        }
        val onDisc = if (busy) c.text else c.onAccent
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            AxIcon(IconKind.Lens, onDisc, iconSize = 62.dp)
            Spacer(Modifier.height(6.dp))
            Text(label, color = onDisc, fontWeight = FontWeight.ExtraBold, fontSize = 21.sp, letterSpacing = 1.6.sp)
        }
    }
}

@Composable
private fun ResultCard(state: AccessUiState, actions: AccessActions) {
    val c = Ax.colors
    // Com a voz ligada o texto já é falado; o leitor de tela só o anuncia se a voz estiver desligada.
    val announce = if (state.settings.voiceEnabled) Modifier else Modifier.semantics { liveRegion = LiveRegionMode.Polite }
    AxCard(highlight = true) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            SectionLabel("Última análise", Modifier.weight(1f))
            state.lastImage?.capturedAt?.takeIf { it.isNotBlank() }?.let {
                Text(it, color = c.muted, fontSize = 13.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text(state.lastAnalysis, modifier = announce, color = c.text, fontSize = 19.sp, lineHeight = 28.sp)
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            SecondaryButton("Repetir", { actions.repeatLastAnalysis() }, Modifier.weight(1f), IconKind.Speaker)
            SecondaryButton("Parar voz", { actions.stopSpeaking() }, Modifier.weight(1f), IconKind.Stop)
        }
    }
}

@Composable
private fun QuickAction(title: String, description: String, icon: IconKind, modifier: Modifier, onClick: () -> Unit) {
    val c = Ax.colors
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .heightIn(min = 96.dp)
            .clip(shape)
            .background(c.surface)
            .border(if (c.highContrast) 2.dp else 1.dp, c.outline, shape)
            .semantics(mergeDescendants = true) { contentDescription = description }
            .clickable(role = Role.Button, onClick = onClick)
            .padding(16.dp),
        horizontalAlignment = Alignment.Start,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        AxIcon(icon, c.accent, iconSize = 30.dp)
        Spacer(Modifier.height(10.dp))
        Text(title, color = c.text, fontWeight = FontWeight.Bold, fontSize = 17.sp)
    }
}

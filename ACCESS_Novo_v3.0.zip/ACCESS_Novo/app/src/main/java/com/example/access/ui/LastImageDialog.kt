package com.example.access.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.LastImage

@Composable
internal fun LastImageDialog(
    image: LastImage?,
    onDismiss: () -> Unit,
    onDelete: () -> Unit,
    onSpeak: (String) -> Unit
) {
    val c = Ax.colors
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = c.surface,
        shape = RoundedCornerShape(26.dp),
        title = { Text("Última imagem analisada", color = c.text, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp) },
        text = {
            if (image == null) {
                Text("Nenhuma imagem foi analisada ainda. Toque em ANALISAR para capturar uma.", color = c.muted, fontSize = 16.sp, lineHeight = 23.sp)
            } else {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Image(
                        bitmap = image.bitmap.asImageBitmap(),
                        contentDescription = "Foto tirada pela bengala na última análise",
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)),
                        contentScale = ContentScale.FillWidth
                    )
                    Spacer(Modifier.height(10.dp))
                    if (image.capturedAt.isNotBlank()) {
                        Text(image.capturedAt, color = c.muted, fontSize = 14.sp)
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(
                        image.analysis.ifBlank { "Analisando..." },
                        color = c.text,
                        fontSize = 17.sp,
                        lineHeight = 25.sp
                    )
                    if (image.analysis.isNotBlank()) {
                        TextButton(onClick = { onSpeak(image.analysis) }) {
                            Text("Ouvir a descrição", color = c.accent, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar", color = c.accent, fontWeight = FontWeight.Bold) } },
        dismissButton = {
            if (image != null) {
                TextButton(onClick = { onDelete(); onDismiss() }) { Text("Apagar imagem", color = c.muted) }
            }
        }
    )
}

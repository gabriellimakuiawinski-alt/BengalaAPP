package com.example.access.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState
import com.example.access.backend.ChatMessage

/** Assistente de voz dentro do app: não abre o Gemini, usa a mesma IA do ACCESS. */
@Composable
internal fun AssistantScreen(state: AccessUiState, actions: AccessActions) {
    val c = Ax.colors
    var typed by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val messages = state.assistantMessages
    val rowCount = messages.size + (if (state.assistantBusy) 1 else 0) + (if (messages.isEmpty() && !state.assistantBusy) 1 else 0)

    LaunchedEffect(rowCount) {
        if (rowCount > 0) listState.animateScrollToItem(rowCount - 1)
    }

    fun send() {
        if (typed.isNotBlank() && !state.assistantBusy) {
            actions.askAssistant(typed)
            typed = ""
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
            Box(Modifier.weight(1f)) { PageHeader("Assistente", "Pergunte por voz ou texto, sem sair do app.") }
            if (messages.isNotEmpty()) {
                TextButton(onClick = { actions.clearAssistantChat() }) { Text("Limpar", color = c.muted, fontSize = 15.sp) }
            }
        }

        LazyColumn(
            Modifier.weight(1f).fillMaxWidth().padding(vertical = 12.dp),
            state = listState,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty() && !state.assistantBusy) {
                item { EmptyPanel("Toque em FALAR e faça sua pergunta, ou digite abaixo.") }
            }
            items(messages) { MessageBubble(it) }
            if (state.assistantBusy) {
                item { Text("Pensando...", color = c.muted, fontSize = 15.sp) }
            }
        }

        // A imagem só vai junto se a pessoa ligar esta chave, e vale para a próxima pergunta.
        val canUseImage = state.lastImage != null
        val useImage = state.assistantUseImage && canUseImage
        Row(
            Modifier
                .fillMaxWidth()
                .toggleable(value = useImage, enabled = canUseImage, role = Role.Switch, onValueChange = { actions.setAssistantUseImage(it) })
                .padding(vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Enviar a última imagem na próxima pergunta", color = c.text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    if (!canUseImage) "Ainda não há imagem analisada." else "A imagem vai à IA junto com a pergunta.",
                    color = c.muted, fontSize = 13.sp
                )
            }
            Switch(
                checked = useImage,
                onCheckedChange = null,
                enabled = canUseImage,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = c.onAccent,
                    checkedTrackColor = c.accent,
                    uncheckedThumbColor = c.muted,
                    uncheckedTrackColor = c.surfaceHigh,
                    uncheckedBorderColor = c.outline
                )
            )
        }

        PrimaryButton(
            "FALAR COM O ASSISTENTE",
            { actions.startVoiceAssistant() },
            Modifier.fillMaxWidth(),
            IconKind.Mic,
            enabled = !state.assistantBusy
        )
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = typed,
                onValueChange = { typed = it },
                modifier = Modifier.weight(1f),
                shape = RoundedCornerShape(16.dp),
                placeholder = { Text("Ou digite sua pergunta") },
                singleLine = true,
                textStyle = TextStyle(fontSize = 17.sp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
                colors = axTextFieldColors()
            )
            SecondaryButton("Enviar", { send() }, Modifier, IconKind.Send, enabled = typed.isNotBlank() && !state.assistantBusy)
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage) {
    val c = Ax.colors
    val fromUser = message.fromUser
    val shape = RoundedCornerShape(
        topStart = 20.dp, topEnd = 20.dp,
        bottomStart = if (fromUser) 20.dp else 6.dp,
        bottomEnd = if (fromUser) 6.dp else 20.dp
    )
    Box(Modifier.fillMaxWidth(), contentAlignment = if (fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
        Column(
            Modifier
                .widthIn(max = 320.dp)
                .background(if (fromUser) c.accent else c.surface, shape)
                .then(if (fromUser) Modifier else Modifier.border(if (c.highContrast) 2.dp else 1.dp, c.outline, shape))
                .padding(14.dp)
        ) {
            Text(
                if (fromUser) "Você" else "Assistente",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 0.8.sp,
                color = if (fromUser) c.onAccent.copy(alpha = 0.75f) else c.accent
            )
            if (message.withImage) {
                Text("com a última imagem", fontSize = 12.sp, color = if (fromUser) c.onAccent.copy(alpha = 0.75f) else c.muted)
            }
            Spacer(Modifier.height(4.dp))
            Text(
                message.text,
                color = if (fromUser) c.onAccent else c.text,
                fontSize = 17.sp,
                lineHeight = 24.sp
            )
        }
    }
}

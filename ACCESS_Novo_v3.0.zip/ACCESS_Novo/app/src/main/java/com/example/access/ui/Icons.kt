package com.example.access.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

internal enum class IconKind {
    Home, History, Route, Assistant, Settings, Lens, Mic, Image, Check, Warning, Refresh, Speaker, Stop, Send, Trash
}

/**
 * Ícones desenhados em código (sem emojis): ficam nítidos em qualquer tamanho e têm a cor do tema.
 * São decorativos: o leitor de tela lê o texto do botão, nunca o desenho.
 */
@Composable
internal fun AxIcon(kind: IconKind, tint: Color, modifier: Modifier = Modifier, iconSize: Dp = 24.dp) {
    Canvas(modifier.size(iconSize)) {
        val u = this.size.minDimension / 24f
        val stroke = Stroke(width = 2f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun p(x: Float, y: Float) = Offset(x * u, y * u)
        fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
            drawLine(tint, p(x1, y1), p(x2, y2), strokeWidth = 2f * u, cap = StrokeCap.Round)
        fun poly(vararg pts: Float, close: Boolean = false, fill: Boolean = false) {
            val path = Path()
            path.moveTo(pts[0] * u, pts[1] * u)
            var i = 2
            while (i < pts.size) {
                path.lineTo(pts[i] * u, pts[i + 1] * u)
                i += 2
            }
            if (close) path.close()
            drawPath(path, tint, style = if (fill) Fill else stroke)
        }

        when (kind) {
            IconKind.Home -> {
                poly(3f, 11.5f, 12f, 3.5f, 21f, 11.5f)
                poly(5.5f, 9.5f, 5.5f, 20f, 18.5f, 20f, 18.5f, 9.5f)
                poly(10f, 20f, 10f, 14.5f, 14f, 14.5f, 14f, 20f)
            }
            IconKind.History -> {
                drawCircle(tint, radius = 9f * u, center = p(12f, 12f), style = stroke)
                poly(12f, 7f, 12f, 12f, 15.5f, 14f)
            }
            IconKind.Route -> {
                val pin = Path().apply {
                    moveTo(12f * u, 21f * u)
                    cubicTo(7f * u, 16f * u, 5f * u, 13f * u, 5f * u, 10f * u)
                    cubicTo(5f * u, 6f * u, 8f * u, 3.5f * u, 12f * u, 3.5f * u)
                    cubicTo(16f * u, 3.5f * u, 19f * u, 6f * u, 19f * u, 10f * u)
                    cubicTo(19f * u, 13f * u, 17f * u, 16f * u, 12f * u, 21f * u)
                    close()
                }
                drawPath(pin, tint, style = stroke)
                drawCircle(tint, radius = 2.6f * u, center = p(12f, 10f), style = stroke)
            }
            IconKind.Assistant -> {
                poly(12f, 3f, 14f, 10f, 21f, 12f, 14f, 14f, 12f, 21f, 10f, 14f, 3f, 12f, 10f, 10f, close = true)
            }
            IconKind.Settings -> {
                line(4f, 6f, 20f, 6f)
                line(4f, 12f, 20f, 12f)
                line(4f, 18f, 20f, 18f)
                drawCircle(tint, radius = 2.6f * u, center = p(9f, 6f))
                drawCircle(tint, radius = 2.6f * u, center = p(15f, 12f))
                drawCircle(tint, radius = 2.6f * u, center = p(8f, 18f))
            }
            IconKind.Lens -> {
                drawCircle(tint, radius = 9.5f * u, center = p(12f, 12f), style = Stroke(width = 1.8f * u))
                drawCircle(tint, radius = 5.5f * u, center = p(12f, 12f), style = Stroke(width = 1.8f * u))
                drawCircle(tint, radius = 2.2f * u, center = p(12f, 12f))
            }
            IconKind.Mic -> {
                drawRoundRect(tint, p(9f, 3f), Size(6f * u, 11f * u), CornerRadius(3f * u, 3f * u), style = stroke)
                drawArc(tint, 0f, 180f, false, p(5.5f, 7.5f), Size(13f * u, 11f * u), style = stroke)
                line(12f, 18.5f, 12f, 21f)
                line(9f, 21f, 15f, 21f)
            }
            IconKind.Image -> {
                drawRoundRect(tint, p(3.5f, 4.5f), Size(17f * u, 15f * u), CornerRadius(2.5f * u, 2.5f * u), style = stroke)
                drawCircle(tint, radius = 1.6f * u, center = p(9f, 10f))
                poly(4f, 18f, 10f, 13f, 14f, 16.5f, 16.5f, 14f, 20f, 18f)
            }
            IconKind.Check -> poly(5f, 12.5f, 10f, 17.5f, 19f, 7f)
            IconKind.Warning -> {
                poly(12f, 3.5f, 21.5f, 20f, 2.5f, 20f, close = true)
                line(12f, 10f, 12f, 14.5f)
                drawCircle(tint, radius = 1.1f * u, center = p(12f, 17.3f))
            }
            IconKind.Refresh -> {
                drawArc(tint, -50f, 290f, false, p(4.5f, 4.5f), Size(15f * u, 15f * u), style = stroke)
                poly(19f, 3.5f, 19f, 8.5f, 14f, 8.5f)
            }
            IconKind.Speaker -> {
                poly(4f, 9.5f, 8f, 9.5f, 13f, 5f, 13f, 19f, 8f, 14.5f, 4f, 14.5f, close = true)
                drawArc(tint, -45f, 90f, false, p(8.5f, 7.5f), Size(9f * u, 9f * u), style = stroke)
                drawArc(tint, -45f, 90f, false, p(5f, 4f), Size(16f * u, 16f * u), style = stroke)
            }
            IconKind.Stop -> {
                drawRoundRect(tint, p(6f, 6f), Size(12f * u, 12f * u), CornerRadius(2.5f * u, 2.5f * u))
            }
            IconKind.Send -> poly(3f, 11f, 21f, 3f, 14f, 21f, 11f, 13f, close = true)
            IconKind.Trash -> {
                line(4f, 7f, 20f, 7f)
                poly(9f, 7f, 9f, 4.5f, 15f, 4.5f, 15f, 7f)
                poly(6f, 7f, 7f, 20f, 17f, 20f, 18f, 7f)
            }
        }
    }
}

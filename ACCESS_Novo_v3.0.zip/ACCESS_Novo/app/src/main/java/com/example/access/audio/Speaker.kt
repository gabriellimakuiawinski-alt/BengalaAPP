package com.example.access.audio

import android.content.Context
import android.media.AudioAttributes
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Voz do app (Text-to-Speech em português do Brasil). */
internal class Speaker(context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()
    @Volatile private var ready = false
    @Volatile private var rate = 1.0f
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                val engine = tts
                engine?.language = Locale("pt", "BR")
                // Fala pelo canal de acessibilidade: o volume segue o ajuste do leitor de tela.
                engine?.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ASSISTANCE_ACCESSIBILITY)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                engine?.setSpeechRate(rate)
                engine?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { finish(utteranceId) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { finish(utteranceId) }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        // Frase interrompida por outra: descarta o callback sem executá-lo.
                        if (utteranceId != null) callbacks.remove(utteranceId)
                    }
                })
                ready = true
            }
        }
    }

    private fun finish(utteranceId: String?) {
        val callback = utteranceId?.let { callbacks.remove(it) } ?: return
        main.post { callback() }
    }

    fun setRate(value: Float) {
        rate = value
        if (ready) tts?.setSpeechRate(value)
    }

    /**
     * Fala o texto. [onFinished] roda quando a fala termina (ou imediatamente se a voz não estiver pronta).
     * Com [interrupt] falso, a frase entra na fila em vez de cortar a que está sendo dita.
     */
    fun speak(text: String, interrupt: Boolean = true, onFinished: (() -> Unit)? = null) {
        val engine = tts
        if (!ready || engine == null || text.isBlank()) {
            onFinished?.let { main.post(it) }
            return
        }
        val id = "access-" + System.nanoTime()
        if (onFinished != null) callbacks[id] = onFinished
        val mode = if (interrupt) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
        val result = engine.speak(text, mode, null, id)
        if (result != TextToSpeech.SUCCESS) finish(id)
    }

    fun stop() {
        callbacks.clear()
        if (ready) tts?.stop()
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
    }
}

package com.example.access.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState
import com.example.access.backend.TravelMode

@Composable
internal fun NavigationScreen(state: AccessUiState, actions: AccessActions) {
    val c = Ax.colors
    var typedDestination by remember { mutableStateOf("") }

    fun go() {
        if (typedDestination.isNotBlank()) actions.openRoute(typedDestination) else actions.startVoiceRoute()
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(0.dp)
    ) {
        PageHeader("Rotas", "Diga ou digite o destino e o ACCESS abre o trajeto no Google Maps.")
        Spacer(Modifier.height(20.dp))

        SectionLabel("Como você vai")
        Spacer(Modifier.height(8.dp))
        TravelModeSelector(state.settings.travelMode, { actions.setTravelMode(it) }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(8.dp))
        Text(
            if (state.settings.travelMode == TravelMode.TRANSIT) {
                "No transporte público o Maps mostra as opções: escolha uma na tela do Maps. O ACCESS não volta sozinho nesse modo."
            } else {
                "Dica: você também pode falar o modo, por exemplo \"Avenida Paulista de ônibus\"."
            },
            color = c.muted, fontSize = 14.sp, lineHeight = 20.sp
        )

        Spacer(Modifier.height(22.dp))
        PrimaryButton("Falar o destino", { actions.startVoiceRoute() }, Modifier.fillMaxWidth(), IconKind.Mic)

        Spacer(Modifier.height(22.dp))
        SectionLabel("Ou digite")
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = typedDestination,
            onValueChange = { typedDestination = it },
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            label = { Text("Para onde você quer ir?") },
            placeholder = { Text("Ex.: Avenida Paulista, São Paulo") },
            singleLine = true,
            textStyle = androidx.compose.ui.text.TextStyle(fontSize = 18.sp),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = { go() }),
            colors = axTextFieldColors()
        )
        Spacer(Modifier.height(12.dp))
        SecondaryButton(
            if (typedDestination.isBlank()) "Abrir o Google Maps" else "Buscar rota (${state.settings.travelMode.label})",
            { if (typedDestination.isBlank()) actions.openGoogleMaps() else go() },
            Modifier.fillMaxWidth(),
            IconKind.Route
        )

        if (state.lastDestination.isNotBlank()) {
            Spacer(Modifier.height(24.dp))
            AxCard(highlight = true) {
                SectionLabel("Último destino")
                Spacer(Modifier.height(6.dp))
                Text(state.lastDestination, color = c.text, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, lineHeight = 26.sp)
                Spacer(Modifier.height(12.dp))
                SecondaryButton("Abrir esta rota de novo", { actions.openRoute(state.lastDestination) }, Modifier.fillMaxWidth(), IconKind.Refresh)
            }
        }

        Spacer(Modifier.height(18.dp))
        Text(
            "A navegação por voz depende do reconhecimento de fala do Android e do Google Maps instalado.",
            color = c.muted, fontSize = 13.sp, lineHeight = 18.sp
        )
    }
}

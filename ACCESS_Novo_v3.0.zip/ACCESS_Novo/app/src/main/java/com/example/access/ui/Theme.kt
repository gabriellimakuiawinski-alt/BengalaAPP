package com.example.access.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import com.example.access.backend.AppSettings

/** Todas as cores do app. Telas nunca usam cores soltas: sempre `Ax.colors`. */
internal data class AccessColors(
    val bgTop: Color,
    val bgBottom: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val outline: Color,
    val accent: Color,
    val accentAlt: Color,
    val onAccent: Color,
    val text: Color,
    val muted: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
    val highContrast: Boolean
)

/** Tema padrão: azul-noite com ciano luminoso. Texto sobre fundo com contraste acima de 7:1. */
internal val DarkAccessColors = AccessColors(
    bgTop = Color(0xFF0B1424),
    bgBottom = Color(0xFF070D18),
    surface = Color(0xFF14233A),
    surfaceHigh = Color(0xFF1C2F4D),
    outline = Color(0xFF2C4468),
    accent = Color(0xFF2BD4E6),
    accentAlt = Color(0xFF5B9CFF),
    onAccent = Color(0xFF04202A),
    text = Color(0xFFF3F7FC),
    muted = Color(0xFFB4C2D6),
    success = Color(0xFF3DDC97),
    warning = Color(0xFFFFC857),
    error = Color(0xFFFF7B7B),
    highContrast = false
)

/** Alto contraste: preto puro, amarelo e branco, com bordas grossas. */
internal val HighContrastColors = AccessColors(
    bgTop = Color(0xFF000000),
    bgBottom = Color(0xFF000000),
    surface = Color(0xFF000000),
    surfaceHigh = Color(0xFF1A1A1A),
    outline = Color(0xFFFFFFFF),
    accent = Color(0xFFFFD60A),
    accentAlt = Color(0xFFFFD60A),
    onAccent = Color(0xFF000000),
    text = Color(0xFFFFFFFF),
    muted = Color(0xFFE6E6E6),
    success = Color(0xFF5CFF9D),
    warning = Color(0xFFFFD60A),
    error = Color(0xFFFF8A8A),
    highContrast = true
)

internal val LocalAccessColors = staticCompositionLocalOf { DarkAccessColors }

internal object Ax {
    val colors: AccessColors
        @Composable
        @ReadOnlyComposable
        get() = LocalAccessColors.current
}

/**
 * Tema do app. [AppSettings.largeText] amplia TODO o texto de uma vez (não só alguns campos) e
 * [AppSettings.highContrast] troca a paleta inteira.
 */
@Composable
fun AccessTheme(settings: AppSettings, content: @Composable () -> Unit) {
    val colors = if (settings.highContrast) HighContrastColors else DarkAccessColors
    val density = LocalDensity.current
    val extraScale = if (settings.largeText) 1.3f else 1f
    CompositionLocalProvider(
        LocalAccessColors provides colors,
        LocalDensity provides Density(density.density, density.fontScale * extraScale)
    ) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = colors.accent,
                onPrimary = colors.onAccent,
                secondary = colors.accentAlt,
                background = colors.bgTop,
                onBackground = colors.text,
                surface = colors.surface,
                onSurface = colors.text,
                surfaceVariant = colors.surfaceHigh,
                onSurfaceVariant = colors.muted,
                outline = colors.outline,
                error = colors.error
            ),
            content = content
        )
    }
}

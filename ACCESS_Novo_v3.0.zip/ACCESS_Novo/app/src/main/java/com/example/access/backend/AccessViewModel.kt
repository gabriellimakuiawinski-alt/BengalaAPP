package com.example.access.backend

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Ponte entre a interface e o núcleo do app. A interface só enxerga [AccessUiState] e [AccessActions];
 * os métodos "on..." são usados apenas pelo shell (MainActivity).
 */
class AccessViewModel(application: Application) : AndroidViewModel(application), AccessActions {
    init {
        AccessRepository.init(application)
    }

    val state: StateFlow<AccessUiState> = AccessRepository.state
    val events: SharedFlow<AccessEvent> = AccessRepository.events

    // Chamados pelo shell
    fun onPermissionsHandled() = AccessRepository.startBluetoothService()
    fun onResume() = AccessRepository.refreshPermissions()
    fun onSpeechResult(heard: String?) = AccessRepository.onSpeechResult(heard)
    fun onSpeechFailed() = AccessRepository.onSpeechFailed()

    // AccessActions
    override fun requestAnalysis() = AccessRepository.requestAnalysis()
    override fun reconnect() = AccessRepository.startBluetoothService(reconnect = true)
    override fun repeatLastAnalysis() = AccessRepository.repeatLastAnalysis()
    override fun speakText(text: String) = AccessRepository.speakText(text)
    override fun stopSpeaking() = AccessRepository.stopSpeaking()
    override fun startVoiceRoute() = AccessRepository.startVoiceRoute()
    override fun openRoute(destination: String) = AccessRepository.openRoute(destination)
    override fun setTravelMode(mode: TravelMode) = AccessRepository.setTravelMode(mode)
    override fun openGoogleMaps() = AccessRepository.openGoogleMaps()
    override fun openOverlaySettings() = AccessRepository.openOverlaySettings()
    override fun startVoiceAssistant() = AccessRepository.startVoiceAssistant()
    override fun askAssistant(text: String) = AccessRepository.askAssistant(text)
    override fun setAssistantUseImage(enabled: Boolean) = AccessRepository.setAssistantUseImage(enabled)
    override fun clearAssistantChat() = AccessRepository.clearAssistantChat()
    override fun clearHistory() = AccessRepository.clearHistory()
    override fun clearLastImage() = AccessRepository.clearLastImage()
    override fun setVoiceEnabled(enabled: Boolean) = AccessRepository.updateSettings { it.copy(voiceEnabled = enabled) }
    override fun setAutoConnect(enabled: Boolean) = AccessRepository.updateSettings { it.copy(autoConnect = enabled) }
    override fun setLargeText(enabled: Boolean) = AccessRepository.updateSettings { it.copy(largeText = enabled) }
    override fun setHighContrast(enabled: Boolean) = AccessRepository.updateSettings { it.copy(highContrast = enabled) }
    override fun setHaptics(enabled: Boolean) = AccessRepository.updateSettings { it.copy(haptics = enabled) }
    override fun setAnnounceConnection(enabled: Boolean) = AccessRepository.updateSettings { it.copy(announceConnection = enabled) }
    override fun setDetailedAnalysis(enabled: Boolean) = AccessRepository.updateSettings { it.copy(detailedAnalysis = enabled) }
    override fun setSpeechRate(rate: SpeechRate) = AccessRepository.updateSettings { it.copy(speechRate = rate) }
}

package com.example.access.bluetooth

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Conexão Bluetooth Classic (SPP) com a BengalaTech, em serviço de primeiro plano.
 *
 * Responsabilidade ÚNICA: manter o link, enviar comandos e entregar mensagens.
 * Não chama IA, não fala, não grava histórico e não conhece telas: tudo isso é feito por
 * quem estiver registrado em [BengalaBridge].
 */
class AccessBluetoothService : Service() {
    companion object {
        const val ACTION_REQUEST_ANALYSIS = "com.example.access.REQUEST_ANALYSIS"
        const val ACTION_RECONNECT = "com.example.access.RECONNECT"
        const val CHANNEL_ID = "access_connection"
        private const val NOTIFICATION_ID = 1001
        private const val DEVICE_NAME = "BengalaTech"
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

        private const val MIN_BACKOFF_MS = 1_500L
        private const val MAX_BACKOFF_MS = 15_000L
        private const val STALL_TIMEOUT_MS = 8_000L
        private const val PHOTO_REPLY_TIMEOUT_MS = 15_000L
        private const val PENDING_PHOTO_VALID_MS = 30_000L
        private const val DOUBLE_TAP_GUARD_MS = 2_500L
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private val socketLock = Any()

    @Volatile private var running = false
    @Volatile private var connected = false
    @Volatile private var reconnectNow = false
    @Volatile private var photoRequestedAt = 0L
    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var output: OutputStream? = null
    @Volatile private var protocol: BengalaProtocol? = null

    private var worker: Thread? = null
    private var writer: ExecutorService? = null
    private var lastNotificationText = ""

    private val listener: BengalaListener? get() = BengalaBridge.listener

    /** Vigia a cada segundo: imagem travada no meio do caminho e pedido de foto sem resposta. */
    private val watchdog = object : Runnable {
        override fun run() {
            if (!running) return
            val proto = protocol
            if (proto != null && proto.isStalled(STALL_TIMEOUT_MS)) {
                photoRequestedAt = 0L
                listener?.onPhotoFailed("A imagem parou de chegar. Reconectando à bengala.")
                closeConnection()
            }
            val requestedAt = photoRequestedAt
            if (requestedAt != 0L && connected && proto?.transferActive != true &&
                System.currentTimeMillis() - requestedAt > PHOTO_REPLY_TIMEOUT_MS
            ) {
                photoRequestedAt = 0L
                listener?.onPhotoFailed("A bengala não respondeu ao pedido de foto.")
            }
            mainHandler.postDelayed(this, 1_000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        writer = Executors.newSingleThreadExecutor()
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Conexão ACCESS", NotificationManager.IMPORTANCE_LOW)
        )
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (!startAsForeground()) {
            stopSelf()
            return START_NOT_STICKY
        }
        when (intent?.action) {
            ACTION_REQUEST_ANALYSIS -> requestPhoto()
            ACTION_RECONNECT -> {
                reconnectNow = true
                closeConnection()
                worker?.interrupt()
            }
        }
        if (worker?.isAlive != true) {
            running = true
            worker = Thread { connectionLoop() }.apply { name = "ACCESS-Bluetooth"; start() }
            mainHandler.removeCallbacks(watchdog)
            mainHandler.postDelayed(watchdog, 1_000L)
        }
        return START_STICKY
    }

    /** No Android 14+ o serviço "connectedDevice" exige a permissão Bluetooth já concedida. */
    private fun startAsForeground(): Boolean = try {
        startForeground(NOTIFICATION_ID, buildNotification(lastNotificationText.ifBlank { "Mantendo conexão com a bengala" }))
        true
    } catch (e: SecurityException) {
        listener?.onConnectionChanged("Permissão Bluetooth necessária", false)
        false
    } catch (e: Exception) {
        listener?.onConnectionChanged("Não foi possível manter a conexão em segundo plano", false)
        false
    }

    // ---------- Pedido de foto ----------

    private fun requestPhoto() {
        val now = System.currentTimeMillis()
        if (protocol?.transferActive == true) return
        if (photoRequestedAt != 0L && now - photoRequestedAt < DOUBLE_TAP_GUARD_MS) return
        photoRequestedAt = now
        listener?.onPhotoRequested()
        if (connected) writeCommand(BengalaCommands.PHOTO, "Solicitando foto à bengala...")
        else publish("Bengala desconectada; tentando conectar...")
    }

    private fun writeCommand(command: String, statusAfter: String?) {
        try {
            writer?.execute {
                try {
                    val stream = output ?: throw IOException("Sem conexão")
                    stream.write(command.toByteArray(Charsets.US_ASCII))
                    stream.flush()
                    if (statusAfter != null) publish(statusAfter)
                } catch (e: Exception) {
                    publish("Falha ao enviar comando Bluetooth")
                    closeConnection()
                }
            }
        } catch (_: Exception) {
            // serviço sendo encerrado
        }
    }

    // ---------- Conexão ----------

    private fun connectionLoop() {
        var backoff = MIN_BACKOFF_MS
        while (running) {
            var wasConnected = false
            try {
                if (!BluetoothAccess.hasConnectPermission(this)) {
                    publish("Permissão Bluetooth necessária")
                    sleepQuietly(2_500)
                    continue
                }
                val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
                if (adapter == null || !adapter.isEnabled) {
                    publish("Ative o Bluetooth do celular")
                    sleepQuietly(2_500)
                    continue
                }
                val device = adapter.bondedDevices.firstOrNull { it.name == DEVICE_NAME }
                if (device == null) {
                    publish("Pareie '$DEVICE_NAME' nas configurações Bluetooth")
                    sleepQuietly(3_000)
                    continue
                }
                publish("Conectando à $DEVICE_NAME...")
                try { adapter.cancelDiscovery() } catch (_: SecurityException) {}
                val newSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket = newSocket
                newSocket.connect()

                output = newSocket.outputStream
                val proto = BengalaProtocol(
                    input = newSocket.inputStream,
                    onPhotoHeader = { size -> listener?.onPhotoStarted(size) }
                )
                protocol = proto
                connected = true
                wasConnected = true
                backoff = MIN_BACKOFF_MS
                publish("BengalaTech conectada")

                val pendingSince = photoRequestedAt
                if (pendingSince != 0L && System.currentTimeMillis() - pendingSince < PENDING_PHOTO_VALID_MS) {
                    writeCommand(BengalaCommands.PHOTO, "Solicitando foto à bengala...")
                } else {
                    photoRequestedAt = 0L
                }
                readLoop(proto)
            } catch (e: SecurityException) {
                publish("Permissão Bluetooth negada")
                sleepQuietly(2_500)
            } catch (e: Exception) {
                if (running && !reconnectNow) {
                    publish(if (wasConnected) "Conexão perdida; reconectando..." else "Não foi possível conectar; tentando de novo...")
                }
            } finally {
                connected = false
                closeConnection()
            }
            if (!running) break
            if (reconnectNow) {
                reconnectNow = false
                backoff = MIN_BACKOFF_MS
            } else {
                sleepQuietly(backoff)
                backoff = if (wasConnected) MIN_BACKOFF_MS else (backoff * 2).coerceAtMost(MAX_BACKOFF_MS)
            }
        }
    }

    private fun readLoop(proto: BengalaProtocol) {
        while (running && connected) {
            when (val message = proto.readMessage()) {
                is BengalaMessage.Photo -> {
                    photoRequestedAt = 0L
                    listener?.onPhotoReceived(message.jpeg)
                }
                is BengalaMessage.BadPhoto -> {
                    photoRequestedAt = 0L
                    listener?.onPhotoFailed(message.reason)
                }
                BengalaMessage.CameraError -> {
                    photoRequestedAt = 0L
                    listener?.onPhotoFailed("A câmera da bengala não conseguiu capturar a foto.")
                }
                is BengalaMessage.Status -> {
                    if (message.text == "PONG" || message.text == "ESP32_OK") publish("BengalaTech conectada")
                    listener?.onBengalaText(message.text)
                }
            }
        }
    }

    private fun closeConnection() {
        synchronized(socketLock) {
            connected = false
            val current = socket
            socket = null
            output = null
            protocol = null
            // Fechar o socket também destrava qualquer leitura em andamento.
            try { current?.close() } catch (_: Exception) {}
        }
    }

    private fun sleepQuietly(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) {}
    }

    // ---------- Notificação ----------

    private fun publish(value: String) {
        listener?.onConnectionChanged(value, connected)
        if (value == lastNotificationText) return
        lastNotificationText = value
        getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification(value))
    }

    private fun buildNotification(text: String): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val openApp = packageManager.getLaunchIntentForPackage(packageName)?.let {
            PendingIntent.getActivity(this, 0, it, flags)
        }
        // "Analisar agora" funciona também com a tela bloqueada.
        val analyze = PendingIntent.getForegroundService(
            this, 1,
            Intent(this, AccessBluetoothService::class.java).setAction(ACTION_REQUEST_ANALYSIS),
            flags
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ACCESS")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openApp)
            .addAction(android.R.drawable.ic_menu_camera, "Analisar agora", analyze)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        mainHandler.removeCallbacks(watchdog)
        closeConnection()
        worker?.interrupt()
        writer?.shutdownNow()
        super.onDestroy()
    }
}

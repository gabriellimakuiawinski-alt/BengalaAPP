package com.example.access.bluetooth

import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import org.junit.Assert.assertArrayEquals
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class BengalaProtocolTest {

    private fun jpeg(size: Int): ByteArray {
        val bytes = ByteArray(size) { (it % 200).toByte() }
        bytes[0] = 0xFF.toByte(); bytes[1] = 0xD8.toByte()
        bytes[size - 2] = 0xFF.toByte(); bytes[size - 1] = 0xD9.toByte()
        return bytes
    }

    private fun stream(vararg parts: ByteArray): ByteArrayInputStream {
        val out = ByteArrayOutputStream()
        parts.forEach { out.write(it) }
        return ByteArrayInputStream(out.toByteArray())
    }

    private fun text(value: String) = value.toByteArray(Charsets.US_ASCII)

    @Test
    fun readsPhotoWithExactSize() {
        val image = jpeg(1500)
        val protocol = BengalaProtocol(stream(text("FOTO:1500\n"), image))
        val message = protocol.readMessage()
        assertTrue(message is BengalaMessage.Photo)
        assertArrayEquals(image, (message as BengalaMessage.Photo).jpeg)
    }

    @Test
    fun jpegContainingNewlineBytesIsNotSplit() {
        val image = jpeg(600)
        image[100] = 10; image[101] = 10 // '\n' dentro dos dados
        val protocol = BengalaProtocol(stream(text("FOTO:600\n"), image, text("PONG\n")))
        assertArrayEquals(image, (protocol.readMessage() as BengalaMessage.Photo).jpeg)
        assertEquals("PONG", (protocol.readMessage() as BengalaMessage.Status).text)
    }

    @Test
    fun answersToPingStatusAndCameraError() {
        val protocol = BengalaProtocol(stream(text("PONG\r\nESP32_OK\nERRO_CAMERA\n")))
        assertEquals("PONG", (protocol.readMessage() as BengalaMessage.Status).text)
        assertEquals("ESP32_OK", (protocol.readMessage() as BengalaMessage.Status).text)
        assertTrue(protocol.readMessage() === BengalaMessage.CameraError)
    }

    @Test
    fun binaryGarbageDoesNotBreakTheLinkAndHeaderIsStillFound() {
        val garbage = ByteArray(700) { (128 + it % 100).toByte() }
        val image = jpeg(300)
        val protocol = BengalaProtocol(stream(garbage, text("FOTO:300\n"), image))
        assertArrayEquals(image, (protocol.readMessage() as BengalaMessage.Photo).jpeg)
    }

    @Test
    fun corruptedImageIsReportedInsteadOfSentToTheAi() {
        val broken = ByteArray(200) { 7 }
        val protocol = BengalaProtocol(stream(text("FOTO:200\n"), broken))
        assertTrue(protocol.readMessage() is BengalaMessage.BadPhoto)
    }

    @Test
    fun invalidSizeIsRejected() {
        assertTrue(BengalaProtocol(stream(text("FOTO:abc\n"))).readMessage() is BengalaMessage.BadPhoto)
        assertTrue(BengalaProtocol(stream(text("FOTO:0\n"))).readMessage() is BengalaMessage.BadPhoto)
        assertTrue(BengalaProtocol(stream(text("FOTO:99999999\n"))).readMessage() is BengalaMessage.BadPhoto)
    }

    @Test
    fun truncatedImageThrows() {
        val protocol = BengalaProtocol(stream(text("FOTO:1000\n"), jpeg(400)))
        try {
            protocol.readMessage()
            throw AssertionError("deveria lançar ProtocolException")
        } catch (expected: ProtocolException) {
            assertFalse(protocol.transferActive)
        }
    }

    @Test
    fun detectsStalledTransfer() {
        var now = 0L
        val pipe = java.io.PipedOutputStream()
        val input = java.io.PipedInputStream(pipe)
        pipe.write(text("FOTO:50\n")); pipe.write(ByteArray(10)); pipe.flush()
        val protocol = BengalaProtocol(input, clock = { now })
        val reader = Thread { try { protocol.readMessage() } catch (_: Exception) {} }
        reader.start()
        Thread.sleep(200)
        assertTrue(protocol.transferActive)
        assertFalse(protocol.isStalled(8_000))
        now = 9_000
        assertTrue(protocol.isStalled(8_000))
        pipe.close()
        reader.join(1_000)
    }

    @Test
    fun jpegValidation() {
        assertTrue(BengalaProtocol.looksLikeJpeg(jpeg(50)))
        assertFalse(BengalaProtocol.looksLikeJpeg(ByteArray(50)))
        assertFalse(BengalaProtocol.looksLikeJpeg(ByteArray(2)))
    }
}

#!/usr/bin/env bash
# Confere as regras de dependência descritas em ARQUITETURA.md. Rode na raiz do projeto.
set -u
SRC="app/src/main/java/com/example/access"
fail=0

# 1) ui/ só pode importar tipos do contrato.
contract_types=$(grep -E "^(data class|enum class|sealed interface|interface) " "$SRC/backend/AccessContract.kt" \
  | sed -E 's/^(data class|enum class|sealed interface|interface) ([A-Za-z]+).*/\2/')
while IFS= read -r line; do
  name=${line##*.}
  if ! grep -qx "$name" <<<"$contract_types"; then
    echo "ERRO: ui/ importa algo fora do contrato: $line"; fail=1
  fi
done < <(grep -rhE "^import com\.example\.access\.(backend|bluetooth|ai|audio|data|navigation|assistant)\." "$SRC/ui" | sed 's/^import //' | sort -u)

# 2) nada fora de ui/ e MainActivity pode importar ui/.
if grep -rn "com.example.access.ui" "$SRC" --include=*.kt | grep -v "^$SRC/ui/" | grep -v "^$SRC/MainActivity.kt"; then
  echo "ERRO: código fora de ui/ importa ui/"; fail=1
fi

# 3) bluetooth/ não conhece o resto do app.
if grep -rn "^import com\.example\.access" "$SRC/bluetooth"; then
  echo "ERRO: bluetooth/ importa outro pacote do app"; fail=1
fi

# 4) Sem Bluetooth, HTTP, JSON ou SharedPreferences dentro de ui/.
if grep -rnE "android\.bluetooth|java\.net|org\.json|SharedPreferences|TextToSpeech" "$SRC/ui"; then
  echo "ERRO: ui/ usa API de infraestrutura"; fail=1
fi

[ $fail -eq 0 ] && echo "Arquitetura OK: as camadas respeitam as regras."
exit $fail

# ACCESS — arquitetura (v3.0)

Regra de ouro: **mudar uma tela nunca exige mexer em Bluetooth, câmera, IA, áudio, histórico ou rotas.**

```
app/src/main/java/com/example/access/
├─ AccessApplication.kt     RAIZ: liga o núcleo quando o processo nasce (também com a tela apagada)
├─ MainActivity.kt          SHELL: permissões, reconhecimento de voz, Toasts. Sem lógica nem telas.
│
├─ ui/                      FRONT END (só Compose). Importa APENAS o contrato.
│  ├─ Theme.kt              cores (padrão e alto contraste), texto ampliado global
│  ├─ Icons.kt              ícones desenhados em código (sem emojis)
│  ├─ Components.kt         botões, cartões, chaves, escolhas
│  ├─ AccessApp.kt          raiz + barra de navegação (enum Page)
│  └─ HomeScreen, HistoryScreen, NavigationScreen, AssistantScreen, SettingsScreen, LastImageDialog
│
├─ backend/                 CONTRATO + COORDENADOR
│  ├─ AccessContract.kt     AccessUiState (o que mostrar) + AccessActions (o que pedir)
│  ├─ AccessViewModel.kt    liga a interface ao coordenador
│  └─ AccessRepository.kt   liga as peças abaixo; não tem protocolo, HTTP nem desenho de tela
│
├─ bluetooth/               BENGALA
│  ├─ BengalaProtocol.kt    lê FOTO:<n>\n + JPEG. Kotlin puro, testado (src/test)
│  ├─ BengalaLink.kt        BengalaListener (o que o serviço conta) + BengalaBridge
│  └─ AccessBluetoothService.kt  conexão SPP em primeiro plano, reconexão, vigia de travamento
├─ ai/                      AiClient (contrato) + OpenRouterClient (Gemini)
├─ assistant/               AssistantChat: conversa dentro do app
├─ audio/                   Speaker (voz pt-BR, canal de acessibilidade) + Haptics (vibração)
├─ data/                    AccessStorage: configurações, histórico, última imagem
└─ navigation/              ExternalApps (Maps), RouteParser (fala -> destino + modo), ReturnToApp

firmware/BengalaTech/BengalaTech.ino   firmware do ESP32-CAM (mesmo protocolo)
```

## Quem pode importar quem

| Pacote        | Pode importar                                  |
|---------------|-------------------------------------------------|
| `ui`          | somente tipos do `backend/AccessContract.kt`    |
| `bluetooth`   | nada do app (só Android)                        |
| `ai`, `audio`, `data`, `navigation`, `assistant` | o contrato e, no máximo, `ai` |
| `backend`     | todos os pacotes acima, **nunca** `ui`          |

Rode `./verificar_arquitetura.sh` para conferir essas regras.

## Como o serviço Bluetooth fala com o resto

O serviço **não** conhece IA, voz nem histórico. Ele chama a interface `BengalaListener`
(`onConnectionChanged`, `onPhotoRequested`, `onPhotoStarted`, `onPhotoReceived`, `onPhotoFailed`).
O `AccessRepository` se registra em `BengalaBridge.listener` ao iniciar. Trocar a IA, ou fazer
a análise num servidor próprio, é mexer só em `ai/` (ou implementar outro `AiClient`).

## Mudanças comuns

- **Visual**: edite só `ui/`. Cores em `Theme.kt`; peças em `Components.kt`.
- **Dado novo na tela**: campo em `AccessUiState`. **Botão novo**: função em `AccessActions`,
  implementada em `AccessViewModel` e `AccessRepository`. Só o contrato muda nos dois lados.
- **Protocolo da bengala**: só `bluetooth/BengalaProtocol.kt` e o `.ino`. Os testes em
  `app/src/test/.../BengalaProtocolTest.kt` documentam o comportamento esperado.

## Fluxo da análise

1. Toque em ANALISAR, atalho "Analisar agora" da notificação, ou botão físico da bengala.
2. Serviço envia `FOTO\n` (ou a bengala envia sozinha ao apertar o botão) → estado `REQUESTING`.
3. Cabeçalho `FOTO:<n>` → `RECEIVING`; os `n` bytes chegam, o JPEG é validado.
4. `AccessRepository` guarda a imagem e chama `AiClient.describe` → `ANALYZING`.
5. Resultado: tela, voz, vibração de sucesso, histórico → `IDLE`.
   Em qualquer falha: voz + vibração longa + mensagem, sem sujar o histórico.

## Vigias de confiabilidade (no serviço)

- imagem sem receber bytes por 8 s → fecha o link e reconecta;
- pedido de foto sem resposta em 15 s → avisa a pessoa;
- reconexão com espera crescente (1,5 s até 15 s) para poupar bateria;
- o serviço só inicia com a permissão Bluetooth concedida (exigência do Android 14+).

## Assistente dentro do app

Aba "Assistente": o app pergunta "Como posso ajudar?", ouve, envia à IA e fala a resposta. Nada abre
fora do ACCESS. A última imagem só vai junto se a pessoa ligar a chave, e vale para a próxima pergunta.
A conversa fica só na memória (não é salva).

## Modos de rota e retorno do Maps

A pé, transporte público, carro e bicicleta; o modo pode ser falado ("Avenida Paulista de ônibus").
A pé, carro e bicicleta iniciam a navegação e o ACCESS volta para a frente com a permissão
"Exibir sobre outros apps". Transporte público abre as opções no Maps e o ACCESS não volta sozinho.

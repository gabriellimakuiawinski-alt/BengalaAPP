package com.example.access.ai

import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Gemini direto pela API do Google (chave gratuita do Google AI Studio, sem OpenRouter).
 *
 * Cada modelo tem a sua própria cota gratuita. Se um modelo estiver sem cota (429) ou indisponível
 * para a chave (404), tenta o próximo da lista [models].
 */
internal class GeminiClient(
    private val apiKey: String,
    models: List<String>
) : AiClient {

    private val modelList = models.map { it.trim() }.filter { it.isNotEmpty() }
        .ifEmpty { listOf(DEFAULT_MODEL) }

    /** Este modelo não serve agora (sem cota ou inexistente): vale tentar o próximo. */
    private class SkipModel(val quota: Boolean) : Exception()

    /** Falha passageira (rede, servidor ocupado): vale tentar de novo no mesmo modelo. */
    private class Transient(val offline: Boolean) : Exception()

    override fun describe(jpeg: ByteArray, detailed: Boolean): String {
        val parts = JSONArray()
            .put(textPart("Descreva o que a câmera da bengala está vendo."))
            .put(imagePart(jpeg))
        val contents = JSONArray().put(JSONObject().put("role", "user").put("parts", parts))
        val system = if (detailed) Prompts.DESCRIBE_DETAILED else Prompts.DESCRIBE_SHORT
        return generate(payload(system, contents, maxTokens = if (detailed) 1536 else 1024, temperature = 0.2))
    }

    override fun chat(history: List<AiMessage>, imageJpeg: ByteArray?): String {
        val recent = history.takeLast(12).dropWhile { !it.fromUser }
        val contents = JSONArray()
        recent.forEachIndexed { index, message ->
            val parts = JSONArray().put(textPart(message.text))
            if (message.fromUser && index == recent.lastIndex && imageJpeg != null) parts.put(imagePart(imageJpeg))
            contents.put(JSONObject().put("role", if (message.fromUser) "user" else "model").put("parts", parts))
        }
        return generate(payload(Prompts.ASSISTANT, contents, maxTokens = 1536, temperature = 0.5))
    }

    private fun textPart(text: String) = JSONObject().put("text", text)

    private fun imagePart(jpeg: ByteArray): JSONObject = JSONObject().put(
        "inlineData",
        JSONObject().put("mimeType", "image/jpeg").put("data", Base64.encodeToString(jpeg, Base64.NO_WRAP))
    )

    private fun payload(system: String, contents: JSONArray, maxTokens: Int, temperature: Double): ByteArray =
        JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(textPart(system))))
            .put("contents", contents)
            // Folga grande em maxOutputTokens: modelos que "pensam" gastam parte dela antes de responder.
            .put("generationConfig", JSONObject().put("temperature", temperature).put("maxOutputTokens", maxTokens))
            .toString()
            .toByteArray(Charsets.UTF_8)

    private fun generate(payload: ByteArray): String {
        val key = apiKey.trim()
        if (key.isBlank()) {
            throw AnalysisException("Configure GEMINI_API_KEY no arquivo local.properties e recompile o app.")
        }
        var lastWasQuota = false
        for (model in modelList) {
            for (attempt in 1..2) {
                try {
                    return parseAnswer(post(model, key, payload))
                } catch (e: SkipModel) {
                    lastWasQuota = e.quota
                    break
                } catch (e: Transient) {
                    if (attempt == 2) {
                        throw AnalysisException(
                            if (e.offline) "Sem conexão com a internet. Verifique a rede e tente de novo."
                            else "O Gemini está ocupado. Tente novamente em instantes."
                        )
                    }
                    try { Thread.sleep(RETRY_DELAY_MS) } catch (_: InterruptedException) { break }
                }
            }
        }
        throw AnalysisException(
            if (lastWasQuota) "O limite gratuito do Gemini acabou por agora. Tente de novo mais tarde."
            else "Nenhum modelo do Gemini está disponível para esta chave. Confira GEMINI_MODELS."
        )
    }

    private fun post(model: String, key: String, payload: ByteArray): String {
        val conn = (URL("$BASE_URL/$model:generateContent").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 15_000
            readTimeout = 40_000
            doOutput = true
            setFixedLengthStreamingMode(payload.size)
            setRequestProperty("x-goog-api-key", key)
            setRequestProperty("Content-Type", "application/json")
        }
        try {
            conn.outputStream.use { it.write(payload) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader()?.use { it.readText() } ?: ""
            when (code) {
                in 200..299 -> return body
                429 -> throw SkipModel(quota = true)
                404 -> throw SkipModel(quota = false)
                400 -> {
                    if (body.contains("API key not valid", ignoreCase = true) || body.contains("API_KEY_INVALID")) {
                        throw AnalysisException("A chave do Gemini foi recusada. Confira GEMINI_API_KEY.")
                    }
                    throw AnalysisException("O Gemini recusou o pedido (erro 400).")
                }
                401, 403 -> throw AnalysisException("O Gemini não aceitou esta chave (erro $code). Confira GEMINI_API_KEY e se a API está liberada para ela.")
                408, 500, 502, 503, 504 -> throw Transient(offline = false)
                else -> throw AnalysisException("O Gemini respondeu com erro $code.")
            }
        } catch (e: IOException) {
            throw Transient(offline = true)
        } finally {
            conn.disconnect()
        }
    }

    private fun parseAnswer(body: String): String {
        val json = try { JSONObject(body) } catch (e: Exception) {
            throw AnalysisException("Resposta inesperada do Gemini.")
        }
        val candidate = json.optJSONArray("candidates")?.optJSONObject(0)
        if (candidate == null) {
            if (json.optJSONObject("promptFeedback")?.has("blockReason") == true) {
                throw AnalysisException("O Gemini bloqueou esta imagem pelo filtro de segurança.")
            }
            throw AnalysisException("O Gemini não devolveu resposta. Tente novamente.")
        }
        val parts = candidate.optJSONObject("content")?.optJSONArray("parts")
        val text = StringBuilder()
        if (parts != null) {
            for (i in 0 until parts.length()) {
                val part = parts.optJSONObject(i) ?: continue
                if (part.optBoolean("thought", false)) continue
                text.append(part.optString("text", ""))
            }
        }
        val answer = text.toString().trim()
        if (answer.isBlank()) {
            if (candidate.optString("finishReason") == "SAFETY") {
                throw AnalysisException("O Gemini bloqueou esta imagem pelo filtro de segurança.")
            }
            throw AnalysisException("A análise voltou vazia. Tente novamente.")
        }
        return answer
    }

    private companion object {
        const val BASE_URL = "https://generativelanguage.googleapis.com/v1beta/models"
        const val DEFAULT_MODEL = "gemini-3.1-flash-lite"
        const val RETRY_DELAY_MS = 1_000L
    }
}

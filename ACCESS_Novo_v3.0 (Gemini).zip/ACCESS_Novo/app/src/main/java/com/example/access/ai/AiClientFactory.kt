package com.example.access.ai

/**
 * Escolhe a IA conforme as chaves configuradas no local.properties:
 *  1. GEMINI_API_KEY presente  -> Gemini direto (chave gratuita do Google AI Studio)
 *  2. senão, OPENROUTER_API_KEY -> OpenRouter
 *  3. nenhuma das duas         -> o cliente do Gemini avisa, por voz e texto, que falta a chave
 */
internal fun createAiClient(geminiKey: String, geminiModels: String, openRouterKey: String): AiClient =
    if (geminiKey.isBlank() && openRouterKey.isNotBlank()) {
        OpenRouterClient(openRouterKey)
    } else {
        GeminiClient(geminiKey, geminiModels.split(','))
    }

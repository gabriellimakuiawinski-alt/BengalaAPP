package com.example.access.backend

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import com.example.access.BuildConfig
import com.example.access.ai.AiClient
import com.example.access.ai.AnalysisException
import com.example.access.ai.createAiClient
import com.example.access.assistant.AssistantChat
import com.example.access.audio.Haptics
import com.example.access.audio.Speaker
import com.example.access.bluetooth.AccessBluetoothService
import com.example.access.bluetooth.BengalaBridge
import com.example.access.bluetooth.BengalaListener
import com.example.access.bluetooth.BluetoothAccess
import com.example.access.data.AccessStorage
import com.example.access.data.decodeScaled
import com.example.access.navigation.ExternalApps
import com.example.access.navigation.NavResult
import com.example.access.navigation.ReturnToApp
import com.example.access.navigation.RouteParser
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Coordenador do app. Existe uma única instância por processo, compartilhada pelo serviço
 * Bluetooth (que continua rodando com a tela apagada) e pela interface.
 *
 * Aqui só se ligam as peças; cada uma vive no seu pacote e fala com as outras por contratos:
 *   bluetooth/  -> BengalaListener        ai/         -> AiClient
 *   data/       -> AccessStorage          audio/      -> Speaker, Haptics
 *   navigation/ -> ExternalApps, ReturnToApp, RouteParser
 *   assistant/  -> AssistantChat
 *
 * Quem "mostra" lê [state]; quem "pede" chama as funções públicas (via AccessViewModel).
 */
object AccessRepository {
    private var initialized = false
    private lateinit var context: Context
    private lateinit var storage: AccessStorage
    private lateinit var speaker: Speaker
    private lateinit var haptics: Haptics
    private lateinit var apps: ExternalApps
    private lateinit var returner: ReturnToApp
    private lateinit var ai: AiClient
    private lateinit var assistant: AssistantChat
    private var overlayHintShown = false

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val analysisRunning = AtomicBoolean(false)

    private enum class SpeechPurpose { DESTINATION, ASSISTANT }
    private var speechPurpose = SpeechPurpose.DESTINATION

    private val _state = MutableStateFlow(AccessUiState())
    val state: StateFlow<AccessUiState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<AccessEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<AccessEvent> = _events.asSharedFlow()

    /** Chamado uma vez, na thread principal, pela classe Application. */
    @Synchronized
    fun init(appContext: Context) {
        if (initialized) return
        context = appContext.applicationContext
        storage = AccessStorage(context)
        speaker = Speaker(context)
        haptics = Haptics(context)
        apps = ExternalApps(context) { message(it) }
        returner = ReturnToApp(context)
        ai = createAiClient(BuildConfig.GEMINI_API_KEY, BuildConfig.GEMINI_MODELS, BuildConfig.OPENROUTER_API_KEY)
        assistant = AssistantChat(ai)

        val settings = storage.loadSettings()
        speaker.setRate(settings.speechRate.value)
        _state.update { it.copy(settings = settings, overlayGranted = Settings.canDrawOverlays(context)) }
        BengalaBridge.listener = bengalaListener
        initialized = true

        // Histórico e imagem podem demorar um pouco: carregam fora da thread principal.
        scope.launch(Dispatchers.IO) {
            val history = storage.loadHistory()
            val lastImage = storage.loadLastImage()
            _state.update { it.copy(history = history, lastImage = lastImage) }
        }
    }

    // ---------- Eventos vindos da bengala (serviço Bluetooth) ----------

    private val bengalaListener = object : BengalaListener {
        override fun onConnectionChanged(status: String, connected: Boolean) {
            val before = _state.value.isConnected
            _state.update { it.copy(connectionStatus = status, isConnected = connected) }
            if (before != connected && _state.value.settings.announceConnection) {
                speak(if (connected) "Bengala conectada." else "Bengala desconectada.", interrupt = false)
            }
        }

        override fun onPhotoRequested() {
            setStage(AnalysisStage.REQUESTING)
            buzz { tap() }
            speak("Capturando a foto.")
        }

        override fun onPhotoStarted(bytes: Int) {
            setStage(AnalysisStage.RECEIVING)
        }

        override fun onPhotoReceived(jpeg: ByteArray) {
            handlePhoto(jpeg)
        }

        override fun onPhotoFailed(reason: String) {
            failure(reason)
        }

        override fun onBengalaText(text: String) {
            // PONG / ESP32_OK: o serviço já atualiza o estado da conexão.
        }
    }

    private fun handlePhoto(jpeg: ByteArray) {
        if (!analysisRunning.compareAndSet(false, true)) {
            message("Ainda estou analisando a foto anterior.")
            return
        }
        setStage(AnalysisStage.ANALYZING)
        val stamp = now()
        scope.launch(Dispatchers.IO) {
            try {
                storage.saveLastImage(jpeg, stamp)
                val bitmap = decodeScaled(jpeg)
                _state.update { it.copy(lastImage = bitmap?.let { b -> LastImage(b, stamp, "") }) }

                val detailed = _state.value.settings.detailedAnalysis
                val outcome: Result<String> = try {
                    Result.success(ai.describe(jpeg, detailed))
                } catch (e: AnalysisException) {
                    Result.failure(e)
                } catch (e: Exception) {
                    Result.failure(AnalysisException("Não consegui analisar a imagem. Verifique a internet."))
                }
                outcome
                    .onSuccess { completeAnalysis(it) }
                    .onFailure { failure(it.message ?: "Não consegui analisar a imagem.") }
            } finally {
                analysisRunning.set(false)
            }
        }
    }

    private fun completeAnalysis(text: String) {
        storage.saveLastImageAnalysis(text)
        addHistory("Análise do ambiente", text)
        _state.update {
            it.copy(
                lastAnalysis = text,
                lastImage = it.lastImage?.copy(analysis = text),
                stage = AnalysisStage.IDLE
            )
        }
        buzz { success() }
        speak(text)
    }

    /** Falha na captura, no envio ou na análise: avisa por voz, vibração e mensagem, sem sujar o histórico. */
    private fun failure(reason: String) {
        setStage(AnalysisStage.IDLE)
        buzz { error() }
        speak(reason)
        message(reason)
    }

    private fun setStage(stage: AnalysisStage) {
        _state.update { it.copy(stage = stage) }
    }

    private fun buzz(action: Haptics.() -> Unit) {
        if (_state.value.settings.haptics) haptics.action()
    }

    // ---------- Ações pedidas pela interface ----------

    fun startBluetoothService(reconnect: Boolean = false) {
        if (!_state.value.settings.autoConnect && !reconnect) return
        if (!BluetoothAccess.hasConnectPermission(context)) {
            bengalaListener.onConnectionChanged("Permissão Bluetooth necessária", false)
            return
        }
        val intent = Intent(context, AccessBluetoothService::class.java)
        if (reconnect) intent.action = AccessBluetoothService.ACTION_RECONNECT
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (_: Exception) {
            bengalaListener.onConnectionChanged("Não foi possível iniciar o serviço Bluetooth", false)
        }
    }

    fun requestAnalysis() {
        if (_state.value.stage != AnalysisStage.IDLE) return
        if (!BluetoothAccess.hasConnectPermission(context)) {
            failure("Permita o Bluetooth nas configurações do Android para falar com a bengala.")
            return
        }
        val intent = Intent(context, AccessBluetoothService::class.java)
            .setAction(AccessBluetoothService.ACTION_REQUEST_ANALYSIS)
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (_: Exception) {
            failure("Não foi possível solicitar a foto.")
        }
    }

    fun repeatLastAnalysis() {
        val text = _state.value.lastAnalysis
        speaker.speak(if (text.isBlank()) "Ainda não há nenhuma análise para repetir." else text)
    }

    /** Fala o texto a pedido da pessoa, mesmo com a resposta por voz desligada. */
    fun speakText(text: String) = speaker.speak(text)

    fun stopSpeaking() = speaker.stop()

    /** Pergunta o destino em voz alta e, quando termina de falar, pede ao shell para ouvir. */
    fun startVoiceRoute() {
        if (!_state.value.overlayGranted && !overlayHintShown) {
            overlayHintShown = true
            message("Dica: em Configurações, conceda \"Exibir sobre outros apps\" para o ACCESS voltar sozinho depois do Maps.")
        }
        speechPurpose = SpeechPurpose.DESTINATION
        speak("Para onde você quer ir?") {
            _events.tryEmit(AccessEvent.LaunchSpeechRecognizer("Para onde você quer ir?"))
        }
    }

    /** Pergunta "Como posso ajudar?" e ouve a pergunta para o assistente. */
    fun startVoiceAssistant() {
        speechPurpose = SpeechPurpose.ASSISTANT
        speak("Pode falar. Como posso ajudar?") {
            _events.tryEmit(AccessEvent.LaunchSpeechRecognizer("Como posso ajudar?"))
        }
    }

    /** Resultado do reconhecimento de voz (destino de rota ou pergunta ao assistente). */
    fun onSpeechResult(heard: String?) {
        val text = heard?.trim().orEmpty()
        when (speechPurpose) {
            SpeechPurpose.ASSISTANT -> {
                if (text.isBlank()) speak("Não consegui entender. Tente novamente.") else askAssistant(text)
            }
            SpeechPurpose.DESTINATION -> {
                if (text.isBlank()) {
                    speak("Não consegui entender o destino. Tente novamente.")
                    return
                }
                val spoken = RouteParser.parse(text)
                if (spoken.destination.isBlank()) {
                    speak("Não ouvi o destino. Toque em ir para e diga o lugar, por exemplo: Avenida Paulista de ônibus.")
                    return
                }
                val mode = spoken.mode ?: _state.value.settings.travelMode
                speak("Destino reconhecido: ${spoken.destination}. Abrindo rota ${mode.spoken}.")
                openRoute(spoken.destination, mode)
            }
        }
    }

    fun onSpeechFailed() {
        speak(
            if (speechPurpose == SpeechPurpose.ASSISTANT) "Não consegui ouvir. Tente novamente."
            else "Não foi possível reconhecer o destino."
        )
    }

    /** Abre a rota no Google Maps. Sem [mode], usa o modo escolhido nas configurações. */
    fun openRoute(destination: String, mode: TravelMode = _state.value.settings.travelMode) {
        val clean = destination.trim()
        if (clean.isBlank()) {
            message("Informe um destino primeiro.")
            return
        }
        _state.update { it.copy(lastDestination = clean) }
        when (apps.openRoute(clean, mode)) {
            NavResult.MAPS_NAVIGATION -> {
                addHistory("Rota (${mode.label})", clean)
                returner.scheduleReturn {
                    speak("Rota iniciada no Google Maps. As instruções de voz continuam no Maps.")
                }
            }
            NavResult.MAPS_PREVIEW -> {
                addHistory("Rota (${mode.label})", clean)
                message("Escolha a rota de transporte público na tela do Google Maps.")
            }
            NavResult.WEB -> addHistory("Rota (${mode.label})", clean)
            NavResult.FAILED -> message("Não foi possível abrir o Google Maps. Verifique sua conexão e tente novamente.")
        }
    }

    fun setTravelMode(mode: TravelMode) {
        updateSettings { it.copy(travelMode = mode) }
    }

    // ---------- Assistente dentro do app ----------

    fun setAssistantUseImage(enabled: Boolean) {
        _state.update { it.copy(assistantUseImage = enabled && it.lastImage != null) }
    }

    fun clearAssistantChat() {
        _state.update { it.copy(assistantMessages = emptyList()) }
    }

    fun askAssistant(text: String) {
        val question = text.trim()
        val current = _state.value
        if (question.isBlank() || current.assistantBusy) return
        val withImage = current.assistantUseImage && current.lastImage != null
        val history = (current.assistantMessages + ChatMessage(true, question, withImage)).takeLast(50)
        // Marca "ocupado" já, antes de sair desta thread, para um segundo toque não duplicar a pergunta.
        _state.update { it.copy(assistantMessages = history, assistantBusy = true, assistantUseImage = false) }
        scope.launch(Dispatchers.IO) {
            val imageBytes = if (withImage) storage.loadLastImageBytes() else null
            val answer = assistant.ask(history, imageBytes)

            _state.update {
                it.copy(assistantMessages = (it.assistantMessages + ChatMessage(false, answer)).takeLast(50), assistantBusy = false)
            }
            speak(assistant.cleanForSpeech(answer))
        }
    }

    fun openGoogleMaps() = apps.openGoogleMaps()
    fun openOverlaySettings() = apps.openOverlaySettings()

    fun refreshPermissions() {
        _state.update { it.copy(overlayGranted = Settings.canDrawOverlays(context)) }
    }

    fun clearHistory() {
        storage.saveHistory(emptyList())
        _state.update { it.copy(history = emptyList()) }
    }

    fun clearLastImage() {
        scope.launch(Dispatchers.IO) { storage.clearLastImage() }
        _state.update { it.copy(lastImage = null, assistantUseImage = false) }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val updated = transform(_state.value.settings)
        storage.saveSettings(updated)
        speaker.setRate(updated.speechRate.value)
        _state.update { it.copy(settings = updated) }
    }

    // ---------- Utilidades internas ----------

    /** Fala respeitando a configuração "Resposta por voz". */
    fun speak(text: String, interrupt: Boolean = true, onFinished: (() -> Unit)? = null) {
        if (_state.value.settings.voiceEnabled) speaker.speak(text, interrupt, onFinished) else onFinished?.invoke()
    }

    fun message(text: String) {
        _events.tryEmit(AccessEvent.ShowMessage(text))
    }

    @Synchronized
    private fun addHistory(title: String, text: String) {
        val updated = (listOf(HistoryItem(title, now(), text)) + _state.value.history).take(100)
        storage.saveHistory(updated)
        _state.update { it.copy(history = updated) }
    }

    private fun now(): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())
}

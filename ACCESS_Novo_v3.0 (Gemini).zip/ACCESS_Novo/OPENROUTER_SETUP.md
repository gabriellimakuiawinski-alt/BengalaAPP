# ACCESS — configuração e teste (v3.0)

## 1. Chave da IA (escolha uma)
Abra `local.properties` na raiz do projeto (no mesmo nível de `settings.gradle.kts`). Se não existir, crie-o. Não remova uma linha `sdk.dir=...` que já exista. Depois use **Sync Project with Gradle Files** e rode o app de novo.

**Opção A — Gemini direto do Google (grátis, sem cartão)**
1. Entre em https://aistudio.google.com/apikey com sua conta Google e crie uma chave.
2. No `local.properties`, adicione: `GEMINI_API_KEY=SUA_CHAVE`
3. Opcional: `GEMINI_MODELS=gemini-3.1-flash-lite,gemini-3.5-flash-lite`. Cada modelo tem a sua própria cota grátis; quando um acaba (erro 429) ou não existe para a sua chave (404), o app tenta o próximo da lista. Se o Google trocar os nomes dos modelos, edite essa linha, sem mexer no código.

Avisos do plano grátis: a cota é pequena (poucas análises por minuto e por dia) e, segundo o Google, no plano grátis as imagens e textos enviados podem ser usados para melhorar os produtos deles. Evite apontar a câmera para documentos, telas ou pessoas que não queiram aparecer.

**Opção B — OpenRouter (pago, precisa de cartão)**
`OPENROUTER_API_KEY=SUA_CHAVE` (modelo `google/gemini-2.5-flash-lite`). É usado só se `GEMINI_API_KEY` estiver vazia.

Se as duas existirem, vale o Gemini. A chave embutida no APK pode ser extraída; para distribuir o app a outras pessoas, mova as chamadas de IA para um backend próprio (basta implementar outro `AiClient` em `ai/`).

## 2. Firmware da bengala
O firmware novo está em `firmware/BengalaTech/BengalaTech.ino`. Leia o cabeçalho do arquivo: ele lista a placa, o esquema de partição **Huge APP** (obrigatório), a ligação do botão (GPIO13 ao GND) e a fonte de alimentação recomendada. O erro `FB-OVF` costuma vir de fonte fraca ou de quadro grande demais; o firmware usa 10 MHz, dois buffers em PSRAM e recompressão automática para evitá-lo.

## 3. Bluetooth
Bluetooth clássico SPP, UUID `00001101-0000-1000-8000-00805F9B34FB`. Pareie `BengalaTech` nas configurações Bluetooth do Android antes do primeiro uso. O app procura o nome exato `BengalaTech`.

Protocolo (não mudou):
- app -> bengala: `FOTO\n`
- bengala -> app: `FOTO:<bytes>\n` + exatamente esses bytes JPEG; ou `ERRO_CAMERA\n`
- testes: `PING\n` -> `PONG`; `STATUS\n` -> `ESP32_OK`
- botão físico: a bengala envia sozinha `FOTO:<bytes>\n` + JPEG; o app já aceita isso.

## 4. Abrir e executar
1. Extraia o ZIP e abra a pasta `ACCESS_Novo` no Android Studio; aguarde a sincronização do Gradle.
2. Grave o firmware na ESP32-CAM e pareie `BengalaTech` com o celular.
3. Execute o app, aceite as permissões de Bluetooth e notificações.
4. Toque em **ANALISAR**.

Testes automáticos do protocolo: `./gradlew testDebugUnitTest` (ou clique com o direito em `BengalaProtocolTest`).
Regras de arquitetura: `./verificar_arquitetura.sh`.

## 5. O que há de novo na v3.0
- Núcleo dividido em pacotes (`bluetooth`, `ai`, `data`, `audio`, `navigation`, `assistant`); o serviço Bluetooth não conhece mais a IA.
- Protocolo robusto: lixo no canal não derruba a conexão, imagem validada, vigia de travamento, reconexão com espera crescente, serviço só inicia com permissão.
- Falhas de captura ou de IA são avisadas por voz e vibração e não entram no histórico.
- Visual novo, ícones próprios, fundo em degradê, botão central animado durante a análise.
- Acessibilidade: texto ampliado global, alto contraste, velocidade da voz, vibração com padrões, aviso falado de conexão, repetir/parar a leitura, "Ouvir" em cada item do histórico, descrição mais completa opcional, atalho "Analisar agora" na notificação (funciona com a tela bloqueada), voz no canal de acessibilidade, áreas de toque de pelo menos 48 dp, rótulos e estados para o TalkBack.
- Otimização: histórico e imagem carregados fora da thread principal, lista do histórico e do chat preguiçosa, animação só enquanto há análise, repetição automática da chamada à IA em falha de rede, notificação só atualiza quando o texto muda.

## 6. O que NÃO foi testado
Este projeto foi escrito e verificado sem Android Studio e sem a placa. O cliente do Gemini compila, mas **nunca foi chamado na API real**: se aparecer erro de modelo (404) ou de chave, ajuste `GEMINI_MODELS`/`GEMINI_API_KEY`. Foram conferidos, com compilador: o protocolo (9 testes passam), todo o código que não é interface (compila contra a API do Android 33) e a sintaxe do `.ino` (contra cabeçalhos simulados). **Não foram verificados**: a compilação completa do app (telas em Compose), o funcionamento no celular, o firmware na placa, o TalkBack, o funcionamento em segundo plano com a tela bloqueada, o retorno do Maps ao ACCESS. Teste cada um no aparelho real antes de confiar.

## Limitações importantes
- O Android pode encerrar serviços ou restringir Bluetooth em segundo plano conforme fabricante e bateria. Teste com a tela apagada e desative a otimização de bateria do ACCESS se a conexão cair.
- O Google Maps é um app externo; o retorno automático depende da permissão "Exibir sobre outros apps".
- A IA pode errar; não use a descrição como única garantia de segurança ao caminhar.
- A chave no APK não é segredo seguro. Use um backend antes de distribuir.
- O botão "abrir o Gemini" foi substituído pelo assistente dentro do app (aba Assistente).

package com.example.access

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.provider.Settings

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size

import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

import androidx.core.content.ContextCompat

import com.example.access.ui.theme.AccessTheme


class MainActivity : ComponentActivity() {

    // ============================================================
    // ESTADOS
    // ============================================================

    private var status by mutableStateOf(
        "Iniciando..."
    )

    private var respostaGemini by mutableStateOf(
        "Nenhuma análise realizada."
    )


    // ============================================================
    // RECEIVER
    //
    // Recebe mensagens do Foreground Service.
    // ============================================================

    private val accessReceiver =
        object : BroadcastReceiver() {

            override fun onReceive(
                context: Context?,
                intent: Intent?
            ) {

                when (intent?.action) {

                    AccessBluetoothService.ACTION_STATUS -> {

                        val novoStatus =
                            intent.getStringExtra(
                                AccessBluetoothService.EXTRA_STATUS
                            )

                        if (
                            novoStatus != null
                        ) {

                            status =
                                novoStatus
                        }
                    }


                    AccessBluetoothService.ACTION_ANALYSIS -> {

                        val analise =
                            intent.getStringExtra(
                                AccessBluetoothService.EXTRA_ANALYSIS
                            )

                        if (
                            analise != null
                        ) {

                            respostaGemini =
                                analise
                        }
                    }
                }
            }
        }


    // ============================================================
    // PERMISSÕES
    // ============================================================

    private val permissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {

            iniciarServico()
        }


    // ============================================================
    // ON CREATE
    // ============================================================

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(
            savedInstanceState
        )


        registrarReceiver()


        solicitarPermissoes()


        setContent {

            AccessTheme {

                Surface(
                    modifier =
                    Modifier.fillMaxSize(),

                    color =
                    MaterialTheme
                        .colorScheme
                        .background
                ) {

                    TelaPrincipal()
                }
            }
        }
    }


    // ============================================================
    // PERMISSÕES
    // ============================================================

    private fun solicitarPermissoes() {

        val permissoes =
            mutableListOf<String>()


        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.S
        ) {

            if (
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_CONNECT
                ) !=
                PackageManager.PERMISSION_GRANTED
            ) {

                permissoes.add(
                    Manifest.permission.BLUETOOTH_CONNECT
                )
            }


            if (
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.BLUETOOTH_SCAN
                ) !=
                PackageManager.PERMISSION_GRANTED
            ) {

                permissoes.add(
                    Manifest.permission.BLUETOOTH_SCAN
                )
            }
        }


        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.TIRAMISU
        ) {

            if (
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.POST_NOTIFICATIONS
                ) !=
                PackageManager.PERMISSION_GRANTED
            ) {

                permissoes.add(
                    Manifest.permission.POST_NOTIFICATIONS
                )
            }
        }


        if (
            permissoes.isNotEmpty()
        ) {

            permissionLauncher.launch(
                permissoes.toTypedArray()
            )

        } else {

            iniciarServico()
        }
    }


    // ============================================================
    // INICIAR FOREGROUND SERVICE
    // ============================================================

    private fun iniciarServico() {

        try {

            val intent =
                Intent(
                    this,
                    AccessBluetoothService::class.java
                )


            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.O
            ) {

                startForegroundService(
                    intent
                )

            } else {

                startService(
                    intent
                )
            }


            status =
                "Iniciando conexão..."


        } catch (
            e: Exception
        ) {

            status =
                "Erro ao iniciar serviço"
        }
    }


    // ============================================================
    // REGISTRAR RECEIVER
    // ============================================================

    private fun registrarReceiver() {

        val filter =
            IntentFilter().apply {

                addAction(
                    AccessBluetoothService.ACTION_STATUS
                )

                addAction(
                    AccessBluetoothService.ACTION_ANALYSIS
                )
            }


        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.TIRAMISU
        ) {

            registerReceiver(
                accessReceiver,
                filter,
                Context.RECEIVER_NOT_EXPORTED
            )

        } else {

            registerReceiver(
                accessReceiver,
                filter
            )
        }
    }


    // ============================================================
    // INTERFACE
    // ============================================================

    @Composable
    private fun TelaPrincipal() {

        Column(

            modifier =
            Modifier
                .fillMaxSize()
                .padding(
                    horizontal = 22.dp,
                    vertical = 28.dp
                ),

            verticalArrangement =
            Arrangement.Top
        ) {

            // ====================================================
            // CABEÇALHO
            // ====================================================

            Text(

                text =
                "Access",

                fontSize =
                32.sp,

                fontWeight =
                FontWeight.Bold,

                color =
                MaterialTheme
                    .colorScheme
                    .onBackground
            )


            Spacer(
                modifier =
                Modifier.height(4.dp)
            )


            Text(

                text =
                "Tecnologia assistiva inteligente",

                fontSize =
                15.sp,

                color =
                MaterialTheme
                    .colorScheme
                    .onBackground
                    .copy(
                        alpha = 0.6f
                    )
            )


            Spacer(
                modifier =
                Modifier.height(25.dp)
            )


            // ====================================================
            // CARD STATUS
            // ====================================================

            Card(

                modifier =
                Modifier.fillMaxWidth(),

                shape =
                RoundedCornerShape(
                    22.dp
                ),

                colors =
                CardDefaults.cardColors(
                    containerColor =
                    MaterialTheme
                        .colorScheme
                        .surfaceVariant
                )
            ) {

                Row(

                    modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(20.dp),

                    verticalAlignment =
                    Alignment.CenterVertically
                ) {

                    Box(

                        modifier =
                        Modifier
                            .size(14.dp)
                            .background(
                                color =
                                if (
                                    status.contains(
                                        "conect",
                                        ignoreCase = true
                                    )
                                ) {
                                    Color(0xFF35C759)
                                } else {
                                    Color(0xFFFF9500)
                                },

                                shape =
                                RoundedCornerShape(
                                    50.dp
                                )
                            )
                    )


                    Spacer(
                        modifier =
                        Modifier.size(14.dp)
                    )


                    Column {

                        Text(

                            text =
                            "Bengala Tech",

                            fontWeight =
                            FontWeight.SemiBold,

                            fontSize =
                            17.sp
                        )


                        Spacer(
                            modifier =
                            Modifier.height(3.dp)
                        )


                        Text(

                            text =
                            status,

                            fontSize =
                            14.sp,

                            color =
                            MaterialTheme
                                .colorScheme
                                .onSurfaceVariant
                        )
                    }
                }
            }


            Spacer(
                modifier =
                Modifier.height(18.dp)
            )


            // ====================================================
            // BOTÃO CONEXÃO
            // ====================================================

            Button(

                onClick = {
                    iniciarServico()
                },

                modifier =
                Modifier
                    .fillMaxWidth()
                    .height(54.dp),

                shape =
                RoundedCornerShape(
                    16.dp
                )
            ) {

                Text(
                    text =
                    "Conectar Bengala"
                )
            }


            Spacer(
                modifier =
                Modifier.height(12.dp)
            )


            // ====================================================
            // BOTÃO ASSISTENTE
            // ====================================================

            OutlinedButton(

                onClick = {
                    abrirAssistente()
                },

                modifier =
                Modifier
                    .fillMaxWidth()
                    .height(54.dp),

                shape =
                RoundedCornerShape(
                    16.dp
                )
            ) {

                Text(
                    text =
                    "Abrir Assistente"
                )
            }


            Spacer(
                modifier =
                Modifier.height(22.dp)
            )


            // ====================================================
            // CARD ANÁLISE
            // ====================================================

            Card(

                modifier =
                Modifier.fillMaxWidth(),

                shape =
                RoundedCornerShape(
                    22.dp
                ),

                colors =
                CardDefaults.cardColors(
                    containerColor =
                    MaterialTheme
                        .colorScheme
                        .surface
                )
            ) {

                Column(

                    modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {

                    Text(

                        text =
                        "Última análise",

                        fontSize =
                        18.sp,

                        fontWeight =
                        FontWeight.Bold
                    )


                    Spacer(
                        modifier =
                        Modifier.height(10.dp)
                    )


                    Text(

                        text =
                        respostaGemini,

                        fontSize =
                        15.sp,

                        lineHeight =
                        22.sp,

                        color =
                        MaterialTheme
                            .colorScheme
                            .onSurface
                            .copy(
                                alpha = 0.8f
                            )
                    )
                }
            }


            Spacer(
                modifier =
                Modifier.height(18.dp)
            )


            // ====================================================
            // INFORMAÇÃO DO SEGUNDO PLANO
            // ====================================================

            Card(

                modifier =
                Modifier.fillMaxWidth(),

                shape =
                RoundedCornerShape(
                    22.dp
                ),

                colors =
                CardDefaults.cardColors(
                    containerColor =
                    MaterialTheme
                        .colorScheme
                        .surfaceVariant
                )
            ) {

                Column(

                    modifier =
                    Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {

                    Text(

                        text =
                        "Segundo plano",

                        fontSize =
                        17.sp,

                        fontWeight =
                        FontWeight.Bold
                    )


                    Spacer(
                        modifier =
                        Modifier.height(7.dp)
                    )


                    Text(

                        text =
                        "O Access mantém a comunicação com a bengala enquanto você utiliza outros aplicativos.",

                        fontSize =
                        14.sp,

                        lineHeight =
                        20.sp
                    )
                }
            }
        }
    }


    // ============================================================
    // ASSISTENTE DO CELULAR
    // ============================================================

    private fun abrirAssistente() {

        try {

            val intent =
                Intent(
                    Intent.ACTION_ASSIST
                )


            startActivity(
                intent
            )


        } catch (
            e: Exception
        ) {

            try {

                val settingsIntent =
                    Intent(
                        Settings.ACTION_VOICE_INPUT_SETTINGS
                    )

                startActivity(
                    settingsIntent
                )

            } catch (
                _: Exception
            ) {

                status =
                    "Assistente do celular indisponível"
            }
        }
    }


    // ============================================================
    // ON DESTROY
    // ============================================================

    override fun onDestroy() {

        try {

            unregisterReceiver(
                accessReceiver
            )

        } catch (
            _: Exception
        ) {
        }


        /*
         * NÃO paramos o AccessBluetoothService aqui.
         *
         * Isso é proposital.
         *
         * Quando o usuário fecha a Activity,
         * o serviço continua funcionando em segundo plano.
         */


        super.onDestroy()
    }
}
package com.example.bengalatech

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(
    tableName = "historico"
)
data class Historico(

    @PrimaryKey(
        autoGenerate = true
    )
    val id: Long = 0,

    val tipo: String,

    val texto: String,

    val timestamp: Long
)
package com.example.access

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.util.Base64

import androidx.core.content.ContextCompat

import org.json.JSONArray
import org.json.JSONObject

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.UUID


class AccessBluetoothService : Service() {

    // ============================================================
    // CONFIGURAÇÕES
    // ============================================================

    companion object {

        const val CHANNEL_ID =
            "access_background"

        const val NOTIFICATION_ID =
            1001


        // Comunicação com MainActivity

        const val ACTION_STATUS =
            "com.example.access.STATUS"

        const val ACTION_ANALYSIS =
            "com.example.access.ANALYSIS"


        const val EXTRA_STATUS =
            "status"

        const val EXTRA_ANALYSIS =
            "analysis"


        // ========================================================
        // GEMINI
        // ========================================================

        /*
         * COLOQUE SUA CHAVE GEMINI AQUI.
         *
         * Exemplo:
         *
         * const val GEMINI_API_KEY =
         *     "AIzaSyXXXXXXXXXXXX"
         */

        const val GEMINI_API_KEY =
            "COLE_SUA_CHAVE_GEMINI_AQUI"


        const val GEMINI_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
    }


    // ============================================================
    // BLUETOOTH
    // ============================================================

    private val bluetoothUUID =
        UUID.fromString(
            "00001101-0000-1000-8000-00805F9B34FB"
        )


    private var socket: BluetoothSocket? =
        null

    private var input: InputStream? =
        null

    private var output: OutputStream? =
        null


    private var running =
        false


    // ============================================================
    // TEXT TO SPEECH
    // ============================================================

    private var tts: TextToSpeech? =
        null


    // ============================================================
    // ON CREATE
    // ============================================================

    override fun onCreate() {

        super.onCreate()


        criarCanalNotificacao()


        tts =
            TextToSpeech(
                this
            ) { resultado ->

                if (
                    resultado ==
                    TextToSpeech.SUCCESS
                ) {

                    tts?.language =
                        Locale(
                            "pt",
                            "BR"
                        )
                }
            }
    }


    // ============================================================
    // ON START COMMAND
    // ============================================================

    override fun onStartCommand(
        intent: Intent?,
        flags: Int,
        startId: Int
    ): Int {

        iniciarForeground()


        if (!running) {

            running =
                true


            Thread {

                conectarBluetooth()

            }.start()
        }


        /*
         * Faz o Android tentar manter o serviço ativo.
         */

        return START_STICKY
    }


    // ============================================================
    // FOREGROUND SERVICE
    // ============================================================

    private fun iniciarForeground() {

        val notification =
            criarNotificacao(
                "Aguardando a Bengala Tech..."
            )


        startForeground(
            NOTIFICATION_ID,
            notification
        )
    }


    // ============================================================
    // CANAL DA NOTIFICAÇÃO
    // ============================================================

    private fun criarCanalNotificacao() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            val canal =
                NotificationChannel(
                    CHANNEL_ID,
                    "Access",
                    NotificationManager.IMPORTANCE_LOW
                )


            canal.description =
                "Comunicação da Bengala Tech em segundo plano"


            val manager =
                getSystemService(
                    NotificationManager::class.java
                )


            manager.createNotificationChannel(
                canal
            )
        }
    }


    // ============================================================
    // NOTIFICAÇÃO
    // ============================================================

    private fun criarNotificacao(
        texto: String
    ): Notification {

        return if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.O
        ) {

            Notification.Builder(
                this,
                CHANNEL_ID
            )
                .setContentTitle(
                    "Access"
                )
                .setContentText(
                    texto
                )
                .setSmallIcon(
                    android.R.drawable.ic_menu_info_details
                )
                .setOngoing(true)
                .build()

        } else {

            Notification.Builder(
                this
            )
                .setContentTitle(
                    "Access"
                )
                .setContentText(
                    texto
                )
                .setSmallIcon(
                    android.R.drawable.ic_menu_info_details
                )
                .setOngoing(true)
                .build()
        }
    }


    // ============================================================
    // ATUALIZAR NOTIFICAÇÃO
    // ============================================================

    private fun atualizarNotificacao(
        texto: String
    ) {

        val manager =
            getSystemService(
                NotificationManager::class.java
            )


        manager.notify(
            NOTIFICATION_ID,
            criarNotificacao(
                texto
            )
        )
    }


    // ============================================================
    // VERIFICAR PERMISSÃO BLUETOOTH
    // ============================================================

    private fun bluetoothPermitido(): Boolean {

        /*
         * Android 11 ou inferior:
         *
         * BLUETOOTH_CONNECT não existe.
         */

        if (
            Build.VERSION.SDK_INT <
            Build.VERSION_CODES.S
        ) {

            return true
        }


        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.BLUETOOTH_CONNECT
        ) ==
                PackageManager.PERMISSION_GRANTED
    }


    // ============================================================
    // CONECTAR BLUETOOTH
    // ============================================================

    private fun conectarBluetooth() {

        try {

            // ====================================================
            // VERIFICAR PERMISSÃO
            // ====================================================

            if (
                !bluetoothPermitido()
            ) {

                enviarStatus(
                    "Permissão Bluetooth não concedida"
                )

                atualizarNotificacao(
                    "Permissão Bluetooth necessária"
                )

                running =
                    false

                return
            }


            // ====================================================
            // BLUETOOTH MANAGER
            // ====================================================

            val manager =
                getSystemService(
                    BLUETOOTH_SERVICE
                ) as BluetoothManager


            val adapter =
                manager.adapter


            if (
                adapter == null
            ) {

                enviarStatus(
                    "Bluetooth indisponível"
                )

                atualizarNotificacao(
                    "Bluetooth indisponível"
                )

                running =
                    false

                return
            }


            // ====================================================
            // DISPOSITIVOS PAREADOS
            // ====================================================

            val dispositivos =
                adapter.bondedDevices


            val dispositivo =
                dispositivos.firstOrNull {

                    it.name ==
                            "BengalaTech"
                }


            if (
                dispositivo == null
            ) {

                enviarStatus(
                    "BengalaTech não pareada"
                )

                atualizarNotificacao(
                    "Pareie a BengalaTech primeiro"
                )

                running =
                    false

                return
            }


            // ====================================================
            // CONECTANDO
            // ====================================================

            enviarStatus(
                "Conectando à BengalaTech..."
            )


            atualizarNotificacao(
                "Conectando à Bengala Tech..."
            )


            // ====================================================
            // CRIAR SOCKET
            // ====================================================

            socket =
                dispositivo.createRfcommSocketToServiceRecord(
                    bluetoothUUID
                )


            // ====================================================
            // CONECTAR
            // ====================================================

            socket?.connect()


            // ====================================================
            // STREAMS
            // ====================================================

            input =
                socket?.inputStream

            output =
                socket?.outputStream


            // ====================================================
            // CONECTADO
            // ====================================================

            enviarStatus(
                "BengalaTech conectada"
            )


            atualizarNotificacao(
                "Bengala Tech conectada"
            )


            // ====================================================
            // RECEBER DADOS
            // ====================================================

            receberDados()


        } catch (
            e: SecurityException
        ) {

            enviarStatus(
                "Permissão Bluetooth necessária"
            )


            atualizarNotificacao(
                "Permissão Bluetooth necessária"
            )


            running =
                false


        } catch (
            e: Exception
        ) {

            enviarStatus(
                "Bluetooth desconectado"
            )


            atualizarNotificacao(
                "Bluetooth desconectado"
            )


            running =
                false
        }
    }


    // ============================================================
    // RECEBER DADOS DA ESP32
    // ============================================================

    private fun receberDados() {

        val entrada =
            input
                ?: return


        try {

            while (
                running &&
                socket?.isConnected == true
            ) {

                val primeiroByte =
                    entrada.read()


                if (
                    primeiroByte == -1
                ) {

                    break
                }


                // =================================================
                // FOTO
                // =================================================

                if (
                    primeiroByte ==
                    'F'.code
                ) {

                    val prefixoBuffer =
                        ByteArray(4)


                    var lidos =
                        0


                    while (
                        lidos < 4
                    ) {

                        val quantidade =
                            entrada.read(
                                prefixoBuffer,
                                lidos,
                                4 - lidos
                            )


                        if (
                            quantidade == -1
                        ) {

                            return
                        }


                        lidos +=
                            quantidade
                    }


                    val prefixo =
                        "F" +
                                String(
                                    prefixoBuffer,
                                    Charsets.UTF_8
                                )


                    if (
                        prefixo !=
                        "FOTO:"
                    ) {

                        continue
                    }


                    // =================================================
                    // TAMANHO DA IMAGEM
                    // =================================================

                    val tamanhoBuilder =
                        StringBuilder()


                    while (true) {

                        val b =
                            entrada.read()


                        if (
                            b == -1
                        ) {

                            return
                        }


                        if (
                            b ==
                            '\n'.code
                        ) {

                            break
                        }


                        if (
                            b !=
                            '\r'.code
                        ) {

                            tamanhoBuilder.append(
                                b.toChar()
                            )
                        }
                    }


                    val tamanho =
                        tamanhoBuilder
                            .toString()
                            .trim()
                            .toIntOrNull()


                    if (
                        tamanho == null ||
                        tamanho <= 0
                    ) {

                        continue
                    }


                    enviarStatus(
                        "Recebendo imagem..."
                    )


                    // =================================================
                    // RECEBER BYTES
                    // =================================================

                    val dados =
                        ByteArray(
                            tamanho
                        )


                    var recebidos =
                        0


                    while (
                        recebidos < tamanho
                    ) {

                        val quantidade =
                            entrada.read(
                                dados,
                                recebidos,
                                tamanho - recebidos
                            )


                        if (
                            quantidade == -1
                        ) {

                            return
                        }


                        recebidos +=
                            quantidade
                    }


                    // =================================================
                    // CONVERTER JPEG → BITMAP
                    // =================================================

                    val bitmap =
                        BitmapFactory.decodeByteArray(
                            dados,
                            0,
                            dados.size
                        )


                    if (
                        bitmap != null
                    ) {

                        enviarStatus(
                            "Foto recebida"
                        )


                        analisarImagem(
                            bitmap
                        )
                    }


                } else {

                    // =================================================
                    // MENSAGEM NORMAL
                    // =================================================

                    val mensagem =
                        StringBuilder()


                    mensagem.append(
                        primeiroByte.toChar()
                    )


                    while (true) {

                        val b =
                            entrada.read()


                        if (
                            b == -1
                        ) {

                            return
                        }


                        if (
                            b ==
                            '\n'.code
                        ) {

                            break
                        }


                        if (
                            b !=
                            '\r'.code
                        ) {

                            mensagem.append(
                                b.toChar()
                            )
                        }
                    }


                    enviarStatus(
                        mensagem
                            .toString()
                            .trim()
                    )
                }
            }


        } catch (
            e: Exception
        ) {

            enviarStatus(
                "Bluetooth desconectado"
            )


            atualizarNotificacao(
                "Bluetooth desconectado"
            )
        }
    }


    // ============================================================
    // GEMINI
    // ============================================================

    private fun analisarImagem(
        bitmap: Bitmap
    ) {

        Thread {

            try {

                enviarStatus(
                    "Analisando imagem..."
                )


                atualizarNotificacao(
                    "Analisando imagem..."
                )


                // =================================================
                // COMPRIMIR
                // =================================================

                val stream =
                    ByteArrayOutputStream()


                bitmap.compress(
                    Bitmap.CompressFormat.JPEG,
                    80,
                    stream
                )


                // =================================================
                // BASE64
                // =================================================

                val imagemBase64 =
                    Base64.encodeToString(
                        stream.toByteArray(),
                        Base64.NO_WRAP
                    )


                // =================================================
                // PROMPT
                // =================================================

                val prompt =
                    """
                    Você é o sistema de visão do Access,
                    uma bengala inteligente destinada a auxiliar
                    uma pessoa cega.

                    Analise cuidadosamente a imagem.

                    Informe somente informações relevantes
                    para locomoção e segurança.

                    Priorize:

                    - obstáculos;
                    - pessoas;
                    - portas;
                    - escadas;
                    - buracos;
                    - objetos no caminho;
                    - esquerda, centro ou direita;
                    - distância aproximada quando possível.

                    Seja extremamente objetivo.

                    A resposta será transformada em voz.

                    Responda em português do Brasil.

                    Não invente informações.
                    """.trimIndent()


                // =================================================
                // INLINE DATA
                // =================================================

                val inlineData =
                    JSONObject()


                inlineData.put(
                    "mime_type",
                    "image/jpeg"
                )


                inlineData.put(
                    "data",
                    imagemBase64
                )


                // =================================================
                // IMAGE PART
                // =================================================

                val imagePart =
                    JSONObject()


                imagePart.put(
                    "inline_data",
                    inlineData
                )


                // =================================================
                // TEXT PART
                // =================================================

                val textPart =
                    JSONObject()


                textPart.put(
                    "text",
                    prompt
                )


                // =================================================
                // PARTS
                // =================================================

                val parts =
                    JSONArray()


                parts.put(
                    imagePart
                )


                parts.put(
                    textPart
                )


                // =================================================
                // CONTENT
                // =================================================

                val content =
                    JSONObject()


                content.put(
                    "parts",
                    parts
                )


                // =================================================
                // CONTENTS
                // =================================================

                val contents =
                    JSONArray()


                contents.put(
                    content
                )


                // =================================================
                // BODY
                // =================================================

                val body =
                    JSONObject()


                body.put(
                    "contents",
                    contents
                )


                // =================================================
                // URL
                // =================================================

                val url =
                    URL(
                        GEMINI_URL
                    )


                val connection =
                    url.openConnection()
                            as HttpURLConnection


                connection.requestMethod =
                    "POST"


                connection.doOutput =
                    true


                connection.connectTimeout =
                    15000


                connection.readTimeout =
                    30000


                connection.setRequestProperty(
                    "Content-Type",
                    "application/json"
                )


                connection.setRequestProperty(
                    "x-goog-api-key",
                    GEMINI_API_KEY
                )


                // =================================================
                // ENVIAR
                // =================================================

                connection.outputStream.use {
                        outputStream ->

                    outputStream.write(
                        body
                            .toString()
                            .toByteArray(
                                Charsets.UTF_8
                            )
                    )
                }


                // =================================================
                // RESPOSTA HTTP
                // =================================================

                val codigo =
                    connection.responseCode


                val resposta =
                    if (
                        codigo in 200..299
                    ) {

                        connection
                            .inputStream
                            .bufferedReader()
                            .use {
                                it.readText()
                            }

                    } else {

                        connection
                            .errorStream
                            ?.bufferedReader()
                            ?.use {
                                it.readText()
                            }
                            ?: ""
                    }


                connection.disconnect()


                // =================================================
                // ERRO
                // =================================================

                if (
                    codigo !in 200..299
                ) {

                    falar(
                        "Erro na análise da imagem."
                    )


                    enviarStatus(
                        "Erro Gemini: HTTP $codigo"
                    )


                    return@Thread
                }


                // =================================================
                // JSON
                // =================================================

                val json =
                    JSONObject(
                        resposta
                    )


                val candidates =
                    json.optJSONArray(
                        "candidates"
                    )


                if (
                    candidates == null ||
                    candidates.length() == 0
                ) {

                    falar(
                        "Não consegui analisar a imagem."
                    )


                    enviarStatus(
                        "Gemini sem resposta"
                    )


                    return@Thread
                }


                // =================================================
                // CONTENT
                // =================================================

                val contentResposta =
                    candidates
                        .getJSONObject(0)
                        .optJSONObject(
                            "content"
                        )


                val responseParts =
                    contentResposta
                        ?.optJSONArray(
                            "parts"
                        )


                val resultado =
                    StringBuilder()


                if (
                    responseParts != null
                ) {

                    for (
                    i in 0 until
                            responseParts.length()
                    ) {

                        resultado.append(
                            responseParts
                                .getJSONObject(i)
                                .optString(
                                    "text",
                                    ""
                                )
                        )
                    }
                }


                // =================================================
                // RESULTADO
                // =================================================

                val textoFinal =
                    resultado
                        .toString()
                        .trim()


                if (
                    textoFinal.isEmpty()
                ) {

                    falar(
                        "Não consegui analisar a imagem."
                    )


                    enviarStatus(
                        "Sem resultado"
                    )


                    return@Thread
                }


                // =================================================
                // ENVIAR PARA APP
                // =================================================

                enviarAnalise(
                    textoFinal
                )


                // =================================================
                // FALAR
                // =================================================

                falar(
                    textoFinal
                )


                enviarStatus(
                    "Análise concluída"
                )


                atualizarNotificacao(
                    "Access ativo"
                )


            } catch (
                e: Exception
            ) {

                falar(
                    "Ocorreu um erro ao analisar a imagem."
                )


                enviarStatus(
                    "Erro Gemini: ${e.message}"
                )
            }

        }.start()
    }


    // ============================================================
    // TEXT TO SPEECH
    // ============================================================

    private fun falar(
        texto: String
    ) {

        tts?.speak(
            texto,
            TextToSpeech.QUEUE_FLUSH,
            null,
            "ACCESS"
        )
    }


    // ============================================================
    // ENVIAR STATUS PARA MAINACTIVITY
    // ============================================================

    private fun enviarStatus(
        texto: String
    ) {

        val intent =
            Intent(
                ACTION_STATUS
            )


        intent.setPackage(
            packageName
        )


        intent.putExtra(
            EXTRA_STATUS,
            texto
        )


        sendBroadcast(
            intent
        )
    }


    // ============================================================
    // ENVIAR ANÁLISE PARA MAINACTIVITY
    // ============================================================

    private fun enviarAnalise(
        texto: String
    ) {

        val intent =
            Intent(
                ACTION_ANALYSIS
            )


        intent.setPackage(
            packageName
        )


        intent.putExtra(
            EXTRA_ANALYSIS,
            texto
        )


        sendBroadcast(
            intent
        )
    }


    // ============================================================
    // DESTROY
    // ============================================================

    override fun onDestroy() {

        running =
            false


        try {

            socket?.close()

        } catch (
            _: Exception
        ) {
        }


        input =
            null

        output =
            null


        tts?.stop()

        tts?.shutdown()


        super.onDestroy()
    }


    // ============================================================
    // BIND
    // ============================================================

    override fun onBind(
        intent: Intent?
    ): IBinder? {

        return null
    }
}
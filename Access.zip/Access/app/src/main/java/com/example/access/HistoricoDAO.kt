package com.example.access

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface HistoricoDAO {

    @Insert
    suspend fun inserir(historico: Historico)

    @Query("SELECT * FROM historico ORDER BY data DESC")
    suspend fun listarTodos(): List<Historico>

    @Delete
    suspend fun excluir(historico: Historico)

    @Query("DELETE FROM historico")
    suspend fun apagarTudo()
}
package com.example.access

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "historico")
data class Historico(

    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,

    val data: Long,

    val pergunta: String,

    val resposta: String,

    val imagemBase64: String? = null
)
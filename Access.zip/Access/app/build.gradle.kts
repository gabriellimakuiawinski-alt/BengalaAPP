plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.devtools.ksp")
}

android {
    namespace = "com.example.access"

    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.access"

        minSdk = 26
        targetSdk = 35

        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }

    kotlinOptions {
        jvmTarget = "11"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {

    // ========================================
    // COMPOSE
    // ========================================

    implementation(
        platform(
            "androidx.compose:compose-bom:2025.08.00"
        )
    )

    implementation(
        "androidx.compose.ui:ui"
    )

    implementation(
        "androidx.compose.ui:ui-graphics"
    )

    implementation(
        "androidx.compose.ui:ui-tooling-preview"
    )

    implementation(
        "androidx.compose.material3:material3"
    )

    implementation(
        "androidx.activity:activity-compose:1.10.1"
    )


    // ========================================
    // ANDROID / LIFECYCLE
    // ========================================

    implementation(
        "androidx.core:core-ktx:1.16.0"
    )

    implementation(
        "androidx.lifecycle:lifecycle-runtime-ktx:2.9.2"
    )

    implementation(
        "androidx.lifecycle:lifecycle-service:2.9.2"
    )


    // ========================================
    // ROOM / SQLITE
    // ========================================

    implementation(
        "androidx.room:room-runtime:2.7.2"
    )

    implementation(
        "androidx.room:room-ktx:2.7.2"
    )

    ksp(
        "androidx.room:room-compiler:2.7.2"
    )


    // ========================================
    // TESTES
    // ========================================

    testImplementation(
        "junit:junit:4.13.2"
    )

    androidTestImplementation(
        platform(
            "androidx.compose:compose-bom:2025.08.00"
        )
    )

    androidTestImplementation(
        "androidx.compose.ui:ui-test-junit4"
    )

    debugImplementation(
        "androidx.compose.ui:ui-tooling"
    )

    debugImplementation(
        "androidx.compose.ui:ui-test-manifest"
    )
}
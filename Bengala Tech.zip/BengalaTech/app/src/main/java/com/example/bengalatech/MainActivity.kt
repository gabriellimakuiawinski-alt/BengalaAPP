package com.example.bengalatech

import android.Manifest
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Base64

import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding

import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.unit.dp

import androidx.core.content.ContextCompat

import com.example.bengalatech.ui.theme.BengalaTechTheme

import org.json.JSONArray
import org.json.JSONObject

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.UUID


class MainActivity : ComponentActivity() {

    // ============================================================
    // GEMINI
    // ============================================================

    private val GEMINI_API_KEY =
        "COLE_SUA_CHAVE_AQUI"

    private val GEMINI_URL =
        "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"


    // ============================================================
    // BLUETOOTH
    // ============================================================

    private var bluetoothSocket: BluetoothSocket? = null

    private var bluetoothInput: InputStream? = null

    private var bluetoothOutput: OutputStream? = null

    private val bluetoothUUID =
        UUID.fromString(
            "00001101-0000-1000-8000-00805F9B34FB"
        )


    // ============================================================
    // VOZ
    // ============================================================

    private var tts: TextToSpeech? = null


    // ============================================================
    // ESTADOS
    // ============================================================

    private var status by mutableStateOf(
        "Desconectado"
    )

    private var respostaGemini by mutableStateOf(
        "Nenhuma análise realizada."
    )

    private var imagemRecebida by mutableStateOf<Bitmap?>(null)

    private var conectado by mutableStateOf(false)


    // ============================================================
    // PERMISSÕES BLUETOOTH
    // ============================================================

    private val permissionLauncher =
        registerForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) {
            listarDispositivos()
        }


    // ============================================================
    // ON CREATE
    // ============================================================

    override fun onCreate(
        savedInstanceState: Bundle?
    ) {

        super.onCreate(savedInstanceState)


        tts = TextToSpeech(
            this
        ) { resultado ->

            if (
                resultado == TextToSpeech.SUCCESS
            ) {

                tts?.language =
                    Locale(
                        "pt",
                        "BR"
                    )
            }
        }


        setContent {

            BengalaTechTheme {

                TelaPrincipal()
            }
        }
    }


    // ============================================================
    // INTERFACE
    // ============================================================

    @Composable
    private fun TelaPrincipal() {

        Column(

            modifier =
            Modifier
                .fillMaxSize()
                .padding(20.dp),

            verticalArrangement =
            Arrangement.Top
        ) {

            Text(
                text = "Bengala Tech",
                style =
                MaterialTheme
                    .typography
                    .headlineMedium
            )


            Spacer(
                modifier =
                Modifier.height(10.dp)
            )


            Text(
                text = "Status: $status"
            )


            Spacer(
                modifier =
                Modifier.height(20.dp)
            )


            Button(

                onClick = {
                    solicitarPermissoesBluetooth()
                },

                modifier =
                Modifier.fillMaxWidth()
            ) {

                Text(
                    "Procurar ESP32"
                )
            }


            Spacer(
                modifier =
                Modifier.height(10.dp)
            )


            Button(

                onClick = {
                    conectarPrimeiroDispositivo()
                },

                modifier =
                Modifier.fillMaxWidth()
            ) {

                Text(
                    "Conectar ESP32"
                )
            }


            Spacer(
                modifier =
                Modifier.height(10.dp)
            )


            Button(

                onClick = {
                    solicitarFoto()
                },

                enabled = conectado,

                modifier =
                Modifier.fillMaxWidth()
            ) {

                Text(
                    "Tirar foto e analisar"
                )
            }


            Spacer(
                modifier =
                Modifier.height(20.dp)
            )


            Text(
                text = "Análise:"
            )


            Spacer(
                modifier =
                Modifier.height(5.dp)
            )


            Text(
                text =
                respostaGemini
            )


            Spacer(
                modifier =
                Modifier.height(15.dp)
            )


            imagemRecebida?.let { bitmap ->

                Image(

                    bitmap =
                    bitmap.asImageBitmap(),

                    contentDescription =
                    "Imagem recebida da ESP32",

                    modifier =
                    Modifier
                        .fillMaxWidth()
                        .height(250.dp)
                )
            }
        }
    }


    // ============================================================
    // PERMISSÕES
    // ============================================================

    private fun solicitarPermissoesBluetooth() {

        if (
            Build.VERSION.SDK_INT >=
            Build.VERSION_CODES.S
        ) {

            permissionLauncher.launch(

                arrayOf(

                    Manifest.permission.BLUETOOTH_CONNECT,

                    Manifest.permission.BLUETOOTH_SCAN
                )
            )

        } else {

            listarDispositivos()
        }
    }


    // ============================================================
    // LISTAR DISPOSITIVOS
    // ============================================================

    private fun listarDispositivos() {

        try {

            val manager =
                getSystemService(
                    BLUETOOTH_SERVICE
                ) as BluetoothManager


            if (
                Build.VERSION.SDK_INT >=
                Build.VERSION_CODES.S
            ) {

                if (
                    ContextCompat.checkSelfPermission(
                        this,
                        Manifest.permission.BLUETOOTH_CONNECT
                    ) !=
                    PackageManager.PERMISSION_GRANTED
                ) {

                    status =
                        "Permissão Bluetooth negada"

                    return
                }
            }


            val dispositivos =
                manager
                    .adapter
                    .bondedDevices


            if (
                dispositivos.isEmpty()
            ) {

                status =
                    "Nenhum dispositivo pareado"

                return
            }


            status =
                "ESP32 encontrada"


        } catch (
            e: SecurityException
        ) {

            status =
                "Sem permissão Bluetooth"

        } catch (
            e: Exception
        ) {

            status =
                "Erro Bluetooth"
        }
    }


    // ============================================================
    // CONECTAR
    // ============================================================

    private fun conectarPrimeiroDispositivo() {

        Thread {

            try {

                val manager =
                    getSystemService(
                        BLUETOOTH_SERVICE
                    ) as BluetoothManager


                if (
                    Build.VERSION.SDK_INT >=
                    Build.VERSION_CODES.S
                ) {

                    if (
                        ContextCompat.checkSelfPermission(
                            this,
                            Manifest.permission.BLUETOOTH_CONNECT
                        ) !=
                        PackageManager.PERMISSION_GRANTED
                    ) {

                        runOnUiThread {

                            status =
                                "Permissão Bluetooth necessária"
                        }

                        return@Thread
                    }
                }


                val dispositivos =
                    manager
                        .adapter
                        .bondedDevices


                if (
                    dispositivos.isEmpty()
                ) {

                    runOnUiThread {

                        status =
                            "Pareie a ESP32 primeiro"
                    }

                    return@Thread
                }


                val dispositivo =
                    dispositivos.first()


                bluetoothSocket =
                    dispositivo.createRfcommSocketToServiceRecord(
                        bluetoothUUID
                    )


                runOnUiThread {

                    status =
                        "Conectando..."
                }


                bluetoothSocket?.connect()


                bluetoothInput =
                    bluetoothSocket?.inputStream


                bluetoothOutput =
                    bluetoothSocket?.outputStream


                conectado =
                    true


                runOnUiThread {

                    status =
                        "ESP32 conectada"
                }


                receberDados()


            } catch (
                e: Exception
            ) {

                conectado =
                    false

                runOnUiThread {

                    status =
                        "Erro ao conectar: ${e.message}"
                }
            }

        }.start()
    }


    // ============================================================
    // SOLICITAR FOTO
    // ============================================================

    private fun solicitarFoto() {

        Thread {

            try {

                bluetoothOutput?.write(
                    "FOTO\n".toByteArray()
                )

                bluetoothOutput?.flush()


                runOnUiThread {

                    status =
                        "Solicitando foto..."

                    respostaGemini =
                        "Aguardando imagem..."
                }

            } catch (
                e: Exception
            ) {

                runOnUiThread {

                    status =
                        "Erro ao solicitar foto"
                }
            }

        }.start()
    }


    // ============================================================
    // RECEBER DADOS DA ESP32
    // ============================================================

    private fun receberDados() {

        Thread {

            try {

                val input =
                    bluetoothInput
                        ?: return@Thread


                while (
                    bluetoothSocket?.isConnected == true
                ) {

                    val primeiroByte =
                        input.read()


                    if (
                        primeiroByte == -1
                    ) {

                        break
                    }


                    // =================================================
                    // FOTO
                    // =================================================

                    if (
                        primeiroByte ==
                        'F'.code
                    ) {

                        val buffer =
                            ByteArray(4)


                        var quantidade =
                            0


                        while (
                            quantidade < 4
                        ) {

                            val n =
                                input.read(
                                    buffer,
                                    quantidade,
                                    4 - quantidade
                                )


                            if (
                                n == -1
                            ) {

                                return@Thread
                            }


                            quantidade += n
                        }


                        val prefixo =
                            "F" +
                                    String(
                                        buffer,
                                        Charsets.UTF_8
                                    )


                        if (
                            prefixo == "FOTO:"
                        ) {

                            val tamanhoTexto =
                                StringBuilder()


                            while (true) {

                                val b =
                                    input.read()


                                if (
                                    b == -1
                                ) {

                                    return@Thread
                                }


                                if (
                                    b == '\n'.code
                                ) {

                                    break
                                }


                                if (
                                    b != '\r'.code
                                ) {

                                    tamanhoTexto.append(
                                        b.toChar()
                                    )
                                }
                            }


                            val tamanho =
                                tamanhoTexto
                                    .toString()
                                    .trim()
                                    .toIntOrNull()


                            if (
                                tamanho == null ||
                                tamanho <= 0
                            ) {

                                continue
                            }


                            val dados =
                                ByteArray(
                                    tamanho
                                )


                            var recebidos =
                                0


                            while (
                                recebidos < tamanho
                            ) {

                                val n =
                                    input.read(
                                        dados,
                                        recebidos,
                                        tamanho - recebidos
                                    )


                                if (
                                    n == -1
                                ) {

                                    return@Thread
                                }


                                recebidos += n
                            }


                            val bitmap =
                                BitmapFactory.decodeByteArray(
                                    dados,
                                    0,
                                    dados.size
                                )


                            if (
                                bitmap != null
                            ) {

                                imagemRecebida =
                                    bitmap


                                runOnUiThread {

                                    status =
                                        "Foto recebida"

                                    respostaGemini =
                                        "Analisando imagem..."
                                }


                                analisarImagem(
                                    bitmap
                                )
                            }
                        }

                    } else {

                        // =================================================
                        // MENSAGEM NORMAL
                        // =================================================

                        val mensagem =
                            StringBuilder()


                        mensagem.append(
                            primeiroByte.toChar()
                        )


                        while (true) {

                            val b =
                                input.read()


                            if (
                                b == -1
                            ) {

                                return@Thread
                            }


                            if (
                                b == '\n'.code
                            ) {

                                break
                            }


                            mensagem.append(
                                b.toChar()
                            )
                        }


                        runOnUiThread {

                            status =
                                mensagem
                                    .toString()
                                    .trim()
                        }
                    }
                }

            } catch (
                e: Exception
            ) {

                runOnUiThread {

                    status =
                        "Erro recebendo dados"
                }
            }
        }.start()
    }


    // ============================================================
    // ANALISAR IMAGEM COM GEMINI
    // ============================================================

    private fun analisarImagem(
        bitmap: Bitmap
    ) {

        Thread {

            try {

                // =================================================
                // COMPRIMIR IMAGEM
                // =================================================

                val stream =
                    ByteArrayOutputStream()


                bitmap.compress(

                    Bitmap.CompressFormat.JPEG,

                    80,

                    stream
                )


                val imagemBytes =
                    stream.toByteArray()


                // =================================================
                // BASE64
                // =================================================

                val imagemBase64 =
                    Base64.encodeToString(
                        imagemBytes,
                        Base64.NO_WRAP
                    )


                // =================================================
                // PROMPT
                // =================================================

                val prompt =
                    """
                    Você é o sistema de visão de uma bengala
                    inteligente para auxiliar uma pessoa cega.

                    Analise cuidadosamente esta imagem.

                    Diga somente informações importantes
                    para a locomoção.

                    Priorize:

                    - obstáculos;
                    - pessoas;
                    - portas;
                    - escadas;
                    - buracos;
                    - objetos no caminho;
                    - esquerda, centro ou direita;
                    - distância aproximada quando possível.

                    Seja extremamente objetivo.

                    A resposta será transformada em voz.

                    Responda em português do Brasil.

                    Não invente informações.
                    """.trimIndent()


                // =================================================
                // DADOS DA IMAGEM
                // =================================================

                val inlineData =
                    JSONObject()


                inlineData.put(
                    "mime_type",
                    "image/jpeg"
                )


                inlineData.put(
                    "data",
                    imagemBase64
                )


                val imagemPart =
                    JSONObject()


                imagemPart.put(
                    "inline_data",
                    inlineData
                )


                // =================================================
                // TEXTO
                // =================================================

                val textoPart =
                    JSONObject()


                textoPart.put(
                    "text",
                    prompt
                )


                // =================================================
                // PARTS
                // =================================================

                val parts =
                    JSONArray()


                parts.put(
                    imagemPart
                )


                parts.put(
                    textoPart
                )


                // =================================================
                // CONTENT
                // =================================================

                val content =
                    JSONObject()


                content.put(
                    "parts",
                    parts
                )


                val contents =
                    JSONArray()


                contents.put(
                    content
                )


                // =================================================
                // BODY
                // =================================================

                val body =
                    JSONObject()


                body.put(
                    "contents",
                    contents
                )


                // =================================================
                // CONEXÃO COM GEMINI
                // =================================================

                val url =
                    URL(
                        GEMINI_URL
                    )


                val connection =
                    url.openConnection()
                            as HttpURLConnection


                connection.requestMethod =
                    "POST"


                connection.doOutput =
                    true


                connection.connectTimeout =
                    15000


                connection.readTimeout =
                    30000


                connection.setRequestProperty(
                    "Content-Type",
                    "application/json"
                )


                connection.setRequestProperty(
                    "x-goog-api-key",
                    GEMINI_API_KEY
                )


                // =================================================
                // ENVIAR REQUISIÇÃO
                // =================================================

                connection.outputStream.use { output ->

                    output.write(
                        body
                            .toString()
                            .toByteArray(
                                Charsets.UTF_8
                            )
                    )
                }


                // =================================================
                // CÓDIGO HTTP
                // =================================================

                val codigo =
                    connection.responseCode


                // =================================================
                // LER RESPOSTA
                // =================================================

                val resposta =
                    if (
                        codigo in 200..299
                    ) {

                        connection
                            .inputStream
                            .bufferedReader()
                            .use {
                                it.readText()
                            }

                    } else {

                        connection
                            .errorStream
                            ?.bufferedReader()
                            ?.use {
                                it.readText()
                            }
                            ?: ""
                    }


                connection.disconnect()


                // =================================================
                // ERRO HTTP
                // =================================================

                if (
                    codigo !in 200..299
                ) {

                    runOnUiThread {

                        respostaGemini =
                            "Erro Gemini: HTTP $codigo"

                        status =
                            "Erro na API"
                    }

                    return@Thread
                }


                // =================================================
                // JSON DA RESPOSTA
                // =================================================

                val json =
                    JSONObject(
                        resposta
                    )


                val candidates =
                    json.optJSONArray(
                        "candidates"
                    )


                if (
                    candidates == null ||
                    candidates.length() == 0
                ) {

                    runOnUiThread {

                        respostaGemini =
                            "O Gemini não retornou uma resposta."

                        status =
                            "Sem resposta"
                    }

                    return@Thread
                }


                val candidate =
                    candidates.getJSONObject(
                        0
                    )


                val responseContent =
                    candidate.optJSONObject(
                        "content"
                    )


                val responseParts =
                    responseContent?.optJSONArray(
                        "parts"
                    )


                if (
                    responseParts == null
                ) {

                    runOnUiThread {

                        respostaGemini =
                            "Não consegui interpretar a resposta."

                        status =
                            "Erro na resposta"
                    }

                    return@Thread
                }


                val resultado =
                    StringBuilder()


                for (
                i in 0 until
                        responseParts.length()
                ) {

                    val part =
                        responseParts
                            .getJSONObject(
                                i
                            )


                    val texto =
                        part.optString(
                            "text",
                            ""
                        )


                    resultado.append(
                        texto
                    )
                }


                val respostaFinal =
                    resultado
                        .toString()
                        .trim()


                runOnUiThread {

                    respostaGemini =
                        if (
                            respostaFinal.isEmpty()
                        ) {

                            "Não consegui analisar a imagem."

                        } else {

                            respostaFinal
                        }


                    status =
                        "Análise concluída"


                    falar(
                        respostaGemini
                    )
                }


            } catch (
                e: Exception
            ) {

                runOnUiThread {

                    respostaGemini =
                        "Erro ao analisar imagem: ${e.message}"

                    status =
                        "Erro Gemini"
                }
            }
        }.start()
    }


    // ============================================================
    // TEXT TO SPEECH
    // ============================================================

    private fun falar(
        texto: String
    ) {

        tts?.speak(

            texto,

            TextToSpeech.QUEUE_FLUSH,

            null,

            "BENGALA_TECH"
        )
    }


    // ============================================================
    // ON DESTROY
    // ============================================================

    override fun onDestroy() {

        try {

            bluetoothSocket?.close()

        } catch (
            _: Exception
        ) {
        }


        tts?.stop()

        tts?.shutdown()


        super.onDestroy()
    }
}


# ACCESS — arquitetura (front end x back end)

```
app/src/main/java/com/example/access/
├─ MainActivity.kt            SHELL: permissões, reconhecimento de voz, Toasts. Sem lógica nem telas.
├─ backend/                   BACK END (nada aqui desenha tela)
│  ├─ AccessContract.kt       CONTRATO: AccessUiState (o que mostrar) + AccessActions (o que pedir)
│  ├─ AccessViewModel.kt      liga a interface ao núcleo
│  ├─ AccessRepository.kt     núcleo: estado, histórico, última imagem, voz, Maps
│  ├─ AccessBluetoothService.kt  conexão SPP com a BengalaTech (serviço em primeiro plano)
│  ├─ OpenRouterClient.kt     Gemini via OpenRouter: descrição de imagens e assistente
│  ├─ RouteParser.kt          entende "Avenida Paulista de ônibus" (destino + modo)
│  ├─ Storage.kt              configurações, histórico e última imagem no celular
│  ├─ Speaker.kt              Text-to-Speech pt-BR
│  ├─ ExternalApps.kt         Google Maps (a pé, transporte público, carro, bicicleta) e permissões
│  └─ ReturnToApp.kt          volta ao ACCESS depois que o Maps começa a guiar
└─ ui/                        FRONT END (só Compose)
   ├─ Theme.kt                cores e tema
   ├─ AccessApp.kt            raiz + barra de navegação
   ├─ HomeScreen.kt, HistoryScreen.kt, NavigationScreen.kt, AssistantScreen.kt, SettingsScreen.kt
   ├─ LastImageDialog.kt      janela da última imagem analisada
   └─ Components.kt           peças reutilizáveis
```

## Regras
1. `ui/` só importa `AccessUiState`, `AccessActions`, `LastImage` (e tipos do contrato) de `backend/`.
   Nada de Bluetooth, JSON, SharedPreferences, TTS ou Intent dentro de `ui/`.
2. `backend/` nunca importa nada de `ui/`.
3. Para mudar o visual: edite só `ui/`. Para mudar o que o app faz: edite só `backend/`.
4. Precisa de um dado novo na tela? Adicione o campo em `AccessUiState`. Precisa de um botão novo
   que faça algo? Adicione a função em `AccessActions`, implemente em `AccessViewModel` e
   `AccessRepository`. Depois use na interface. Só o contrato muda nos dois lados.

## Assistente dentro do app
Aba "Assistente" (ou botão "Falar com o assistente" na tela inicial): o app pergunta "Como posso ajudar?",
ouve, envia ao Gemini via OpenRouter e fala a resposta. Nada abre fora do ACCESS. A última imagem só vai
junto se a pessoa ativar o botão na tela do assistente, e vale só para a próxima pergunta. A conversa fica
apenas na memória do app (não é salva).

## Modos de rota
A pé, transporte público, carro e bicicleta. O modo escolhido fica salvo e também pode ser falado:
"Avenida Paulista de ônibus", "de carro para o aeroporto". A pé, carro e bicicleta iniciam a navegação
passo a passo e o ACCESS volta para a frente. Transporte público abre as opções de rota no Maps
(o Android não permite iniciar a navegação de transporte por intent) e o ACCESS não volta sozinho.

## Fluxo da rota por voz
Botão "IR PARA..." → `startVoiceRoute()` → app pergunta o destino em voz alta → evento
`LaunchSpeechRecognizer` → `MainActivity` abre o reconhecimento → `onSpeechResult()` →
Maps abre a navegação a pé → `ReturnToApp` traz o ACCESS de volta.

## Voltar ao app depois do Maps
O Android bloqueia apps em segundo plano de abrirem telas. Com a permissão "Exibir sobre outros apps"
(Configurações do ACCESS), o app cria uma janela invisível de 1x1 pixel, que o Android aceita como
"app visível", e então consegue voltar. Sem a permissão, aparece uma notificação "Voltar ao ACCESS".

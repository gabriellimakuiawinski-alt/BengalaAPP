# ACCESS — configuração e teste

## 1. Chave do OpenRouter
Abra `local.properties` na raiz do projeto (no mesmo nível de `settings.gradle.kts`) e adicione:

`OPENROUTER_API_KEY=SUA_CHAVE_DO_OPENROUTER`

Se o arquivo não existir, crie-o. Não remova uma linha `sdk.dir=...` que já exista. Depois use **Sync Project with Gradle Files**. A chave embutida no APK pode ser extraída; para distribuir o app a outras pessoas, mova as chamadas de IA para um backend privado.

Modelo configurado: `google/gemini-2.5-flash-lite`.

## 2. Bluetooth com o Arduino enviado
Este app usa Bluetooth clássico SPP e UUID `00001101-0000-1000-8000-00805F9B34FB`. Antes do primeiro uso, pareie `BengalaTech` nas configurações Bluetooth do Android. O app procura o dispositivo já pareado pelo nome exato `BengalaTech`.

Protocolo:
- app -> Arduino: `FOTO\n`
- Arduino -> app: `FOTO:<quantidade de bytes>\n`, seguido imediatamente pelos bytes JPEG exatos
- teste opcional: `PING\n` -> `PONG`; `STATUS\n` -> `ESP32_OK`

O leitor do app lê o cabeçalho até a quebra de linha e, em seguida, lê exatamente o número de bytes anunciado. Não converte os bytes JPEG em texto.

## 3. Abrir e executar
1. Extraia o ZIP.
2. Abra a pasta `ACCESS_Novo` no Android Studio.
3. Aguarde a sincronização Gradle.
4. Pareie a ESP32-CAM `BengalaTech` com o celular.
5. Execute o app e aceite a permissão Bluetooth e a notificação do serviço.
6. Toque em **ANALISAR**.

## 4. O que está implementado
- Tela inicial escura, botão central de análise, status Bluetooth e assistente do Android.
- Serviço em primeiro plano para conexão SPP e reconexão.
- Recepção do cabeçalho `FOTO:<bytes>` e da imagem JPEG.
- Análise multimodal via OpenRouter e Gemini 2.5 Flash Lite.
- Histórico local de análises e destinos.
- Navegação por voz em português brasileiro e abertura de rota a pé no Google Maps.
- Configurações de leitura por voz, reconexão automática e texto ampliado.

## Limitações importantes
- O Android pode encerrar serviços ou restringir Bluetooth em segundo plano conforme fabricante, bateria e permissões. Teste com tela apagada no aparelho-alvo.
- O Google Maps é um app externo. O ACCESS abre a navegação a pé a partir do destino reconhecido, mas o Android não garante retorno automático ao ACCESS nem garante que o áudio do Maps continue em segundo plano em todos os aparelhos.
- A IA pode errar; não use a descrição como única garantia de segurança ao caminhar.
- A chave no APK não é segredo seguro. Use backend antes de distribuir.

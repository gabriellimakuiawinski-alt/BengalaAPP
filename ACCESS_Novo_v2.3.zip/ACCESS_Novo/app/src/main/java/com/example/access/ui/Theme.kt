package com.example.access.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

internal val Navy = Color(0xFF101B2A)
internal val Panel = Color(0xFF1B293A)
internal val PanelLight = Color(0xFF24364A)
internal val Cyan = Color(0xFF23C8D8)
internal val White = Color(0xFFF6F8FB)
internal val Muted = Color(0xFFAAB8C8)
internal val Green = Color(0xFF48D597)
internal val Amber = Color(0xFFFFC45C)

@Composable
fun AccessTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Cyan,
            background = Navy,
            surface = Panel,
            onBackground = White,
            onSurface = White
        ),
        content = content
    )
}

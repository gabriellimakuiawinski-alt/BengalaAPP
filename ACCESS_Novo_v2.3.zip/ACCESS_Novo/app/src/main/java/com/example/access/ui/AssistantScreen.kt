package com.example.access.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState
import com.example.access.backend.ChatMessage

/** Assistente de voz dentro do app: não abre o Gemini, usa a mesma IA do ACCESS. */
@Composable
internal fun AssistantScreen(state: AccessUiState, actions: AccessActions) {
    var typed by remember { mutableStateOf("") }
    val scroll = rememberScrollState()
    val messages = state.assistantMessages

    LaunchedEffect(messages.size, state.assistantBusy) { scroll.animateScrollTo(scroll.maxValue) }

    fun send() {
        if (typed.isNotBlank() && !state.assistantBusy) {
            actions.askAssistant(typed)
            typed = ""
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp, vertical = 16.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                PageHeader("Assistente", "Pergunte por voz ou texto, sem sair do app.")
            }
            if (messages.isNotEmpty()) {
                TextButton(onClick = { actions.clearAssistantChat() }) { Text("Limpar", color = Muted) }
            }
        }
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(scroll).padding(vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (messages.isEmpty() && !state.assistantBusy) {
                EmptyPanel("Toque em FALAR e faça sua pergunta, ou digite abaixo.")
            }
            messages.forEach { MessageBubble(it, state.settings.largeText) }
            if (state.assistantBusy) Text("Pensando...", color = Muted, fontSize = 13.sp)
        }

        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Enviar a última imagem na próxima pergunta", color = White, fontSize = 13.sp)
                Text(
                    if (state.lastImage == null) "Ainda não há imagem analisada."
                    else "A imagem vai ao Gemini junto com a pergunta.",
                    color = Muted, fontSize = 11.sp
                )
            }
            Switch(
                checked = state.assistantUseImage && state.lastImage != null,
                onCheckedChange = { actions.setAssistantUseImage(it) },
                enabled = state.lastImage != null
            )
        }
        Spacer(Modifier.height(8.dp))
        Button(
            onClick = { actions.startVoiceAssistant() },
            enabled = !state.assistantBusy,
            modifier = Modifier.fillMaxWidth().height(60.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy)
        ) {
            Text("🎙", fontSize = 22.sp)
            Spacer(Modifier.width(10.dp))
            Text("FALAR COM O ASSISTENTE", fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp)
        }
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = typed,
                onValueChange = { typed = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Ou digite sua pergunta") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { send() }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = White,
                    unfocusedTextColor = White,
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = PanelLight,
                    cursorColor = Cyan
                )
            )
            Spacer(Modifier.width(8.dp))
            OutlinedButton(
                onClick = { send() },
                enabled = typed.isNotBlank() && !state.assistantBusy,
                modifier = Modifier.height(56.dp),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Cyan)
            ) { Text("Enviar") }
        }
    }
}

@Composable
private fun MessageBubble(message: ChatMessage, largeText: Boolean) {
    val fromUser = message.fromUser
    Box(Modifier.fillMaxWidth(), contentAlignment = if (fromUser) Alignment.CenterEnd else Alignment.CenterStart) {
        Card(
            modifier = Modifier.widthIn(max = 310.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = if (fromUser) Cyan else Panel)
        ) {
            Column(Modifier.padding(12.dp)) {
                if (message.withImage) {
                    Text("🖼️ com a última imagem", fontSize = 10.sp, color = if (fromUser) Navy else Muted)
                }
                Text(
                    message.text,
                    color = if (fromUser) Navy else White,
                    fontSize = if (largeText) 17.sp else 14.sp,
                    lineHeight = if (largeText) 25.sp else 20.sp
                )
            }
        }
    }
}

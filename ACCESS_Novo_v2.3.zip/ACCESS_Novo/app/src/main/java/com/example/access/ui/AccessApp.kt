package com.example.access.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState

/**
 * Raiz do FRONT END. Recebe só o estado e as ações do contrato (backend/AccessContract.kt).
 * Para redesenhar o app, mexa apenas nos arquivos desta pasta (ui/).
 */
@Composable
fun AccessApp(state: AccessUiState, actions: AccessActions) {
    var currentPage by rememberSaveable { mutableStateOf("Início") }

    Column(Modifier.fillMaxSize().background(Navy).systemBarsPadding().imePadding()) {
        Box(Modifier.weight(1f).fillMaxWidth()) {
            when (currentPage) {
                "Histórico" -> HistoryScreen(state, actions)
                "Navegação" -> NavigationScreen(state, actions)
                "Assistente" -> AssistantScreen(state, actions)
                "Configurações" -> SettingsScreen(state, actions)
                else -> HomeScreen(state, actions) { currentPage = it }
            }
        }
        BottomNavigationBar(currentPage) { currentPage = it }
    }
}

@Composable
private fun BottomNavigationBar(current: String, onSelect: (String) -> Unit) {
    HorizontalDivider(color = PanelLight)
    Row(
        Modifier.fillMaxWidth().background(Navy).navigationBarsPadding().padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        NavItem("Início", "⌂", "Início", current, onSelect)
        NavItem("Histórico", "◷", "Histórico", current, onSelect)
        NavItem("Navegação", "⌖", "Rotas", current, onSelect)
        NavItem("Assistente", "✦", "Assistente", current, onSelect)
        NavItem("Configurações", "⚙", "Ajustes", current, onSelect)
    }
}

@Composable
private fun RowScope.NavItem(page: String, symbol: String, label: String, current: String, onSelect: (String) -> Unit) {
    val selected = current == page
    Column(
        Modifier.weight(1f).clickable { onSelect(page) }.padding(vertical = 5.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(symbol, fontSize = 21.sp, color = if (selected) Cyan else Muted)
        Text(label, fontSize = 9.sp, maxLines = 1, color = if (selected) Cyan else White, textAlign = TextAlign.Center)
    }
}

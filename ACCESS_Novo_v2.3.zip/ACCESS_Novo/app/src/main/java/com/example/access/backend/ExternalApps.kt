package com.example.access.backend

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

internal enum class NavResult {
    /** Navegação passo a passo iniciada no Maps (a pé, carro ou bicicleta). */
    MAPS_NAVIGATION,

    /** Maps aberto com as opções de rota (transporte público): a pessoa escolhe a rota no Maps. */
    MAPS_PREVIEW,

    /** Maps não instalado: rota aberta no navegador. */
    WEB,

    FAILED
}

/** Abre apps externos: Google Maps e telas de configuração do Android. */
internal class ExternalApps(
    private val context: Context,
    private val notify: (String) -> Unit
) {
    private fun Intent.newTask() = apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }

    fun openRoute(destination: String, mode: TravelMode): NavResult {
        val encoded = Uri.encode(destination)
        val webMode = when (mode) {
            TravelMode.WALKING -> "walking"
            TravelMode.TRANSIT -> "transit"
            TravelMode.DRIVING -> "driving"
            TravelMode.BICYCLING -> "bicycling"
        }
        val webUri = Uri.parse("https://www.google.com/maps/dir/?api=1&destination=$encoded&travelmode=$webMode")

        // Transporte público não tem navegação passo a passo por intent: abre as opções de rota.
        val baseIntent = if (mode == TravelMode.TRANSIT) {
            Intent(Intent.ACTION_VIEW, webUri)
        } else {
            val code = when (mode) {
                TravelMode.DRIVING -> "d"
                TravelMode.BICYCLING -> "b"
                else -> "w"
            }
            Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=$encoded&mode=$code"))
        }
        val mapsIntent = baseIntent.setPackage(MAPS_PACKAGE).newTask()

        return try {
            context.startActivity(mapsIntent)
            if (mode == TravelMode.TRANSIT) NavResult.MAPS_PREVIEW else NavResult.MAPS_NAVIGATION
        } catch (_: Exception) {
            try {
                context.startActivity(Intent(Intent.ACTION_VIEW, webUri).newTask())
                NavResult.WEB
            } catch (_: Exception) {
                NavResult.FAILED
            }
        }
    }

    fun openGoogleMaps() {
        try {
            val launch = context.packageManager.getLaunchIntentForPackage(MAPS_PACKAGE)
            if (launch != null) {
                context.startActivity(launch.newTask())
            } else {
                context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://maps.google.com")).newTask())
            }
        } catch (_: Exception) {
            notify("Não foi possível abrir o Google Maps.")
        }
    }

    fun openOverlaySettings() {
        try {
            context.startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")).newTask()
            )
        } catch (_: Exception) {
            notify("Não foi possível abrir a tela de permissão.")
        }
    }

    private companion object {
        const val MAPS_PACKAGE = "com.google.android.apps.maps"
    }
}

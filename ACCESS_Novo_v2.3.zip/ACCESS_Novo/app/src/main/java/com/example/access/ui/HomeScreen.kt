package com.example.access.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState

@Composable
internal fun HomeScreen(state: AccessUiState, actions: AccessActions, onNavigate: (String) -> Unit) {
    var showLastImage by remember { mutableStateOf(false) }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(14.dp))
        Box(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text("ACCESS", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold, letterSpacing = 4.sp, color = White)
                Text("TECNOLOGIA PARA MAIS AUTONOMIA", fontSize = 10.sp, letterSpacing = 1.7.sp, color = Muted)
            }
            LastImageButton(
                hasImage = state.lastImage != null,
                onClick = { showLastImage = true },
                modifier = Modifier.align(Alignment.TopEnd)
            )
        }
        Spacer(Modifier.height(20.dp))
        ConnectionCard(state, actions)
        Spacer(Modifier.height(26.dp))
        Text("ANÁLISE DO AMBIENTE", color = Muted, fontSize = 12.sp, letterSpacing = 1.3.sp)
        Spacer(Modifier.height(14.dp))
        Box(
            Modifier.size(220.dp).background(Cyan.copy(alpha = 0.09f), CircleShape).padding(12.dp)
                .background(Cyan.copy(alpha = 0.14f), CircleShape).padding(12.dp)
                .background(Cyan, CircleShape)
                .clickable { actions.requestAnalysis() },
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("◎", fontSize = 58.sp, color = Navy, fontWeight = FontWeight.Light)
                Text("ANALISAR", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Navy, letterSpacing = 1.2.sp)
                Text("TOQUE PARA CAPTURAR", fontSize = 9.sp, color = Navy.copy(alpha = 0.8f))
            }
        }
        Spacer(Modifier.height(18.dp))
        Text("Aponte a bengala para o ambiente e solicite a análise.", color = Muted, fontSize = 12.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = { actions.startVoiceRoute() },
            modifier = Modifier.fillMaxWidth().height(60.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Cyan, contentColor = Navy)
        ) {
            Text("🎙", fontSize = 22.sp)
            Spacer(Modifier.width(10.dp))
            Text("IR PARA... (GOOGLE MAPS)", fontWeight = FontWeight.ExtraBold, letterSpacing = 0.8.sp)
        }
        Spacer(Modifier.height(8.dp))
        TravelModeSelector(state.settings.travelMode, { actions.setTravelMode(it) }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(20.dp))
        if (state.lastAnalysis.isNotBlank()) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text("ÚLTIMA ANÁLISE", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        state.lastAnalysis,
                        color = White,
                        fontSize = if (state.settings.largeText) 18.sp else 14.sp,
                        lineHeight = if (state.settings.largeText) 26.sp else 21.sp
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
        }
        OutlinedButton(
            onClick = {
                actions.startVoiceAssistant()
                onNavigate("Assistente")
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = White)
        ) {
            Text("✦", color = Cyan, fontSize = 21.sp)
            Spacer(Modifier.width(10.dp))
            Text("Falar com o assistente", fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(18.dp))
    }

    if (showLastImage) {
        LastImageDialog(
            image = state.lastImage,
            largeText = state.settings.largeText,
            onDismiss = { showLastImage = false },
            onDelete = { actions.clearLastImage() }
        )
    }
}

@Composable
private fun ConnectionCard(state: AccessUiState, actions: AccessActions) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(12.dp).background(if (state.isConnected) Green else Amber, CircleShape))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("BENGALA TECH", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                Text(state.connectionStatus, color = Muted, fontSize = 12.sp)
            }
            TextButton(onClick = { actions.reconnect() }) { Text("Conectar", color = Cyan) }
        }
    }
}

/** Botão pequeno no canto superior direito: não ocupa espaço do conteúdo principal. */
@Composable
private fun LastImageButton(hasImage: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(48.dp)
            .alpha(if (hasImage) 1f else 0.45f)
            .clip(CircleShape)
            .background(Panel)
            .clickable(onClick = onClick)
            .semantics { contentDescription = "Ver última imagem analisada" },
        contentAlignment = Alignment.Center
    ) {
        Text("🖼️", fontSize = 20.sp, color = Color.Unspecified)
    }
}

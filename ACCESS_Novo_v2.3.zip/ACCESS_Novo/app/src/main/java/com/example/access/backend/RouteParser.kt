package com.example.access.backend

internal data class SpokenRoute(val destination: String, val mode: TravelMode?)

/**
 * Interpreta a frase falada. Exemplos:
 *  "Avenida Paulista de ônibus"            -> destino "Avenida Paulista", modo TRANSIT
 *  "de carro para o aeroporto de Congonhas" -> destino "aeroporto de Congonhas", modo DRIVING
 *  "quero ir para o Ibirapuera"            -> destino "Ibirapuera", modo null (usa o escolhido na tela)
 * O modo só é reconhecido no começo ou no fim da frase, para não confundir com nomes de lugares.
 */
internal object RouteParser {
    private val options = setOf(RegexOption.IGNORE_CASE)
    private const val PREFIX = "(?:(?:de|por|com|no|em|via)\\s+)?"

    private val modePhrases: List<Pair<TravelMode, String>> = listOf(
        TravelMode.TRANSIT to "transporte\\s+p[úu]blico|[ôo]nibus|metr[ôo]|trem",
        TravelMode.DRIVING to "carro|autom[óo]vel",
        TravelMode.BICYCLING to "bicicleta|bike",
        TravelMode.WALKING to "a\\s+p[ée]|andando|caminhando"
    )

    private val modeAtStart = modePhrases.map { (mode, words) -> mode to Regex("^$PREFIX(?:$words)\\s+", options) }
    private val modeAtEnd = modePhrases.map { (mode, words) -> mode to Regex("(?:^|\\s+)$PREFIX(?:$words)$", options) }

    private val filler = Regex(
        "^(?:eu\\s+)?(?:quero\\s+ir|vou|ir|me\\s+leve|me\\s+leva|navegar)\\s+(?:para|pra|até|ate|a|ao|à)\\s+(?:(?:a|o|as|os)\\s+)?",
        options
    )
    private val leadingPreposition = Regex("^(?:para|pra|até|ate|ao|à)\\s+(?:(?:a|o|as|os)\\s+)?", options)

    fun parse(heard: String): SpokenRoute {
        var text = heard.trim().replace(Regex("\\s+"), " ")
        var mode: TravelMode? = null

        for ((candidate, regex) in modeAtEnd) {
            if (regex.containsMatchIn(text)) {
                text = text.replace(regex, "")
                mode = candidate
                break
            }
        }
        if (mode == null) {
            for ((candidate, regex) in modeAtStart) {
                if (regex.containsMatchIn(text)) {
                    text = text.replace(regex, "")
                    mode = candidate
                    break
                }
            }
        }
        text = text.replace(filler, "").replace(leadingPreposition, "").trim()
        // Se só o modo foi falado ("de carro"), o destino fica vazio para o app perguntar de novo.
        return SpokenRoute(text.ifBlank { if (mode != null) "" else heard.trim() }, mode)
    }
}

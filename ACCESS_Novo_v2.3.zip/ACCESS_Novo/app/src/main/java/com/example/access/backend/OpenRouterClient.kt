package com.example.access.backend

import android.util.Base64
import com.example.access.BuildConfig
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** Erro com mensagem já pronta para o usuário. */
internal class AnalysisException(message: String) : Exception(message)

/** Conversa com o Gemini (via OpenRouter): descrição de imagens e assistente de voz. */
internal object OpenRouterClient {
    private const val URL_API = "https://openrouter.ai/api/v1/chat/completions"
    private const val MODEL = "google/gemini-2.5-flash-lite"

    private val DESCRIBE_PROMPT = """
        Você é o assistente de acessibilidade visual do ACCESS. Descreva em português brasileiro, de forma curta e objetiva, o ambiente visto na imagem. Priorize obstáculos, degraus, buracos, portas, pessoas, veículos e riscos. Diga esquerda, centro ou direita apenas quando isso estiver visível. Não invente distâncias. Se não conseguir avaliar algo, diga isso claramente. Não afirme que o caminho é seguro apenas porque não vê obstáculos.
    """.trimIndent()

    private val ASSISTANT_PROMPT = """
        Você é o assistente de voz do ACCESS, um app para pessoas com deficiência visual que usam a Bengala Tech. Responda sempre em português do Brasil, de forma curta e clara, com frases fáceis de ouvir. Não use markdown, listas, emojis nem símbolos. Se houver imagem e a pessoa pedir para descrevê-la, cite primeiro obstáculos e riscos, não invente distâncias e nunca garanta que o caminho é seguro. Se não souber algo ou não conseguir ver, diga isso. Para ir a algum lugar, oriente a usar o botão de rota do ACCESS. Em emergência, oriente ligar para 192 (SAMU), 193 (bombeiros) ou 190 (polícia).
    """.trimIndent()

    fun describe(jpeg: ByteArray): String {
        val content = JSONArray().put(textPart(DESCRIBE_PROMPT)).put(imagePart(jpeg))
        val messages = JSONArray().put(JSONObject().put("role", "user").put("content", content))
        return complete(messages, maxTokens = 180, temperature = 0.2)
    }

    /** [history] inclui a pergunta nova no final. A imagem só vai junto com a última pergunta. */
    fun chat(history: List<ChatMessage>, imageJpeg: ByteArray?): String {
        val recent = history.takeLast(12).dropWhile { !it.fromUser }
        val messages = JSONArray().put(JSONObject().put("role", "system").put("content", ASSISTANT_PROMPT))
        recent.forEachIndexed { index, message ->
            val isLast = index == recent.lastIndex
            if (message.fromUser && isLast && imageJpeg != null) {
                val content = JSONArray().put(textPart(message.text)).put(imagePart(imageJpeg))
                messages.put(JSONObject().put("role", "user").put("content", content))
            } else {
                messages.put(
                    JSONObject().put("role", if (message.fromUser) "user" else "assistant").put("content", message.text)
                )
            }
        }
        return complete(messages, maxTokens = 400, temperature = 0.5)
    }

    private fun textPart(text: String) = JSONObject().put("type", "text").put("text", text)

    private fun imagePart(jpeg: ByteArray): JSONObject {
        val image64 = Base64.encodeToString(jpeg, Base64.NO_WRAP)
        return JSONObject().put("type", "image_url")
            .put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$image64"))
    }

    private fun complete(messages: JSONArray, maxTokens: Int, temperature: Double): String {
        val key = BuildConfig.OPENROUTER_API_KEY.trim()
        if (key.isBlank()) {
            throw AnalysisException("Configure OPENROUTER_API_KEY no arquivo local.properties e recompile o app.")
        }
        val body = JSONObject()
            .put("model", MODEL)
            .put("temperature", temperature)
            .put("max_tokens", maxTokens)
            .put("messages", messages)
        val conn = (URL(URL_API).openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20000
            readTimeout = 45000
            doOutput = true
            setRequestProperty("Authorization", "Bearer $key")
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("HTTP-Referer", "https://access.local")
            setRequestProperty("X-Title", "ACCESS")
        }
        val responseBody: String
        try {
            conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            responseBody = stream?.bufferedReader()?.use { it.readText() } ?: ""
            if (code !in 200..299) throw IllegalStateException("OpenRouter HTTP $code: ${responseBody.take(300)}")
        } finally {
            conn.disconnect()
        }
        return JSONObject(responseBody).getJSONArray("choices")
            .getJSONObject(0).getJSONObject("message").getString("content").trim()
    }
}

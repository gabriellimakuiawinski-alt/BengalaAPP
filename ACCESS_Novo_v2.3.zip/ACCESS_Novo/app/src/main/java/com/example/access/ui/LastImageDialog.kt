package com.example.access.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.LastImage

@Composable
internal fun LastImageDialog(
    image: LastImage?,
    largeText: Boolean,
    onDismiss: () -> Unit,
    onDelete: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Panel,
        title = { Text("Última imagem analisada", color = White, fontWeight = FontWeight.Bold) },
        text = {
            if (image == null) {
                Text("Nenhuma imagem foi analisada ainda. Toque em ANALISAR para capturar uma.", color = Muted)
            } else {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    Image(
                        bitmap = image.bitmap.asImageBitmap(),
                        contentDescription = "Última imagem enviada para análise",
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)),
                        contentScale = ContentScale.FillWidth
                    )
                    Spacer(Modifier.height(8.dp))
                    if (image.capturedAt.isNotBlank()) {
                        Text(image.capturedAt, color = Muted, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                    }
                    Text(
                        image.analysis.ifBlank { "Analisando..." },
                        color = White,
                        fontSize = if (largeText) 17.sp else 14.sp,
                        lineHeight = if (largeText) 25.sp else 20.sp
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Fechar", color = Cyan) } },
        dismissButton = {
            if (image != null) TextButton(onClick = { onDelete(); onDismiss() }) { Text("Apagar imagem", color = Muted) }
        }
    )
}

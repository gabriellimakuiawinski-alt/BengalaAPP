package com.example.access

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.access.backend.AccessEvent
import com.example.access.backend.AccessViewModel
import com.example.access.ui.AccessApp
import com.example.access.ui.AccessTheme
import kotlinx.coroutines.launch

/**
 * SHELL: só faz a ponte com o sistema Android (permissões, reconhecimento de voz, Toasts).
 * Não tem lógica de negócio nem desenho de tela: isso fica em backend/ e ui/.
 */
class MainActivity : ComponentActivity() {
    private val viewModel: AccessViewModel by viewModels()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { viewModel.onPermissionsHandled() }

    private val speechLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val heard = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            viewModel.onSpeechResult(heard)
        } else {
            viewModel.onSpeechFailed()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.events.collect { event ->
                    when (event) {
                        is AccessEvent.ShowMessage ->
                            Toast.makeText(this@MainActivity, event.message, Toast.LENGTH_LONG).show()
                        is AccessEvent.LaunchSpeechRecognizer -> launchSpeechRecognizer(event.prompt)
                    }
                }
            }
        }

        setContent {
            AccessTheme {
                val state by viewModel.state.collectAsState()
                AccessApp(state = state, actions = viewModel)
            }
        }
        requestPermissionsAndStart()
    }

    override fun onResume() {
        super.onResume()
        viewModel.onResume()
    }

    private fun launchSpeechRecognizer(prompt: String) {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, prompt)
        }
        try {
            speechLauncher.launch(intent)
        } catch (_: Exception) {
            Toast.makeText(this, "O reconhecimento de voz não está disponível neste celular.", Toast.LENGTH_LONG).show()
        }
    }

    private fun requestPermissionsAndStart() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (!granted(Manifest.permission.BLUETOOTH_CONNECT)) permissions += Manifest.permission.BLUETOOTH_CONNECT
            if (!granted(Manifest.permission.BLUETOOTH_SCAN)) permissions += Manifest.permission.BLUETOOTH_SCAN
        }
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            permissions += Manifest.permission.POST_NOTIFICATIONS
        }
        if (permissions.isNotEmpty()) permissionLauncher.launch(permissions.toTypedArray())
        else viewModel.onPermissionsHandled()
    }

    private fun granted(permission: String) =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
}

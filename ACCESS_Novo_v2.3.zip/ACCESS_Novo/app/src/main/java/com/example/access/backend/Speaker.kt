package com.example.access.backend

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** Voz do app (Text-to-Speech em português do Brasil). */
internal class Speaker(context: Context) {
    private val main = Handler(Looper.getMainLooper())
    private val callbacks = ConcurrentHashMap<String, () -> Unit>()
    @Volatile private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale("pt", "BR")
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { finish(utteranceId) }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { finish(utteranceId) }
                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        // Frase interrompida por outra: descarta o callback sem executá-lo.
                        if (utteranceId != null) callbacks.remove(utteranceId)
                    }
                })
                ready = true
            }
        }
    }

    private fun finish(utteranceId: String?) {
        val callback = utteranceId?.let { callbacks.remove(it) } ?: return
        main.post { callback() }
    }

    /** Fala o texto. [onFinished] roda quando a fala termina (ou imediatamente se a voz não estiver pronta). */
    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        val engine = tts
        if (!ready || engine == null) {
            onFinished?.let { main.post(it) }
            return
        }
        val id = "access-" + System.nanoTime()
        if (onFinished != null) callbacks[id] = onFinished
        val result = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
        if (result != TextToSpeech.SUCCESS) finish(id)
    }

    fun shutdown() {
        tts?.shutdown()
        tts = null
    }
}

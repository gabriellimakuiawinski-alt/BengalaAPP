package com.example.access.backend

import android.graphics.Bitmap

/*
 * CONTRATO ENTRE FRONT END (pacote ui) E BACK END (pacote backend).
 *
 * O front end só pode importar ESTE arquivo do backend. Enquanto o contrato não mudar,
 * a interface pode ser redesenhada à vontade sem tocar em Bluetooth, IA, voz ou Maps.
 *  - AccessUiState : tudo o que a interface precisa MOSTRAR
 *  - AccessActions : tudo o que a interface pode PEDIR
 */

data class HistoryItem(val title: String, val date: String, val text: String)

/** Forma de ir até o destino. [label] aparece na tela; [spoken] é falado pela voz do app. */
enum class TravelMode(val label: String, val spoken: String) {
    WALKING("A pé", "a pé"),
    TRANSIT("Transporte público", "de transporte público"),
    DRIVING("Carro", "de carro"),
    BICYCLING("Bicicleta", "de bicicleta")
}

data class AppSettings(
    val voiceEnabled: Boolean = true,
    val autoConnect: Boolean = true,
    val largeText: Boolean = false,
    val travelMode: TravelMode = TravelMode.WALKING
)

/** Última imagem enviada para análise, guardada só no celular. */
data class LastImage(val bitmap: Bitmap, val capturedAt: String, val analysis: String)

/** Mensagem da conversa com o assistente. */
data class ChatMessage(val fromUser: Boolean, val text: String, val withImage: Boolean = false)

data class AccessUiState(
    val connectionStatus: String = "Iniciando conexão...",
    val isConnected: Boolean = false,
    val lastAnalysis: String = "",
    val lastImage: LastImage? = null,
    val history: List<HistoryItem> = emptyList(),
    val settings: AppSettings = AppSettings(),
    val lastDestination: String = "",
    /** Permissão "Exibir sobre outros apps" (usada para voltar ao ACCESS depois do Maps). */
    val overlayGranted: Boolean = false,
    val assistantMessages: List<ChatMessage> = emptyList(),
    val assistantBusy: Boolean = false,
    /** Se verdadeiro, a última imagem vai junto com a PRÓXIMA pergunta ao assistente. */
    val assistantUseImage: Boolean = false
)

/** Eventos pontuais que o back end pede ao "shell" (MainActivity) para executar. */
sealed interface AccessEvent {
    data class ShowMessage(val message: String) : AccessEvent
    data class LaunchSpeechRecognizer(val prompt: String) : AccessEvent
}

interface AccessActions {
    fun requestAnalysis()
    fun reconnect()

    // Rotas
    fun startVoiceRoute()
    fun openRoute(destination: String)
    fun setTravelMode(mode: TravelMode)
    fun openGoogleMaps()
    fun openOverlaySettings()

    // Assistente dentro do app
    fun startVoiceAssistant()
    fun askAssistant(text: String)
    fun setAssistantUseImage(enabled: Boolean)
    fun clearAssistantChat()

    // Dados e configurações
    fun clearHistory()
    fun clearLastImage()
    fun setVoiceEnabled(enabled: Boolean)
    fun setAutoConnect(enabled: Boolean)
    fun setLargeText(enabled: Boolean)
}

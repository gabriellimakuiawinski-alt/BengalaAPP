package com.example.access.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState

@Composable
internal fun HistoryScreen(state: AccessUiState, actions: AccessActions) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        PageHeader("Histórico", "Suas análises anteriores ficam salvas neste celular.")
        Spacer(Modifier.height(14.dp))
        if (state.history.isEmpty()) {
            EmptyPanel("Ainda não há análises salvas.")
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                state.history.forEach { item ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                        Column(Modifier.fillMaxWidth().padding(14.dp)) {
                            Text(item.title, color = Cyan, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Text(item.date, color = Muted, fontSize = 11.sp)
                            Spacer(Modifier.height(7.dp))
                            Text(item.text, color = White, fontSize = if (state.settings.largeText) 17.sp else 13.sp, lineHeight = 20.sp)
                        }
                    }
                }
            }
            TextButton(onClick = { actions.clearHistory() }, modifier = Modifier.align(Alignment.End)) {
                Text("Limpar histórico", color = Muted)
            }
        }
    }
}

package com.example.access.backend

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Núcleo do back end. Existe uma única instância por processo, compartilhada pelo serviço
 * Bluetooth (que continua rodando com a tela apagada) e pela interface.
 *
 * Quem "mostra" lê [state]; quem "pede" chama as funções públicas (via AccessViewModel).
 */
object AccessRepository {
    private var initialized = false
    private lateinit var context: Context
    private lateinit var storage: AccessStorage
    private lateinit var speaker: Speaker
    private lateinit var apps: ExternalApps
    private lateinit var returner: ReturnToApp
    private var overlayHintShown = false

    private enum class SpeechPurpose { DESTINATION, ASSISTANT }
    private var speechPurpose = SpeechPurpose.DESTINATION

    private val _state = MutableStateFlow(AccessUiState())
    val state: StateFlow<AccessUiState> = _state.asStateFlow()

    private val _events = MutableSharedFlow<AccessEvent>(extraBufferCapacity = 16)
    val events: SharedFlow<AccessEvent> = _events.asSharedFlow()

    /** Deve ser chamado na thread principal (serviço ou ViewModel). */
    @Synchronized
    fun init(appContext: Context) {
        if (initialized) return
        context = appContext.applicationContext
        storage = AccessStorage(context)
        speaker = Speaker(context)
        apps = ExternalApps(context) { message(it) }
        returner = ReturnToApp(context)
        _state.update {
            it.copy(
                settings = storage.loadSettings(),
                history = storage.loadHistory(),
                lastImage = storage.loadLastImage(),
                overlayGranted = Settings.canDrawOverlays(context)
            )
        }
        initialized = true
    }

    // ---------- Chamado pelo serviço Bluetooth ----------

    fun setConnection(status: String, connected: Boolean) {
        _state.update { it.copy(connectionStatus = status, isConnected = connected) }
    }

    fun onImageReceived(jpeg: ByteArray) {
        val stamp = now()
        storage.saveLastImage(jpeg, stamp)
        val bitmap = decodeScaled(jpeg)
        _state.update { it.copy(lastImage = bitmap?.let { b -> LastImage(b, stamp, "") }) }
    }

    fun onAnalysisResult(text: String) {
        storage.saveLastImageAnalysis(text)
        addHistory("Análise do ambiente", text)
        _state.update { it.copy(lastAnalysis = text, lastImage = it.lastImage?.copy(analysis = text)) }
        speak(text)
    }

    // ---------- Ações pedidas pela interface ----------

    fun startBluetoothService(reconnect: Boolean = false) {
        if (!_state.value.settings.autoConnect && !reconnect) return
        val intent = Intent(context, AccessBluetoothService::class.java)
        if (reconnect) intent.action = AccessBluetoothService.ACTION_RECONNECT
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (_: Exception) {
            setConnection("Não foi possível iniciar o serviço Bluetooth", false)
        }
    }

    fun requestAnalysis() {
        val intent = Intent(context, AccessBluetoothService::class.java)
            .setAction(AccessBluetoothService.ACTION_REQUEST_ANALYSIS)
        try {
            ContextCompat.startForegroundService(context, intent)
        } catch (_: Exception) {
            message("Não foi possível solicitar a foto.")
        }
    }

    /** Pergunta o destino em voz alta e, quando termina de falar, pede ao shell para ouvir. */
    fun startVoiceRoute() {
        if (!_state.value.overlayGranted && !overlayHintShown) {
            overlayHintShown = true
            message("Dica: em Configurações, conceda \"Exibir sobre outros apps\" para o ACCESS voltar sozinho depois do Maps.")
        }
        speechPurpose = SpeechPurpose.DESTINATION
        speak("Para onde você quer ir?") {
            _events.tryEmit(AccessEvent.LaunchSpeechRecognizer("Para onde você quer ir?"))
        }
    }

    /** Pergunta "Como posso ajudar?" e ouve a pergunta para o assistente. */
    fun startVoiceAssistant() {
        speechPurpose = SpeechPurpose.ASSISTANT
        speak("Pode falar. Como posso ajudar?") {
            _events.tryEmit(AccessEvent.LaunchSpeechRecognizer("Como posso ajudar?"))
        }
    }

    /** Resultado do reconhecimento de voz (destino de rota ou pergunta ao assistente). */
    fun onSpeechResult(heard: String?) {
        val text = heard?.trim().orEmpty()
        when (speechPurpose) {
            SpeechPurpose.ASSISTANT -> {
                if (text.isBlank()) speak("Não consegui entender. Tente novamente.") else askAssistant(text)
            }
            SpeechPurpose.DESTINATION -> {
                if (text.isBlank()) {
                    speak("Não consegui entender o destino. Tente novamente.")
                    return
                }
                val spoken = RouteParser.parse(text)
                if (spoken.destination.isBlank()) {
                    speak("Não ouvi o destino. Toque em ir para e diga o lugar, por exemplo: Avenida Paulista de ônibus.")
                    return
                }
                val mode = spoken.mode ?: _state.value.settings.travelMode
                speak("Destino reconhecido: ${spoken.destination}. Abrindo rota ${mode.spoken}.")
                openRoute(spoken.destination, mode)
            }
        }
    }

    fun onSpeechFailed() {
        speak(
            if (speechPurpose == SpeechPurpose.ASSISTANT) "Não consegui ouvir. Tente novamente."
            else "Não foi possível reconhecer o destino."
        )
    }

    /** Abre a rota no Google Maps. Sem [mode], usa o modo escolhido nas configurações. */
    fun openRoute(destination: String, mode: TravelMode = _state.value.settings.travelMode) {
        val clean = destination.trim()
        if (clean.isBlank()) {
            message("Informe um destino primeiro.")
            return
        }
        _state.update { it.copy(lastDestination = clean) }
        when (apps.openRoute(clean, mode)) {
            NavResult.MAPS_NAVIGATION -> {
                addHistory("Rota (${mode.label})", clean)
                returner.scheduleReturn {
                    speak("Rota iniciada no Google Maps. As instruções de voz continuam no Maps.")
                }
            }
            NavResult.MAPS_PREVIEW -> {
                addHistory("Rota (${mode.label})", clean)
                message("Escolha a rota de transporte público na tela do Google Maps.")
            }
            NavResult.WEB -> addHistory("Rota (${mode.label})", clean)
            NavResult.FAILED -> message("Não foi possível abrir o Google Maps. Verifique sua conexão e tente novamente.")
        }
    }

    fun setTravelMode(mode: TravelMode) {
        updateSettings { it.copy(travelMode = mode) }
    }

    // ---------- Assistente dentro do app ----------

    fun setAssistantUseImage(enabled: Boolean) {
        _state.update { it.copy(assistantUseImage = enabled && it.lastImage != null) }
    }

    fun clearAssistantChat() {
        _state.update { it.copy(assistantMessages = emptyList()) }
    }

    fun askAssistant(text: String) {
        val question = text.trim()
        val current = _state.value
        if (question.isBlank() || current.assistantBusy) return
        val imageBytes = if (current.assistantUseImage) storage.loadLastImageBytes() else null
        val history = (current.assistantMessages + ChatMessage(true, question, imageBytes != null)).takeLast(50)
        _state.update { it.copy(assistantMessages = history, assistantBusy = true, assistantUseImage = false) }
        Thread {
            val answer = try {
                OpenRouterClient.chat(history, imageBytes)
            } catch (e: AnalysisException) {
                e.message ?: "Não consegui responder agora."
            } catch (e: Exception) {
                "Não consegui responder agora. Verifique a internet e tente de novo."
            }
            _state.update {
                it.copy(assistantMessages = (it.assistantMessages + ChatMessage(false, answer)).takeLast(50), assistantBusy = false)
            }
            speak(cleanForSpeech(answer))
        }.start()
    }

    private fun cleanForSpeech(text: String) = text.replace(Regex("[*_#`]+"), "")

    fun openGoogleMaps() = apps.openGoogleMaps()
    fun openOverlaySettings() = apps.openOverlaySettings()

    fun refreshPermissions() {
        _state.update { it.copy(overlayGranted = Settings.canDrawOverlays(context)) }
    }

    fun clearHistory() {
        storage.saveHistory(emptyList())
        _state.update { it.copy(history = emptyList()) }
    }

    fun clearLastImage() {
        storage.clearLastImage()
        _state.update { it.copy(lastImage = null) }
    }

    fun updateSettings(transform: (AppSettings) -> AppSettings) {
        val updated = transform(_state.value.settings)
        storage.saveSettings(updated)
        _state.update { it.copy(settings = updated) }
    }

    // ---------- Utilidades internas ----------

    fun speak(text: String, onFinished: (() -> Unit)? = null) {
        if (_state.value.settings.voiceEnabled) speaker.speak(text, onFinished) else onFinished?.invoke()
    }

    fun message(text: String) {
        _events.tryEmit(AccessEvent.ShowMessage(text))
    }

    private fun addHistory(title: String, text: String) {
        val updated = (listOf(HistoryItem(title, now(), text)) + _state.value.history).take(100)
        storage.saveHistory(updated)
        _state.update { it.copy(history = updated) }
    }

    private fun now(): String =
        SimpleDateFormat("dd/MM/yyyy HH:mm", Locale("pt", "BR")).format(Date())
}

package com.example.access.ui

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState

@Composable
internal fun SettingsScreen(state: AccessUiState, actions: AccessActions) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp)) {
        PageHeader("Configurações", "Personalize a experiência do ACCESS.")
        Spacer(Modifier.height(18.dp))
        SettingSwitch("Resposta por voz", "Ler os resultados das análises em voz alta.", state.settings.voiceEnabled) { actions.setVoiceEnabled(it) }
        SettingSwitch("Reconectar à bengala", "O serviço tenta restabelecer a conexão Bluetooth.", state.settings.autoConnect) { actions.setAutoConnect(it) }
        SettingSwitch("Texto ampliado", "Aumenta o tamanho das descrições e do histórico.", state.settings.largeText) { actions.setLargeText(it) }
        Spacer(Modifier.height(10.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Bengala Bluetooth", fontWeight = FontWeight.Bold)
                Text("Nome esperado: BengalaTech", color = Muted, fontSize = 13.sp)
                Text("Protocolo: Bluetooth clássico SPP", color = Muted, fontSize = 13.sp)
                TextButton(onClick = { actions.reconnect() }) { Text("Reconectar agora", color = Cyan) }
            }
        }
        Spacer(Modifier.height(12.dp))
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
            Column(Modifier.padding(16.dp)) {
                Text("Voltar ao ACCESS após abrir o Maps", fontWeight = FontWeight.Bold)
                Text(
                    if (state.overlayGranted) {
                        "Permissão concedida: o ACCESS volta sozinho para a tela depois de iniciar a rota."
                    } else {
                        "Para o ACCESS voltar sozinho depois de abrir o Maps, o Android exige a permissão \"Exibir sobre outros apps\". Ative o ACCESS na lista que vai abrir."
                    },
                    color = Muted, fontSize = 13.sp, lineHeight = 19.sp
                )
                if (!state.overlayGranted) {
                    TextButton(onClick = { actions.openOverlaySettings() }) { Text("Conceder permissão", color = Cyan) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "Privacidade: as imagens e as perguntas ao assistente são enviadas ao OpenRouter (Gemini). A última imagem fica guardada apenas neste celular (toque no ícone de imagem na tela inicial para ver ou apagar) e só vai ao assistente se você ativar essa opção na tela dele. A conversa com o assistente não é salva.",
            color = Muted, fontSize = 12.sp, lineHeight = 18.sp
        )
    }
}

package com.example.access.backend

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

class AccessBluetoothService : Service() {
    companion object {
        const val ACTION_REQUEST_ANALYSIS = "com.example.access.REQUEST_ANALYSIS"
        const val ACTION_RECONNECT = "com.example.access.RECONNECT"
        const val CHANNEL_ID = "access_connection"
        private const val DEVICE_NAME = "BengalaTech"
        private val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    @Volatile private var running = false
    @Volatile private var connected = false
    @Volatile private var pendingPhoto = false
    private var socket: BluetoothSocket? = null
    private var input: InputStream? = null
    private var output: OutputStream? = null
    private val photoInProgress = AtomicBoolean(false)
    private var worker: Thread? = null

    override fun onCreate() {
        super.onCreate()
        AccessRepository.init(applicationContext)
        val manager = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            manager.createNotificationChannel(
                NotificationChannel(CHANNEL_ID, "Conexão ACCESS", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        ensureForeground()
        when (intent?.action) {
            ACTION_REQUEST_ANALYSIS -> {
                pendingPhoto = true
                if (connected) sendCommand("FOTO\n")
                else broadcastStatus("Bengala desconectada; tentando conectar...")
            }
            ACTION_RECONNECT -> {
                // Fechar o socket desbloqueia a leitura atual; o loop de conexão tenta reconectar.
                closeConnection()
            }
        }
        if (worker?.isAlive != true) {
            running = true
            worker = Thread { connectionLoop() }.apply { name = "ACCESS-Bluetooth"; start() }
        }
        return START_STICKY
    }

    private fun ensureForeground() {
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ACCESS")
            .setContentText("Mantendo conexão com a bengala")
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth)
            .setOngoing(true)
            .build()
        startForeground(1001, notification)
    }

    private fun connectionLoop() {
        while (running) {
            try {
                if (!hasBluetoothPermission()) {
                    broadcastStatus("Permissão Bluetooth necessária")
                    Thread.sleep(2500)
                    continue
                }
                val adapter = (getSystemService(BLUETOOTH_SERVICE) as BluetoothManager).adapter
                if (adapter == null || !adapter.isEnabled) {
                    broadcastStatus("Ative o Bluetooth do celular")
                    Thread.sleep(2500)
                    continue
                }
                val device = adapter.bondedDevices.firstOrNull { it.name == DEVICE_NAME }
                if (device == null) {
                    broadcastStatus("Pareie '$DEVICE_NAME' nas configurações Bluetooth")
                    Thread.sleep(3000)
                    continue
                }
                broadcastStatus("Conectando à $DEVICE_NAME...")
                val newSocket = device.createRfcommSocketToServiceRecord(SPP_UUID)
                socket = newSocket
                newSocket.connect()
                input = newSocket.inputStream
                output = newSocket.outputStream
                connected = true
                broadcastStatus("BengalaTech conectada")
                if (pendingPhoto) sendCommand("FOTO\n")
                readProtocol(newSocket.inputStream)
            } catch (e: SecurityException) {
                broadcastStatus("Permissão Bluetooth negada")
                sleepQuietly(2500)
            } catch (e: Exception) {
                connected = false
                if (running) broadcastStatus("Conexão perdida; reconectando...")
                sleepQuietly(1500)
            } finally {
                connected = false
                closeConnection()
            }
        }
    }

    private fun hasBluetoothPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) == PackageManager.PERMISSION_GRANTED

    private fun readProtocol(stream: InputStream) {
        while (running && socket?.isConnected == true) {
            val line = readAsciiLine(stream) ?: throw IllegalStateException("Bluetooth encerrado")
            when {
                line.startsWith("FOTO:") -> {
                    val size = line.substringAfter("FOTO:").trim().toLongOrNull()
                        ?: throw IllegalStateException("Tamanho de imagem inválido")
                    if (size <= 0 || size > 8_000_000) throw IllegalStateException("Tamanho de imagem fora do limite: $size")
                    broadcastStatus("Recebendo imagem (${size / 1024} KB)...")
                    val jpeg = readExact(stream, size.toInt())
                    broadcastStatus("Imagem recebida; analisando...")
                    pendingPhoto = false
                    analyzeImage(jpeg)
                }
                line == "PONG" -> broadcastStatus("Bengala conectada (teste PONG)")
                line == "ESP32_OK" -> broadcastStatus("BengalaTech conectada")
                line == "ERRO_CAMERA" -> {
                    pendingPhoto = false
                    broadcastStatus("A câmera não conseguiu capturar a foto")
                }
                line.isNotBlank() -> broadcastStatus("Bengala: $line")
            }
        }
    }

    private fun readAsciiLine(stream: InputStream): String? {
        val out = ByteArrayOutputStream()
        while (true) {
            val value = stream.read()
            if (value == -1) return if (out.size() == 0) null else out.toString(Charsets.US_ASCII.name())
            if (value == '\n'.code) return out.toString(Charsets.US_ASCII.name()).trimEnd('\r')
            if (out.size() >= 128) throw IllegalStateException("Cabeçalho Bluetooth muito longo")
            out.write(value)
        }
    }

    private fun readExact(stream: InputStream, expected: Int): ByteArray {
        val result = ByteArray(expected)
        var offset = 0
        while (offset < expected) {
            val count = stream.read(result, offset, expected - offset)
            if (count < 0) throw IllegalStateException("Conexão caiu durante a imagem ($offset/$expected bytes)")
            if (count > 0) offset += count
        }
        return result
    }

    @Synchronized
    private fun sendCommand(command: String) {
        try {
            val stream = output
            if (stream == null || socket?.isConnected != true) {
                pendingPhoto = command.startsWith("FOTO")
                broadcastStatus("Bengala desconectada; aguardando conexão")
                return
            }
            stream.write(command.toByteArray(Charsets.US_ASCII))
            stream.flush()
            if (command.startsWith("FOTO")) {
                pendingPhoto = true
                broadcastStatus("Solicitando foto à bengala...")
            }
        } catch (e: Exception) {
            broadcastStatus("Falha ao enviar comando Bluetooth")
            closeConnection()
        }
    }

    private fun analyzeImage(jpeg: ByteArray) {
        if (!photoInProgress.compareAndSet(false, true)) return
        AccessRepository.onImageReceived(jpeg)
        Thread {
            try {
                AccessRepository.onAnalysisResult(OpenRouterClient.describe(jpeg))
            } catch (e: AnalysisException) {
                AccessRepository.onAnalysisResult(e.message ?: "Não consegui analisar a imagem.")
            } catch (e: Exception) {
                AccessRepository.onAnalysisResult("Não consegui analisar a imagem. Verifique a internet e a configuração do OpenRouter.")
            } finally {
                photoInProgress.set(false)
            }
        }.start()
    }

    private fun broadcastStatus(value: String) {
        AccessRepository.setConnection(value, connected)
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(1001, NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("ACCESS").setContentText(value)
            .setSmallIcon(android.R.drawable.stat_sys_data_bluetooth).setOngoing(true).build())
    }

    private fun closeConnection() {
        connected = false
        try { input?.close() } catch (_: Exception) {}
        try { output?.close() } catch (_: Exception) {}
        try { socket?.close() } catch (_: Exception) {}
        input = null
        output = null
        socket = null
    }

    private fun sleepQuietly(ms: Long) {
        try { Thread.sleep(ms) } catch (_: InterruptedException) {}
    }

    override fun onBind(intent: Intent?): IBinder? = null
    override fun onDestroy() {
        running = false
        closeConnection()
        super.onDestroy()
    }
}

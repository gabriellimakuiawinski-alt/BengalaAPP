package com.example.access.backend

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.core.app.NotificationCompat

/**
 * Traz o ACCESS de volta para a frente depois que o Google Maps começa a guiar.
 *
 * O Android 10+ bloqueia apps em segundo plano de abrirem telas. A exceção que usamos é um app
 * com janela visível: com a permissão "Exibir sobre outros apps" criamos uma janela invisível de
 * 1x1 pixel antes de ir para o Maps. Sem a permissão, tentamos mesmo assim e deixamos uma
 * notificação "Voltar ao ACCESS" como plano B.
 */
internal class ReturnToApp(private val context: Context) {
    private val handler = Handler(Looper.getMainLooper())
    private var anchor: View? = null

    fun scheduleReturn(delayMs: Long = 4500L, onReturned: () -> Unit) {
        handler.post { showAnchor() }
        handler.postDelayed({
            bringToFront()
            onReturned()
            handler.postDelayed({ hideAnchor() }, 4000L)
        }, delayMs)
    }

    private fun launchIntent(): Intent? =
        context.packageManager.getLaunchIntentForPackage(context.packageName)?.addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )

    private fun bringToFront() {
        val intent = launchIntent() ?: return
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
        }
        if (!Settings.canDrawOverlays(context)) postFallbackNotification(intent)
    }

    private fun showAnchor() {
        if (anchor != null || !Settings.canDrawOverlays(context)) return
        try {
            val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            val view = View(context)
            val params = WindowManager.LayoutParams(
                1, 1,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.START }
            windowManager.addView(view, params)
            anchor = view
        } catch (_: Exception) {
        }
    }

    private fun hideAnchor() {
        val view = anchor ?: return
        try {
            (context.getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeViewImmediate(view)
        } catch (_: Exception) {
        }
        anchor = null
    }

    private fun postFallbackNotification(intent: Intent) {
        try {
            val manager = context.getSystemService(NotificationManager::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                manager.createNotificationChannel(
                    NotificationChannel(CHANNEL_ID, "Voltar ao ACCESS", NotificationManager.IMPORTANCE_HIGH)
                )
            }
            val pending = PendingIntent.getActivity(
                context, 0, intent, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val notification = NotificationCompat.Builder(context, CHANNEL_ID)
                .setContentTitle("Voltar ao ACCESS")
                .setContentText("Toque aqui para voltar ao app. O Maps continua guiando.")
                .setSmallIcon(android.R.drawable.ic_menu_revert)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pending)
                .setAutoCancel(true)
                .setTimeoutAfter(20000L)
                .build()
            manager.notify(NOTIFICATION_ID, notification)
        } catch (_: Exception) {
        }
    }

    private companion object {
        const val CHANNEL_ID = "access_return"
        const val NOTIFICATION_ID = 1002
    }
}

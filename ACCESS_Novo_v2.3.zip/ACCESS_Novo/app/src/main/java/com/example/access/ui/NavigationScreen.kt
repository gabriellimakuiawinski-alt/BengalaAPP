package com.example.access.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.access.backend.AccessActions
import com.example.access.backend.AccessUiState
import com.example.access.backend.TravelMode

@Composable
internal fun NavigationScreen(state: AccessUiState, actions: AccessActions) {
    var info by remember { mutableStateOf("Escolha como vai, depois digite ou fale o destino. O ACCESS abre a rota no Google Maps.") }
    var typedDestination by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        PageHeader("Navegação", "Planeje seu trajeto por voz.")
        Spacer(Modifier.height(18.dp))
        TravelModeSelector(state.settings.travelMode, { actions.setTravelMode(it) }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(6.dp))
        Text(
            if (state.settings.travelMode == TravelMode.TRANSIT) {
                "No transporte público o Maps mostra as opções de rota: escolha uma na tela do Maps. O ACCESS não volta sozinho nesse modo."
            } else {
                "Dica: você também pode falar o modo, por exemplo \"Avenida Paulista de ônibus\"."
            },
            color = Muted, fontSize = 11.sp, lineHeight = 16.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(22.dp))
        Box(Modifier.size(150.dp).background(Cyan.copy(alpha = 0.12f), CircleShape), contentAlignment = Alignment.Center) {
            Text("⌖", fontSize = 76.sp, color = Cyan)
        }
        Spacer(Modifier.height(24.dp))
        Text(info, color = Muted, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 22.sp)
        Spacer(Modifier.height(24.dp))
        OutlinedTextField(
            value = typedDestination,
            onValueChange = { typedDestination = it },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Para onde você quer ir?") },
            placeholder = { Text("Ex.: Avenida Paulista, São Paulo") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = White,
                unfocusedTextColor = White,
                focusedBorderColor = Cyan,
                unfocusedBorderColor = PanelLight,
                focusedLabelColor = Cyan,
                unfocusedLabelColor = Muted,
                cursorColor = Cyan
            )
        )
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                if (typedDestination.isNotBlank()) {
                    info = "Abrindo a rota ${state.settings.travelMode.spoken} para ${typedDestination.trim()}."
                    actions.openRoute(typedDestination)
                } else {
                    actions.startVoiceRoute()
                }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(14.dp)
        ) {
            Text(
                if (typedDestination.isBlank()) "Abrir rota no Google Maps" else "Buscar rota (${state.settings.travelMode.label})",
                color = Navy,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(10.dp))
        OutlinedButton(
            onClick = { actions.startVoiceRoute() },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = White)
        ) { Text("🎙 Falar destino", color = Cyan, fontWeight = FontWeight.Bold) }
        OutlinedButton(
            onClick = { actions.openGoogleMaps() },
            modifier = Modifier.fillMaxWidth().height(50.dp),
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = White)
        ) { Text("Abrir Google Maps", color = White) }
        if (state.lastDestination.isNotBlank()) {
            Spacer(Modifier.height(20.dp))
            Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                Column(Modifier.padding(14.dp)) {
                    Text("ÚLTIMO DESTINO", color = Cyan, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(state.lastDestination, color = White)
                    TextButton(onClick = { actions.openRoute(state.lastDestination) }) {
                        Text("Abrir rota novamente", color = Cyan)
                    }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            "A navegação por voz depende do reconhecimento de fala e do Google Maps instalado.",
            color = Muted, fontSize = 11.sp, textAlign = TextAlign.Center
        )
    }
}
